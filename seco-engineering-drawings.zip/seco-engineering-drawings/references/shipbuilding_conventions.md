# Shipbuilding & Marine Structural Drafting Conventions (SECO)

Activated whenever a drawing is classified as `shipbuilding-structural` or `shipbuilding-outfitting`. Supplements `iso_standards.md` with shipyard production and IACS/Class drafting discipline.

## 1. Vessel Coordinate System & Mandatory Reference Planes
Every shipbuilding drawing is anchored to the vessel's principal reference planes:
- **Longitudinal (`X`):** Referenced from **Aft Perpendicular (`AP`)** or **Frame numbers (`FR 0`, `FR 1`, ...)** with an explicitly declared **frame spacing schedule** (e.g., `FR 0–40 @ 600 mm`).
- **Transverse (`Y`):** Referenced from **Centerline (`CL`, `Y = 0`)**, explicitly labeled **`PORT` (`P`)** and **`STBD` (`S`)**.
- **Vertical (`Z`):** Referenced from **Baseline (`BL`, `Z = 0`)** or **Waterlines (`WL`)** / **Deck Molded Lines**.

### Standard Marine View Orientations
Every structural view **must** carry an explicit viewing direction and orientation arrow:
- **Profile / Longitudinal Elevation:** Bow to the right (**`FWD →`**), typically looking Port (`LKG PORT`) or explicitly labeled `LKG STBD`.
- **Transverse Section / Frame / Bulkhead:** **`LKG FWD`** (SECO default, Looking Forward — `PORT` on left, `STBD` on right) unless explicitly labeled `LKG AFT` (`STBD` on left, `PORT` on right).
- **Plan / Deck / Tank Top View:** Looking down (`PLAN VIEW`), **`FWD →`** to the right, `PORT` on top, `STBD` on bottom.

## 2. Molded Lines (`ML`) & Material / Stiffener Throw
In ship structures, geometry is defined along **Molded Lines (`ML`)**, and actual steel thickness is thrown strictly to one declared side:
- **Plate Thickness Throw:** Every structural plate must declare its molded-line side:
  - `FWD` / `AFT` (for transverse bulkheads & web frames)
  - `ABV` (above) / `BLW` (below) (for decks, flats, tank tops)
  - `INBD` (inboard, toward CL) / `OUTBD` (outboard, away from CL) / `PORT` / `STBD` (for longitudinal bulkheads & girders)
  - `CL` / `SYM` (centered on centerline or molded plane)
- **Stiffener Toe Direction:** Every asymmetric stiffener (`HP` bulb flat, `L` angle, `FB` offset) must show its **toe/flange throw arrow** on the view (e.g., `TOE FWD`, `TOE INBD`, `TOE UP`) so fitters weld it facing the correct way.
- **Ambiguity rule:** Never guess plate throw or stiffener toe direction if omitted from instructions—flag it in the intake gate!

## 3. Standard Marine Structural Profiles & Plate Callouts
- **Plates:** `<thickness> PL` + steel grade (e.g., `12 PL GR.A`, `16 PL AH36`), with steel density **`7.85 t/m³`** (`0.00785 kg/cm³`).
- **Flat Bars (`FB`):** `FB <height>x<thick>` (e.g., `FB 150x12`), linear mass `= height * thick * 0.00785 kg/m`.
- **Bulb Flats (`HP`, EN 10067):** `HP <h>x<t>` (e.g., `HP 120x7`, `HP 160x8`, `HP 180x9`, `HP 200x10`, `HP 240x10`, `HP 260x11`). Standard EN 10067 linear masses are encoded in `scripts/cad_core/standards.py`.
- **Angles (`L`, EN 10056):** `L <a>x<b>x<t>` (e.g., `L 100x75x8`, `L 125x75x10`).
- **Built-Up T-Bars (`T`):** `T <web_h>x<web_t> / <flange_w>x<flange_t>` (e.g., `T 300x10 / 150x12`).
- **Fabrication Features:**
  - **Scallops / Rat-holes:** Standard radius `R35`–`R50` at weld intersections.
  - **Drain / Air holes:** Explicitly called out (`Ø50 DRAIN HOLE`, `R50 AIR HOLE`).
  - **End cuts:** Sniped (`30°` or `45°` snipe with nose height), bracketed, lugged, or collared (`WT COLLAR`).
  - **Green / Excess Material:** `+25 mm EXCESS` or `+50 mm GREEN` at block erection butts/seams where specified for shipwright trim-in-place.

## 4. Welding Symbols (ISO 2553) & Tightness Boundaries
- **SECO Default Weld Sizing:** **Design throat thickness `a`** (e.g., `a5`, `a6`, continuous fillet both sides, or staggered intermittent `a5 100(200)` / chain `a5 100-200`). Leg length `z` (e.g., `z7`) is also supported when explicitly instructed.
- **Full-Penetration Butt Welds:** Indicated per ISO 2553 (`V`, `X`, `K`, or `1/2 V` bevel) with NDT callout where specified (e.g., `100% UT`, `10% RT`).
- **Tightness Classification:** Watertight (`WT`), Oiltight (`OT`), Gastight (`GT`), or Non-tight (`NT`) boundaries must be explicitly tagged on the view; `WT`/`OT` plate boundaries must form closed contours with continuous double-sided welds (`CONT.`).

## 5. Symmetry, Handing & Part-Mark BOM
- **Symmetry:** Where port and starboard are mirror images, draw Starboard (or full width) and annotate **`SYM ABOUT CL`** clearly along the centerline with double short parallel symmetry ticks. Any non-symmetric opening, bracket, or penetration must be tagged **`PORT ONLY`** or **`STBD ONLY`**.
- **Near-Side (`NS`) vs. Far-Side (`FS`) Stiffeners (ISO 128-15):**
  - Stiffeners/webs on the **viewer's side (Near Side)** of a plate are drawn with **continuous solid lines** (`VISIBLE`).
  - Stiffeners/webs welded on the **opposite side behind the plate (Far Side)** are drawn with **dashed lines** (`HIDDEN`) and labeled `FS` where needed.
- **Handing & Part Marks:** Each fabricated piece receives a unique mark (e.g., `<BLOCK>-P01`, `<BLOCK>-S01`). Compartment locations use ISO 128-15 suffixes **`(P)`** Port, **`(S)`** Starboard, **`(C)`** Center.
- **Material List / BOM Columns:**
  `MARK | DESCRIPTION / PROFILE | GRADE | DIMENSIONS (mm) | QTY (P / S / CL / TOT) | UNIT WT (kg) | TOTAL WT (kg) | THROW / TOE`
- **Mass Reconciliation:** Every BOM item's weight is computed deterministically from the Model Space geometry (`net area × thickness × 7.85 t/m³` for plates; `cut length × EN linear mass` for profiles) and verified within `1%` by the linter.

## 6. Voids, Openings & Tank / Leak Testing Plans (ISO 128-15 & IACS UR S14)
- **Void Spaces & Cofferdams — Thin Continuous Diagonal Cross (`X`):**
  - Mark every **Void Space (`VOID` / `V.S.`)**, dry compartment, cofferdam, and deck/bulkhead opening with **two crossing thin continuous diagonal lines (`X`, `0.25 mm`)** on layer `VOID_OPENING` (with a clean text gap around the centered label).
  - **NEVER hatch voids** — hatching represents solid cut steel; crossing diagonals (`X`) distinguish dry/empty voids from active liquid tanks and solid structure immediately on monochrome prints.
- **Tank & Leak Testing Plans (IACS UR S14) — Monochrome Symbol Coding:**
  - Avoid heavy colored fills on leak/tank test plans. Differentiate test regimes using crisp monochrome boundaries, legend tables, and standard UR S14 test codes:
    - **`ST` / `HT`** — Structural / Hydrostatic Test (liquid tanks, specify test head `H`)
    - **`AT`** — Air Test / Leak Test (e.g., `0.15 bar` soap-solution weld check on voids/boundaries)
    - **`HS`** — Hose Test (min `2 bar` nozzle on WT doors, hatches, penetrations)
    - **`VT`** — Vacuum Box Test (plate seams/fillet welds where pressurization is impractical)
    - **`VOID` (`X`)** — Dry void space / cofferdam (thin continuous diagonal cross `X`, exempt from full hydrostatic head unless designated as boundary test)
- **Thin Structural Sections at Hull Scale (ISO 128-50 / 128-15):** When shell plating or profile webs plot narrower than `~2 mm` in cross-section, use solid black fill with a `≥ 0.7 mm` white separation gap between adjacent distinct parts rather than unreadable cross-hatching.
