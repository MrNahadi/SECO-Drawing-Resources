# ISO Engineering Drawing Standards Reference (SECO House Baseline)

This reference encodes the primary ISO technical-drawing rules enforced by `seco-engineering-drawings` (default metric millimetre baseline).

## 1. Units & CAD Database Header
- Linear units: **Millimetres (`mm`)** — `$INSUNITS = 4`, `$MEASUREMENT = 1` (metric `acadiso.lin` / `acadiso.pat`).
- Display precision: decimal (`$LUNITS = 2`), up to 2 decimal places (`$LUPREC = 2`), trailing zeros suppressed in dimensions (`DIMZIN = 8`, e.g., `50`, `50.5`, `50.25`).
- Paper-space linetype scaling: `$PSLTSCALE = 1`, `$LTSCALE = 1.0`, `$CELTSCALE = 1.0`.
- Entity properties: **100% `BYLAYER`** (`color = 256`, `linetype = BYLAYER`, `lineweight = -1`) for all drawing entities.

## 2. Color Discipline, Line Types, Weights & Precedence (ISO 128-2 / 128-20 / 128-24)

### Color Convention (Strict Monochrome Principle)
- **Plotted output is strictly monochrome (black ink on white paper)** via `monochrome.ctb` + object lineweights. Visual hierarchy comes **only** from ISO 128 lineweights and linetypes — **never** from decorative color fills, colored shading, or rainbow linework.
- **Only regulated exceptions where color may be plotted:** SOLAS/IMO Fire Control Plans (ISO 17631), marine piping/P&ID fluid identification (ISO 14726), or explicit revision redline markups. Even on Tank Testing / Leak Test plans, black-and-white symbols (`HT`, `AT`, `HS`, `VT`, diagonal `X` for voids) are the primary convention so monochrome shop/surveyor copies remain 100% legible.
- **Restrained CAD Screen Palette (DWG/DXF):** On screen in AutoCAD, layers stay predominantly monochrome white/gray (`7`, `8`, `9`) with minimal functional accents so drawings never look garish if opened without a CTB:

SECO baseline uses the **ISO 128 `0.5` line group** (`2:1` thick-to-thin ratio), plotted monochrome via `monochrome.ctb` with *Use Object Lineweight = Yes*:

| Semantic Layer | Screen ACI Color | Linetype (`acadiso.lin`) | Plotted Weight | Usage |
| :--- | :---: | :--- | :---: | :--- |
| `VISIBLE` | 7 (White) | `Continuous` | **0.50 mm** | Visible outlines, visible edges, profile contours |
| `CUTTING` | 1 (Red) | `DASHDOT2` | **0.50 mm** | Section cutting-plane lines & arrows |
| `HIDDEN` | 8 (Dark Gray) | `HIDDEN2` | **0.35 mm** | Hidden outlines, hidden edges, far-side (`FS`) stiffeners |
| `CENTER` | 1 (Red) | `CENTER2` | **0.25 mm** | Centerlines, axes of symmetry, pitch circles |
| `DIM` | 4 (Cyan) | `Continuous` | **0.25 mm** | Dimension lines, extension lines, leaders |
| `HATCH` | 8 (Dark Gray) | `Continuous` | **0.25 mm** | Section hatching of **cut solid material only** (ANSI31 45°) |
| `VOID_OPENING` | 8 (Dark Gray) | `Continuous` | **0.25 mm** | Diagonal crossing lines (`X`) for voids, openings, cutouts, flat surfaces (ISO 128 `01.1.3` / `01.1.10`) |
| `PHANTOM` | 8 (Dark Gray) | `PHANTOM2` | **0.25 mm** | Adjacent/reference parts, alternate positions, bend lines |
| `TEXT` | 7 (White) | `Continuous` | **0.25 mm** | View titles, notes, callouts, BOM text |
| `TITLEBLOCK_HEAVY` | 7 (White) | `Continuous` | **0.50 mm** | Inner drawing frame & title block perimeter |
| `TITLEBLOCK` | 7 (White) | `Continuous` | **0.25 mm** | Sheet grid, title block text, projection symbol |
| `VIEWPORT` | 9 (Light Gray) | `Continuous` | **No-plot** | Paper Space viewports (`plot = 0`) |
| `MOLDED_LINE` | 3 (Green) | `PHANTOM2` | **0.25 mm** | Shipbuilding molded lines (`ML`) |
| `FRAME_GRID` | 9 (Light Gray) | `CENTER2` | **0.18 mm** | Ship datum/frame grids (`FR`, `BL`, `CL`, `WL`) |
| `WELD_SYM` | 7 (White) | `Continuous` | **0.25 mm** | ISO 2553 welding symbols & leaders |
| `REV_CLOUD` | 6 (Magenta) | `Continuous` | **0.35 mm** | Revision clouds & revision delta markers |

### Line Precedence (ISO 128-20)
When two lines coincide in a 2D projection, only the highest-precedence line is drawn:
1. Visible outlines (`VISIBLE`)
2. Hidden outlines (`HIDDEN`)
3. Cutting-plane lines (`CUTTING`)
4. Centerlines & axes (`CENTER`)
5. Centroidal / molded lines (`MOLDED_LINE`)
6. Extension & dimension lines (`DIM`)

### Essential ISO 128 Representation Rules (Voids, Hatching, Thin Walls & Breaks)
- **Voids, Openings, Cutouts & Flat Surfaces — Thin Continuous Diagonal Cross (`X`):**
  - Per ISO 128 Basic Line Type **01.1** (`01.1.3` openings/cutouts/recesses; `01.1.10` flat surfaces on cylindrical shafts), mark **openings, cutouts, recesses, void spaces, and wrench flats** with **two crossing thin continuous diagonal lines (`X`, `0.25 mm`)** on layer `VOID_OPENING`.
  - **NEVER hatch a void or empty space.** Hatching (`ANSI31`) exclusively represents *cut solid material*.
- **Longitudinal Ribs, Webs, Stiffeners & Fasteners Are NEVER Hatched (ISO 128-50):**
  - When a cutting plane passes longitudinally through a rib, web, stiffener, bolt, nut, pin, key, or solid shaft, leave it **unhatched** (only hatch transverse cross-sections).
- **Assembly Sections:** Adjacent separate parts cut in the same section must alternate hatch angle (`+45°` / `-45°`) and/or spacing.
- **Thin Sections Solid-Black with White Gap (ISO 128-50):** Plates, gaskets, or thin profile webs narrower than `~2 mm` on paper are filled **solid black** rather than hatched, leaving a **`≥ 0.7 mm` plotted white gap** between touching adjacent thin components so individual parts remain distinguishable.
- **Break Lines (ISO 128-2 Type 01.1):** Shortened long uniform shafts, pipes, or girders use thin continuous (`0.25 mm`) zig-zag long-break or freehand short-break lines.
- **3D STEP Projection Integrity (Anti-Erasure & Complete Pipe/Feature Closure):**
  - Always project `.step` / `.stp` models using **exact analytic B-Rep HLR (`HLRBRep_Algo` + `HLRBRep_HLRToShape` + `BRepLib.BuildCurves3d_s`)** including `VCompound`, `OutLineVCompound`, and `Rg1LineVCompound` — never coarse tessellated `PolyHLR` (which causes Z-fighting erasures where coaming/handrail faces sit flush on decks).
  - **Never length-cull real geometric edges** (`min_len_mm <= 1.0 mm`, `curve_deflection <= 2.5 mm`). Dropping segments longer than `1 mm` deletes pipe end-caps, suction bells, flanges, brackets, and short isometric corners, leaving floating open parallel lines or "erased" geometry.

## 3. Orthographic Projection (ISO 5456-2)
- **SECO Default: First-Angle Projection** (ISO standard). Symbol `ISO_PROJ_FIRST` (truncated cone on left, concentric circles on right) is placed in the title block.
  - **Front View**: Principal view.
  - **Top View (Plan)**: Placed **below** Front View (aligned in `X`).
  - **Left Side View**: Placed **right** of Front View (aligned in `Y`).
  - **Right Side View**: Placed **left** of Front View (aligned in `Y`).
  - **Bottom View**: Placed **above** Front View (aligned in `X`).
- Third-Angle (`ISO_PROJ_THIRD`) is supported per-drawing if explicitly required by a client, with views automatically placed in third-angle positions and `ISO_PROJ_THIRD` inserted on the sheet.

## 4. Preferred Drawing Scales (ISO 5455)
- Full size: `1:1`
- Reduction scales: `1:2`, `1:5`, `1:10`, `1:20`, `1:25`, `1:50`, `1:100`, `1:200`, `1:500`
- Enlargement scales: `2:1`, `5:1`, `10:1`
- Geometry is **always** drawn at `1:1` in Model Space. Scale is controlled solely by Paper Space `VIEWPORT` zoom factor (`paper_height / view_height = num / den`).

## 5. Dimensioning Rules (ISO 129-1)
- Every dimension must be a native associative `DIMENSION` entity on layer `DIM` using `DIMSTYLE = SECO_ISO_MM` (`DIMTXT = 2.5 mm` plotted, `DIMASZ = 2.5 mm`, `DIMEXO = 1.25 mm`, `DIMEXE = 2.0 mm`, `DIMGAP = 1.0 mm`, `DIMTAD = 1`, `DIMTIH = 0`, `DIMTOH = 0`).
- **Clearances (plotted paper mm):**
  - First dimension line ≥ `10 mm` from visible part outline.
  - Parallel stacked dimension lines ≥ `7.5 mm` apart.
  - Dimension text must never overlap visible outlines, hidden lines, centerlines, arrowheads, other dimension text, or the sheet border.
- **Non-redundancy:** Never close a dimension chain unless one dimension is explicitly marked as reference `(XX)`.
- **Truthfulness:** Never override a dimension's measured value to disguise wrong geometry. Measured value must match Model Space geometry within `0.001 mm`.
- **Holes & arcs:** Full circles (`360°`) use `Ø` diameter; arcs (`< 360°`) use `R` radius. Bolt patterns state count × diameter (`4x Ø14 THRU`) plus pitch circle (`PCD Ø120`) or datum coordinates.

## 6. Technical Lettering, Text Positioning, Table Enclosure & Zero-Overlap Rules (ISO 3098 / ISO 129-1)
- **Font:** `ISO_TEXT` (`isocpeur.ttf`, height `0.0` in style definition).
- **Plotted heights on paper:**
  - Standard dimension & note text: **2.5 mm** (minimum legal plotted height on A4–A0)
  - Section labels & callout headings: **3.5 mm**
  - View titles (`FRONT VIEW`, `SECTION A-A`): **3.6–5.0 mm** (underlined)
  - Drawing title in title block: **2.5–5.0 mm** (scaled to sheet & auto-fitted inside cell)

### Mandatory Text Positioning & Zero-Overlap Discipline
1. **Zero text-on-line overlaps:** Text (dimensions, callouts, weld specs, notes, view titles, datum labels) must **never** overlap visible outlines, hidden lines, centerlines, dimension/extension lines, hatching, or borders. When a label must sit inside a void cross (`X`) or hatched area, mask/break the crossing lines cleanly around the text box (`≥ 1.5 mm` paper margin).
2. **Zero text-on-text overlaps:** Maintain `≥ 1.5 mm` plotted whitespace between any two independent text blocks (labels, dimensions, titles, subtitles, notes).
3. **Strict Table Enclosure (BOM, Revision Table, Title Block, Legends):**
   - Every piece of text inside a table must be **strictly enclosed inside its cell** with `≥ 1.5 mm` horizontal and `≥ 0.8 mm` vertical internal clearance — never touching or crossing column dividers or row borders.
   - Auto-size column widths to fit the longest header/value (or wrap onto multiple lines); left-align descriptive text (`DESCRIPTION`, `REMARKS`), center short codes (`MARK`, `GRADE`, `QTY`), and right-align numerical quantities/weights (`UNIT kg`, `TOT kg`).
4. **Clear-Zone Placement by Role:**
   - **Callouts, leaders & weld symbols:** Route outside the part silhouette into clear margins; never cross dimension lines or other leaders.
   - **View titles & scale subtitles:** Center directly below the view and strictly below the lowest bottom dimension row (`≥ 9 mm` paper clearance), with clear separation between underline and `SCALE` subtitle.
   - **Tables (BOM / Schedules):** Anchor in a completely unoccupied corner (`top_right` or `bottom_right`) with **`≥ 5 mm` paper whitespace** separating the table from every view, dimension line, extension line, and callout. If no corner is clear at the current scale, step down one ISO 5455 scale or step up one ISO 5457 sheet size — **never overlap a table with drawing geometry or dimensions**.
   - **Reading orientation (ISO 129-1):** Horizontal text reads left-to-right; rotated vertical text (dimensions or narrow-bay labels) reads bottom-to-top (viewed from the right edge of the sheet) — never upside-down.

## 7. Sheet Sizes, Orientations & Usable Zones (ISO 5457 / SECO Master Template)
- **Landscape (Default):** `A4` (`297 × 210 mm`), `A3` (`420 × 297 mm`), `A2` (`594 × 420 mm`), `A1` (`841 × 594 mm`), `A0` (`1189 × 841 mm`) — full-bleed `DWG To PDF.pc3`. **Landscape is always the default** unless portrait is explicitly requested.
- **Portrait (On Request via `standard.orientation: portrait`):** `A4-P` (`210 × 297 mm`), `A3-P` (`297 × 420 mm`), `A2-P` (`420 × 594 mm`), `A1-P` (`594 × 841 mm`), `A0-P` (`841 × 1189 mm`) — each with ISO 5457 portrait borders, `1`–`6` × `A`–`H` zone grid, attributed `SECO_TBLOCK_<SIZE>-P`, and full-color SECO + SGS ISO 9001 corporate logos.
- Target sheet utilization: views + dimensions occupy roughly `50–70%` of the usable drawing zone (leaving `30–50%` clear whitespace for readability, notes, and BOM).

## 8. General Tolerances (ISO 2768-1 & ISO 2768-2)
- Default note for machined & fabricated parts: **`GENERAL TOLERANCES: ISO 2768-mK`** (medium linear/angular, class K geometrical) unless tighter IT/GD&T tolerances or marine hull tolerances (IACS Rec. 47) are specified.
