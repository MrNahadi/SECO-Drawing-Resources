#!/usr/bin/env python3
"""
Independent 4-Gate Verification Suite for SECO 2D Engineering Drawings.

Gates checked objectively against the final AutoCAD-saved DWG/DXF and plotted PDF:
  Gate 1: Native CAD Integrity (AutoCAD 2027 AUDIT = 0 errors, ezdxf.audit() = 0 errors)
  Gate 2: CAD Standards, Geometry, Alignment, Dimension, Title-Block & Marine Linter
  Gate 3: Plotted PDF Vector Verification via PyMuPDF (paper size, no clipping,
          ISO 128 stroke-width hierarchy, rendered dashed lines, text readability)
  Gate 4: High-resolution rasterization & visual inspection crops (`pdftoppm`)
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import ezdxf
import pymupdf

from cad_core.autocad_bridge import parse_audit_counts, rasterize_and_crop, run_accore
from cad_core.intake import load_spec
from cad_core.standards import (
    APPROVED_LAYERS,
    compute_bom_item_weight_kg,
    parse_scale,
    validate_weld_spec,
)

STALE_TOKENS = ("ALPHA LOGISTIOCS", "ALPHAHEK", "FOUNDATION DETAIL", "---/----/---/---.", "12/03/25")


@dataclass
class CheckResult:
    gate: str
    name: str
    passed: bool
    detail: str


@dataclass
class VerificationReport:
    passed: bool
    checks: List[CheckResult] = field(default_factory=list)
    crops: Dict[str, str] = field(default_factory=dict)

    def add(self, gate: str, name: str, passed: bool, detail: str) -> None:
        self.checks.append(CheckResult(gate=gate, name=name, passed=passed, detail=detail))
        if not passed:
            self.passed = False


def _boxes_overlap(a: List[float], b: List[float], tol: float = -0.2) -> bool:
    return not (a[2] + tol <= b[0] or b[2] + tol <= a[0] or a[3] + tol <= b[1] or b[3] + tol <= a[1])


def verify_drawing(
    dwg_path: Path,
    dxf_path: Path,
    pdf_path: Path,
    manifest_path: Path,
    spec_path: Optional[Path] = None,
    crops_dir: Optional[Path] = None,
) -> VerificationReport:
    report = VerificationReport(passed=True)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    spec = load_spec(spec_path) if spec_path and spec_path.exists() else {}

    # =========================================================================
    # GATE 1: Native CAD Integrity (AutoCAD 2027 AUDIT + ezdxf.audit())
    # =========================================================================
    ac_log = run_accore(dwg_path, ["AUDIT", "Y", "QUIT", "N"], timeout=45)
    ac_err, ac_fix = parse_audit_counts(ac_log)
    report.add(
        "Gate 1: Native CAD",
        "AutoCAD 2027 AUDIT",
        ac_err == 0,
        f"Total errors found={ac_err}, fixed={ac_fix}",
    )

    doc = ezdxf.readfile(str(dxf_path))
    ez_audit = doc.audit()
    report.add(
        "Gate 1: Native CAD",
        "ezdxf.audit()",
        len(ez_audit.errors) == 0,
        f"{len(ez_audit.errors)} errors, {len(ez_audit.fixes)} fixes",
    )

    # =========================================================================
    # GATE 2: Standards, Geometry, Alignment, Dimensions, Title Block & Marine
    # =========================================================================
    # 2a. Header invariants
    hdr_ok = (
        doc.header.get("$INSUNITS") == 4
        and doc.header.get("$MEASUREMENT") == 1
        and doc.header.get("$PSLTSCALE") == 1
        and abs(float(doc.header.get("$LTSCALE", 0.0)) - 1.0) < 1e-6
    )
    report.add(
        "Gate 2: CAD Standards",
        "ISO Metric Header Invariants",
        hdr_ok,
        f"INSUNITS={doc.header.get('$INSUNITS')}, MEASUREMENT={doc.header.get('$MEASUREMENT')}, "
        f"PSLTSCALE={doc.header.get('$PSLTSCALE')}, LTSCALE={doc.header.get('$LTSCALE')}",
    )

    # 2b. Layer & BYLAYER compliance across Model Space & active Paper Space
    sheet = manifest["sheet"]
    lay = doc.layouts.get(sheet)
    msp = doc.modelspace()

    bad_layers = []
    bad_bylayer = []
    for space_name, space in (("Model", msp), (sheet, lay)):
        for e in space:
            if e.dxftype() == "VIEWPORT" and e.dxf.get("id", 0) == 1:
                continue  # root paper space viewport
            lyr = e.dxf.layer
            if lyr not in APPROVED_LAYERS:
                bad_layers.append(f"{space_name}:{e.dxftype()}@{lyr}")
            # Check BYLAYER overrides (color 256, linetype BYLAYER, lineweight -1)
            c = e.dxf.get("color", 256)
            lt = e.dxf.get("linetype", "BYLAYER")
            lw = e.dxf.get("lineweight", -1)
            if c != 256 or str(lt).upper() != "BYLAYER" or lw != -1:
                bad_bylayer.append(f"{space_name}:{e.dxftype()}@{lyr}(c={c},lt={lt},lw={lw})")

    report.add(
        "Gate 2: CAD Standards",
        "Approved Semantic Layers",
        len(bad_layers) == 0,
        "100% approved layers" if not bad_layers else f"{len(bad_layers)} violations: {bad_layers[:5]}",
    )
    report.add(
        "Gate 2: CAD Standards",
        "100% BYLAYER Enforcement",
        len(bad_bylayer) == 0,
        "100% BYLAYER" if not bad_bylayer else f"{len(bad_bylayer)} overrides: {bad_bylayer[:5]}",
    )

    # 2c. Geometric hygiene (zero-length segments, exact duplicates, closed VISIBLE polylines)
    zero_len = 0
    seen_segs = set()
    dup_segs = 0
    open_vis_polys = 0
    for e in msp:
        t = e.dxftype()
        if t == "LINE":
            p1 = (round(e.dxf.start.x, 3), round(e.dxf.start.y, 3))
            p2 = (round(e.dxf.end.x, 3), round(e.dxf.end.y, 3))
            if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-4:
                zero_len += 1
            key = (e.dxf.layer, min(p1, p2), max(p1, p2))
            if key in seen_segs:
                dup_segs += 1
            else:
                seen_segs.add(key)
        elif t == "LWPOLYLINE" and e.dxf.layer == "VISIBLE":
            if not e.closed:
                open_vis_polys += 1

    report.add(
        "Gate 2: Geometry",
        "Zero-Length & Duplicate Line Hygiene",
        zero_len == 0 and dup_segs == 0 and open_vis_polys == 0,
        f"zero_len={zero_len}, duplicates={dup_segs}, open_visible_polylines={open_vis_polys}",
    )

    # 2d. Cross-view orthographic alignment (< 1e-6 mm)
    views_m = manifest.get("views", {})
    align_errs = []
    for vid, vm in views_m.items():
        ref_id = vm.get("align_to")
        if not ref_id or ref_id not in views_m:
            continue
        ref = views_m[ref_id]
        role = vm["role"]
        if role in ("top", "plan", "bottom"):
            err = abs(vm["ox"] - ref["ox"])
            if err > 1e-6:
                align_errs.append(f"{vid}->{ref_id} dX={err:.6f}mm")
        elif role in ("left", "right"):
            err = abs(vm["oy"] - ref["oy"])
            if err > 1e-6:
                align_errs.append(f"{vid}->{ref_id} dY={err:.6f}mm")
    report.add(
        "Gate 2: Geometry",
        "Orthographic Cross-View Alignment (<1e-6 mm)",
        len(align_errs) == 0,
        "All aligned views exact within 1e-6 mm" if not align_errs else "; ".join(align_errs),
    )

    # 2e. Real associative DIMENSION integrity & zero collisions
    dim_entities = [e for e in msp if e.dxftype() == "DIMENSION"]
    manifest_dims = manifest.get("dimensions", [])
    bad_dim_overrides = []
    dim_val_mismatches = []
    for idx, de in enumerate(dim_entities):
        raw_txt = de.dxf.get("text", "")
        if raw_txt and "<>" not in raw_txt:
            bad_dim_overrides.append(f"dim[{idx}] text={raw_txt!r}")
        meas = de.dxf.get("actual_measurement")
        if meas is not None and idx < len(manifest_dims):
            exp = manifest_dims[idx].get("expected_mm")
            if exp is not None and abs(float(meas) - float(exp)) > 0.005:
                dim_val_mismatches.append(f"dim[{idx}]: actual={meas:.3f} vs expected={exp:.3f}")

    # Check dimension text box vs view geometry & inter-dimension overlaps
    dim_overlaps = []
    view_boxes = [(vid, vm["model_bbox"]) for vid, vm in views_m.items()]
    tboxes = [(i, d["text_box"]) for i, d in enumerate(manifest_dims) if "text_box" in d]
    for i, tb in tboxes:
        for vid, vb in view_boxes:
            if _boxes_overlap(tb, vb, tol=-0.1):
                dim_overlaps.append(f"dim[{i}] overlaps view {vid}")
        for j, tb2 in tboxes:
            if j > i and _boxes_overlap(tb, tb2, tol=-0.1):
                dim_overlaps.append(f"dim[{i}] overlaps dim[{j}]")

    report.add(
        "Gate 2: Dimensions",
        "Native Associative DIMENSION Entities (No Faked Overrides)",
        len(dim_entities) == len(manifest_dims) and len(bad_dim_overrides) == 0 and len(dim_val_mismatches) == 0,
        f"count={len(dim_entities)}/{len(manifest_dims)}, bad_overrides={len(bad_dim_overrides)}, mismatches={len(dim_val_mismatches)}",
    )
    report.add(
        "Gate 2: Dimensions",
        "Zero Dimension Text / Geometry Overlaps",
        len(dim_overlaps) == 0,
        "0 overlaps" if not dim_overlaps else f"{len(dim_overlaps)} overlaps: {dim_overlaps[:4]}",
    )

    # 2f. Title block completeness, projection symbol, and VIEWPORT scale match
    stale_found = []
    tb_scale_str = ""
    tb_title = ""
    proj_symbol_found = False
    vp_scale_actual = None

    for e in lay:
        if e.dxftype() == "INSERT":
            if e.dxf.name in ("ISO_PROJ_FIRST", "ISO_PROJ_THIRD"):
                proj_symbol_found = True
            if e.dxf.name.startswith("SECO_TBLOCK_"):
                for att in e.attribs:
                    val = att.dxf.text.strip()
                    if any(tok in val.upper() for tok in STALE_TOKENS):
                        stale_found.append(f"{att.dxf.tag}={val!r}")
                    if att.dxf.tag == "SCALE":
                        tb_scale_str = val
                    if att.dxf.tag == "TITLE":
                        tb_title = val
        elif e.dxftype() == "TEXT":
            val = e.dxf.text.strip().upper()
            if any(tok in val for tok in STALE_TOKENS):
                stale_found.append(f"TEXT={val!r}")
        elif e.dxftype() == "VIEWPORT" and e.dxf.get("id", 0) >= 2:
            if e.dxf.view_height > 0:
                vp_scale_actual = e.dxf.height / e.dxf.view_height

    scale_match = False
    if tb_scale_str and vp_scale_actual is not None:
        declared = parse_scale(tb_scale_str)
        scale_match = abs(vp_scale_actual - declared) / max(declared, 1e-9) < 0.002

    report.add(
        "Gate 2: Title Block",
        "Clean Title Block, ISO Projection Symbol & Viewport Scale Match",
        len(stale_found) == 0 and bool(tb_title) and proj_symbol_found and scale_match,
        f"stale={len(stale_found)}, title={tb_title!r}, proj_sym={proj_symbol_found}, "
        f"declared_scale={tb_scale_str!r}, vp_actual={vp_scale_actual:.5f}" if vp_scale_actual else "missing viewport",
    )

    # 2g. Shipbuilding-specific compliance checks (when active)
    if manifest.get("discipline", "").startswith("shipbuilding") and spec:
        ship_errs = []
        ship_ctx = spec.get("ship_context", {})
        fspace = ship_ctx.get("frame_spacing_mm")
        for v in spec.get("views", []):
            if not v.get("view_direction"):
                ship_errs.append(f"View {v['id']} missing view_direction")
            if not v.get("orientation_marker"):
                ship_errs.append(f"View {v['id']} missing orientation_marker")
            frames = (v.get("frame_grid") or {}).get("frames", [])
            if len(frames) >= 2 and fspace:
                f0 = frames[0]
                for fi in frames[1:]:
                    exp_c = f0["coord"] + (fi["fr"] - f0["fr"]) * fspace
                    if abs(fi["coord"] - exp_c) > 0.5:
                        ship_errs.append(f"FR{fi['fr']} coord mismatch ({fi['coord']} vs {exp_c})")
            for el in v.get("elements", []):
                if el.get("type") == "weld_symbol":
                    w = el.get("arrow_side") or el.get("other_side") or ""
                    if not validate_weld_spec(w):
                        ship_errs.append(f"Invalid ISO 2553 weld {w!r}")

        # Reconcile BOM weights within 1%
        bom_recs = manifest.get("bom_records", [])
        spec_bom = spec.get("bom", [])
        if len(bom_recs) != len(spec_bom):
            ship_errs.append(f"BOM row count mismatch: {len(bom_recs)} vs {len(spec_bom)}")
        else:
            for item, rec in zip(spec_bom, bom_recs):
                exp_u = compute_bom_item_weight_kg(item) or 0.0
                if exp_u > 0 and abs(rec["unit_weight_kg"] - exp_u) / exp_u > 0.01:
                    ship_errs.append(f"BOM {item['mark']} weight drift: {rec['unit_weight_kg']} vs {exp_u}")
                if rec["qty_tot"] != int(item.get("qty_p", 0)) + int(item.get("qty_s", 0)) + int(item.get("qty_cl", 0)):
                    ship_errs.append(f"BOM {item['mark']} P+S+CL qty mismatch")

        report.add(
            "Gate 2: Shipbuilding",
            "Marine View Markers, Frame Grid, ISO 2553 Welds & BOM Weight Reconciliation",
            len(ship_errs) == 0,
            "All shipbuilding checks passed" if not ship_errs else "; ".join(ship_errs[:5]),
        )

    # =========================================================================
    # GATE 3: Plotted PDF Vector Verification (PyMuPDF)
    # =========================================================================
    pdf_doc = pymupdf.open(str(pdf_path))
    page = pdf_doc[0]
    pt_to_mm = 25.4 / 72.0
    pdf_w_mm = page.rect.width * pt_to_mm
    pdf_h_mm = page.rect.height * pt_to_mm
    exp_w = manifest["paper_width_mm"]
    exp_h = manifest["paper_height_mm"]

    size_ok = abs(pdf_w_mm - exp_w) <= 0.6 and abs(pdf_h_mm - exp_h) <= 0.6
    report.add(
        "Gate 3: Plotted PDF",
        "Exact ISO Paper Dimensions",
        size_ok,
        f"PDF={pdf_w_mm:.2f}x{pdf_h_mm:.2f} mm (expected {exp_w:.1f}x{exp_h:.1f} mm)",
    )

    drawings = page.get_drawings()
    rot_mat = page.rotation_matrix
    widths_mm = []
    clipped = 0
    short_dash_segments = 0
    non_mono_drawing_paths = 0
    logo_colored_paths = 0
    color_mode = (spec.get("standard", {}).get("color_mode", "monochrome") if spec else "monochrome")

    # Corporate logo column in center title block (SECO Red/Green logo + SGS Orange/Gray ISO 9001 badge):
    # On A3 (420x297 mm), X in [172, 191] mm, Y_from_bottom in [10, 38] mm (PDF Y is top-down!).
    scale_a3 = exp_w / 420.0
    logo_x0 = (172.0 * scale_a3) / pt_to_mm
    logo_x1 = (191.0 * scale_a3) / pt_to_mm
    logo_y0 = page.rect.height - (38.0 * scale_a3) / pt_to_mm
    logo_y1 = page.rect.height - (10.0 * scale_a3) / pt_to_mm

    def _is_colored(rgb) -> bool:
        if not rgb or len(rgb) < 3:
            return False
        return (max(rgb[:3]) - min(rgb[:3])) > 0.05

    def _in_seco_logo_box(r) -> bool:
        return r is not None and r.x0 >= logo_x0 and r.x1 <= logo_x1 and r.y0 >= logo_y0 and r.y1 <= logo_y1

    for drw in drawings:
        rect = drw.get("rect")
        r_rot = (rect * rot_mat) if rect else None
        if _is_colored(drw.get("color")) or _is_colored(drw.get("fill")):
            if _in_seco_logo_box(r_rot):
                logo_colored_paths += 1
            else:
                non_mono_drawing_paths += 1
        w_pt = drw.get("width")
        if w_pt and w_pt > 0:
            widths_mm.append(round(w_pt * pt_to_mm, 2))
        if r_rot:
            # Allow tiny 2.5 pt tolerance on outer sheet trim line
            if r_rot.x0 < -2.5 or r_rot.y0 < -2.5 or r_rot.x1 > page.rect.width + 2.5 or r_rot.y1 > page.rect.height + 2.5:
                clipped += 1
        # Detect rendered dash strokes (many short 1-5 mm line segments)
        for item in drw.get("items", []):
            if item[0] == "l":
                p1, p2 = item[1], item[2]
                seg_mm = math.hypot(p2.x - p1.x, p2.y - p1.y) * pt_to_mm
                if 1.0 <= seg_mm <= 4.5:
                    short_dash_segments += 1

    unique_w = sorted(set(widths_mm))
    thick_w = max(unique_w) if unique_w else 0.0
    thin_w = min([w for w in unique_w if w >= 0.14], default=0.0)
    hierarchy_ok = (thick_w >= 0.42) and (thin_w > 0) and ((thick_w / thin_w) >= 1.5)

    report.add(
        "Gate 3: Plotted PDF",
        "ISO 128 Monochrome Drawing + Colored SECO Corporate Logo",
        ((color_mode == "functional") or (non_mono_drawing_paths == 0)) and (logo_colored_paths >= 3),
        f"color_mode={color_mode}, non_mono_drawing_paths={non_mono_drawing_paths}, seco_logo_colored_fills={logo_colored_paths}",
    )

    report.add(
        "Gate 3: Plotted PDF",
        "ISO 128 Plotted Stroke-Width Hierarchy (2:1 Thick-to-Thin)",
        hierarchy_ok,
        f"thick={thick_w:.2f}mm, thin={thin_w:.2f}mm, ratio={thick_w / thin_w if thin_w else 0:.2f}, distinct={unique_w}",
    )
    report.add(
        "Gate 3: Plotted PDF",
        "Zero Clipped Geometry Outside Sheet Bounds",
        clipped == 0,
        f"clipped_paths={clipped}, total_vector_paths={len(drawings)}",
    )
    report.add(
        "Gate 3: Plotted PDF",
        "Dashed/Center Linetypes Rendered as Distinct Dashes",
        short_dash_segments >= 8,
        f"short_dash_segments_1_to_4.5mm={short_dash_segments}",
    )

    # Check ISO 3098 text presence, BOM cell text enclosure, and zero text-on-text overlaps in PDF
    tdict = page.get_text("dict")
    text_heights_mm = []
    pdf_text_spans = []  # (text, paper_x0, paper_y0, paper_x1, paper_y1)
    for blk in tdict.get("blocks", []):
        for ln in blk.get("lines", []):
            for sp in ln.get("spans", []):
                txt = sp.get("text", "").strip()
                if txt:
                    text_heights_mm.append(round(sp["size"] * pt_to_mm, 2))
                    rb = pymupdf.Rect(sp["bbox"]) * rot_mat
                    # Convert rotated top-down pt bbox -> bottom-up paper mm
                    px0 = rb.x0 * pt_to_mm
                    px1 = rb.x1 * pt_to_mm
                    py0 = pdf_h_mm - rb.y1 * pt_to_mm
                    py1 = pdf_h_mm - rb.y0 * pt_to_mm
                    pdf_text_spans.append((txt, px0, py0, px1, py1))

    max_txt_mm = max(text_heights_mm) if text_heights_mm else 0.0
    report.add(
        "Gate 3: Plotted PDF",
        "ISO 3098 Plotted Text Readability",
        len(text_heights_mm) > 0 and max_txt_mm >= 2.5,
        f"text_spans={len(text_heights_mm)}, min={min(text_heights_mm) if text_heights_mm else 0:.2f}mm, max={max_txt_mm:.2f}mm",
    )

    # 3e. Strict BOM Table Cell Enclosure & Zero Foreign Lines Crossing BOM Table
    bom_box = manifest.get("bom_box_paper")
    bom_cells = manifest.get("bom_cells_paper") or []
    cell_overflows = []
    foreign_bom_crossings = 0
    if bom_box:
        bx0, by0, bx1, by1 = bom_box
        # Check rendered PDF text spans inside BOM against their cell boundaries
        if bom_cells:
            for txt, sx0, sy0, sx1, sy1 in pdf_text_spans:
                scx, scy = (sx0 + sx1) / 2.0, (sy0 + sy1) / 2.0
                if bx0 <= scx <= bx1 and by0 <= scy <= by1:
                    # Find containing cell by center point
                    matched = None
                    for cell in bom_cells:
                        cx0, cy0, cx1, cy1 = cell["box"]
                        if cx0 - 0.5 <= scx <= cx1 + 0.5 and cy0 - 0.5 <= scy <= cy1 + 0.5:
                            matched = cell
                            break
                    if matched:
                        cx0, cy0, cx1, cy1 = matched["box"]
                        if sx0 < cx0 + 0.1 or sx1 > cx1 - 0.1:
                            cell_overflows.append(
                                f"{matched['col']}:{txt!r} span=[{sx0:.1f},{sx1:.1f}] vs cell=[{cx0:.1f},{cx1:.1f}]"
                            )

        # Check rendered PDF vector lines for any foreign line entering BOM from outside
        from shapely.geometry import LineString, box as shp_box
        bom_inner = shp_box(bx0 + 0.8, by0 + 0.8, bx1 - 0.8, by1 - 0.8)
        bom_outer = shp_box(bx0 - 1.2, by0 - 1.2, bx1 + 1.2, by1 + 1.2)
        for drw in drawings:
            for item in drw.get("items", []):
                if item[0] == "l":
                    p1 = item[1] * rot_mat
                    p2 = item[2] * rot_mat
                    a = (p1.x * pt_to_mm, pdf_h_mm - p1.y * pt_to_mm)
                    b = (p2.x * pt_to_mm, pdf_h_mm - p2.y * pt_to_mm)
                    ls = LineString([a, b])
                    # Foreign crossing = intersects strict interior AND extends outside BOM perimeter
                    if ls.intersects(bom_inner) and not bom_outer.contains(ls):
                        foreign_bom_crossings += 1

        report.add(
            "Gate 3: Plotted PDF",
            "Strict Table Cell Text Enclosure (Zero Cell Overflow)",
            len(cell_overflows) == 0,
            "All BOM text strictly enclosed in cells" if not cell_overflows else f"{len(cell_overflows)} overflows: {cell_overflows[:3]}",
        )
        report.add(
            "Gate 3: Plotted PDF",
            "Zero Foreign Lines/Dimensions Crossing BOM Table",
            foreign_bom_crossings == 0,
            f"foreign_lines_crossing_bom={foreign_bom_crossings}",
        )

    # 3f. Zero Text-on-Text Overlaps in the Drawing Area (above title block)
    tblock_top_mm = 38.0 * scale_a3
    drawing_spans = [s for s in pdf_text_spans if s[2] >= tblock_top_mm]
    text_overlaps = []
    for i in range(len(drawing_spans)):
        t1, ax0, ay0, ax1, ay1 = drawing_spans[i]
        a_area = max(1e-6, (ax1 - ax0) * (ay1 - ay0))
        for j in range(i + 1, len(drawing_spans)):
            t2, bx0_, by0_, bx1_, by1_ = drawing_spans[j]
            ix = max(0.0, min(ax1, bx1_) - max(ax0, bx0_))
            iy = max(0.0, min(ay1, by1_) - max(ay0, by0_))
            if ix > 0.2 and iy > 0.2:
                b_area = max(1e-6, (bx1_ - bx0_) * (by1_ - by0_))
                # Ignore tiny font-ascender touches between fragments of the same line
                if (ix * iy) / min(a_area, b_area) > 0.20:
                    text_overlaps.append(f"{t1!r} <-> {t2!r}")

    report.add(
        "Gate 3: Plotted PDF",
        "Zero Text-on-Text Overlaps in Drawing Area",
        len(text_overlaps) == 0,
        "0 text-on-text overlaps" if not text_overlaps else f"{len(text_overlaps)} overlaps: {text_overlaps[:4]}",
    )
    pdf_doc.close()

    # =========================================================================
    # GATE 4: Rasterize & Produce Visual Inspection Crops (`pdftoppm`)
    # =========================================================================
    if crops_dir is not None:
        crops = rasterize_and_crop(pdf_path, crops_dir, dpi=200)
        report.crops = {k: str(v) for k, v in crops.items()}
        report.add(
            "Gate 4: Visual Crops",
            "Rasterized Sheet & Detail Crops Generated",
            all(Path(p).exists() for p in report.crops.values()),
            f"generated={list(report.crops.keys())}",
        )

    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify a generated SECO 2D engineering drawing.")
    parser.add_argument("--dwg", type=Path, required=True)
    parser.add_argument("--dxf", type=Path, required=True)
    parser.add_argument("--pdf", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--spec", type=Path, default=None)
    parser.add_argument("--crops-dir", type=Path, default=None)
    parser.add_argument("--json-out", type=Path, default=None)
    args = parser.parse_args()

    rep = verify_drawing(args.dwg, args.dxf, args.pdf, args.manifest, args.spec, args.crops_dir)
    for c in rep.checks:
        tag = "PASS" if c.passed else "FAIL"
        print(f"[{tag}] {c.gate} | {c.name}: {c.detail}")

    if args.json_out:
        args.json_out.write_text(json.dumps(asdict(rep), indent=2), encoding="utf-8")

    print(f"\nOVERALL VERIFICATION: {'PASSED' if rep.passed else 'FAILED'}")
    return 0 if rep.passed else 2


if __name__ == "__main__":
    sys.exit(main())
