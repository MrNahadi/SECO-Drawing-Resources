"""
OpenCASCADE (OCP) 3D STEP B-Rep Projection & Planar Cross-Section Engine.

Extracts exact 1:1 mm 2D CAD linework directly from `.step` / `.stp` 3D models:
  - Exact analytic B-Rep Hidden-Line Removal (`HLRBRep_Algo` + `HLRBRep_HLRToShape`)
    to eliminate triangle-mesh Z-fighting erasures on coplanar/touching faces
  - Preserves ALL real geometric edges (`min_len_mm <= 1.0 mm`, fine curve discretization)
    so pipe end-caps, suction bells, flanges, and hatch coamings are NEVER broken or erased
  - Exact 3D planar cross-sections (`BRepAlgoAPI_Section`) + half-space background HLR
  - 3D half-model cutaway isometric projections
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import List, Optional, Tuple

from OCP.Bnd import Bnd_Box
from OCP.BRep import BRep_Builder
from OCP.BRepAdaptor import BRepAdaptor_Curve
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common, BRepAlgoAPI_Section
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepLib import BRepLib
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.GCPnts import GCPnts_QuasiUniformDeflection
from OCP.GeomAbs import GeomAbs_Line
from OCP.gp import gp_Ax2, gp_Dir, gp_Pln, gp_Pnt
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import (
    HLRBRep_Algo,
    HLRBRep_HLRToShape,
    HLRBRep_PolyAlgo,
    HLRBRep_PolyHLRToShape,
)
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_EDGE, TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS, TopoDS_Compound, TopoDS_Shape

Segment2D = Tuple[Tuple[float, float], Tuple[float, float]]


def load_step_shape(step_path: Path, mesh_deflection: float = 5.0) -> TopoDS_Shape:
    """Load a STEP B-Rep model (with fine triangulation only as PolyHLR fallback)."""
    reader = STEPControl_Reader()
    status = reader.ReadFile(str(step_path))
    if int(status) != 1:
        raise RuntimeError(f"Failed to read STEP file: {step_path} (status={status})")
    reader.TransferRoots()
    shape = reader.OneShape()
    if mesh_deflection > 0:
        BRepMesh_IncrementalMesh(shape, mesh_deflection, False, 0.15, True)
    return shape


def get_shape_bbox(shape: TopoDS_Shape) -> Tuple[float, float, float, float, float, float]:
    bb = Bnd_Box()
    BRepBndLib.AddOptimal_s(shape, bb, False, False)
    p0, p1 = bb.CornerMin(), bb.CornerMax()
    return (p0.X(), p0.Y(), p0.Z(), p1.X(), p1.Y(), p1.Z())


def _extract_2d_segments_from_compound(
    comp: Optional[TopoDS_Shape],
    min_len_mm: float = 0.5,
    quant_mm: float = 0.25,
    curve_deflection: float = 2.0,
) -> List[Segment2D]:
    """
    Convert an OpenCASCADE 2D HLR compound (in XY plane) into clean deduplicated 2D segments.
    NEVER length-culls real geometry: `min_len_mm` stays <= 1.0 mm so pipe end-caps,
    flanges, coaming corners, and fine curved arcs remain 100% intact.
    """
    if comp is None or comp.IsNull():
        return []
    # Analytic HLRBRep_HLRToShape emits 2D pcurves; build 3D curves before BRepAdaptor_Curve!
    try:
        BRepLib.BuildCurves3d_s(comp)
    except Exception:
        pass

    seen = set()
    segs: List[Segment2D] = []
    exp = TopExp_Explorer(comp, TopAbs_EDGE)
    while exp.More():
        edge = TopoDS.Edge(exp.Current())
        try:
            adaptor = BRepAdaptor_Curve(edge)
            ctype = adaptor.GetType()
            if ctype == GeomAbs_Line:
                p0 = adaptor.Value(adaptor.FirstParameter())
                p1 = adaptor.Value(adaptor.LastParameter())
                pts = [(p0.X(), p0.Y()), (p1.X(), p1.Y())]
            else:
                disc = GCPnts_QuasiUniformDeflection(adaptor, curve_deflection)
                if disc.IsDone() and disc.NbPoints() >= 2:
                    pts = [(disc.Value(i).X(), disc.Value(i).Y()) for i in range(1, disc.NbPoints() + 1)]
                else:
                    # Uniform fallback for small circles/arcs (e.g. pipe ends) so they NEVER disappear
                    u0, u1 = adaptor.FirstParameter(), adaptor.LastParameter()
                    n_pts = 16
                    pts = [
                        (adaptor.Value(u0 + (u1 - u0) * k / n_pts).X(), adaptor.Value(u0 + (u1 - u0) * k / n_pts).Y())
                        for k in range(n_pts + 1)
                    ]
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                if math.hypot(b[0] - a[0], b[1] - a[1]) < min_len_mm:
                    continue
                qa = (round(a[0] / quant_mm), round(a[1] / quant_mm))
                qb = (round(b[0] / quant_mm), round(b[1] / quant_mm))
                if qa == qb:
                    continue
                key = (qa, qb) if qa < qb else (qb, qa)
                if key not in seen:
                    seen.add(key)
                    segs.append((a, b))
        except Exception:
            pass
        exp.Next()
    return segs


def _merge_unique_segments(groups: List[List[Segment2D]], quant_mm: float = 0.25) -> List[Segment2D]:
    seen = set()
    out: List[Segment2D] = []
    for segs in groups:
        for a, b in segs:
            qa = (round(a[0] / quant_mm), round(a[1] / quant_mm))
            qb = (round(b[0] / quant_mm), round(b[1] / quant_mm))
            key = (qa, qb) if qa < qb else (qb, qa)
            if key not in seen:
                seen.add(key)
                out.append((a, b))
    return out


def project_hlr_segments(
    shape: TopoDS_Shape,
    eye_dir: Tuple[float, float, float],
    x_dir: Tuple[float, float, float],
    min_len_mm: float = 0.5,
    include_outline: bool = True,
    include_hidden: bool = False,
    quant_mm: float = 0.25,
    curve_deflection: float = 2.0,
    analytic: bool = True,
) -> Tuple[List[Segment2D], List[Segment2D]]:
    """
    Project `shape` looking from `+eye_dir` toward origin with horizontal 2D X axis
    along `x_dir`. Uses exact analytic `HLRBRep_Algo` by default (zero mesh Z-fighting
    erasures on touching faces and exact pipe/cylinder end caps), with automatic fallback
    to fine `HLRBRep_PolyAlgo` if needed.
    """
    # Guard against accidental destructive length culling
    safe_min_len = min(float(min_len_mm), 1.0)
    ax = gp_Ax2(
        gp_Pnt(0.0, 0.0, 0.0),
        gp_Dir(eye_dir[0], eye_dir[1], eye_dir[2]),
        gp_Dir(x_dir[0], x_dir[1], x_dir[2]),
    )
    proj = HLRAlgo_Projector(ax)

    vis_groups: List[List[Segment2D]] = []
    hid: List[Segment2D] = []

    used_analytic = False
    if analytic:
        try:
            hlr = HLRBRep_Algo()
            hlr.Add(shape)
            hlr.Projector(proj)
            hlr.Update()
            hlr.Hide()
            hlr_shapes = HLRBRep_HLRToShape(hlr)
            vis_groups.append(
                _extract_2d_segments_from_compound(
                    hlr_shapes.VCompound(), min_len_mm=safe_min_len, quant_mm=quant_mm, curve_deflection=curve_deflection
                )
            )
            if include_outline:
                vis_groups.append(
                    _extract_2d_segments_from_compound(
                        hlr_shapes.OutLineVCompound(),
                        min_len_mm=safe_min_len,
                        quant_mm=quant_mm,
                        curve_deflection=curve_deflection,
                    )
                )
                vis_groups.append(
                    _extract_2d_segments_from_compound(
                        hlr_shapes.Rg1LineVCompound(),
                        min_len_mm=safe_min_len,
                        quant_mm=quant_mm,
                        curve_deflection=curve_deflection,
                    )
                )
            if include_hidden:
                hid = _extract_2d_segments_from_compound(
                    hlr_shapes.HCompound(), min_len_mm=safe_min_len, quant_mm=quant_mm, curve_deflection=curve_deflection
                )
            used_analytic = True
        except Exception:
            used_analytic = False

    if not used_analytic:
        poly_hlr = HLRBRep_PolyAlgo(shape)
        poly_hlr.Projector(proj)
        poly_hlr.Update()
        hlr_shapes = HLRBRep_PolyHLRToShape()
        hlr_shapes.Update(poly_hlr)
        vis_groups.append(
            _extract_2d_segments_from_compound(
                hlr_shapes.VCompound(), min_len_mm=safe_min_len, quant_mm=quant_mm, curve_deflection=curve_deflection
            )
        )
        if include_outline:
            vis_groups.append(
                _extract_2d_segments_from_compound(
                    hlr_shapes.OutLineVCompound(),
                    min_len_mm=safe_min_len,
                    quant_mm=quant_mm,
                    curve_deflection=curve_deflection,
                )
            )
        if include_hidden:
            hid = _extract_2d_segments_from_compound(
                hlr_shapes.HCompound(), min_len_mm=safe_min_len, quant_mm=quant_mm, curve_deflection=curve_deflection
            )

    return _merge_unique_segments(vis_groups, quant_mm=quant_mm), hid


def slice_planar_section(
    shape: TopoDS_Shape,
    origin: Tuple[float, float, float],
    normal: Tuple[float, float, float],
    u_axis: Tuple[float, float, float],
    v_axis: Tuple[float, float, float],
    min_len_mm: float = 0.5,
    quant_mm: float = 0.25,
    curve_deflection: float = 2.0,
) -> List[Segment2D]:
    """
    Slice `shape` with an exact 3D plane at `origin` with unit `normal`, and project
    the exact cut edges into 2D `(u, v)` coordinates relative to `origin`.
    """
    safe_min_len = min(float(min_len_mm), 1.0)
    pln = gp_Pln(gp_Pnt(*origin), gp_Dir(*normal))
    sec = BRepAlgoAPI_Section(shape, pln, False)
    sec.Approximation(True)
    sec.Build()
    res = sec.Shape()

    ox, oy, oz = origin
    ux, uy, uz = u_axis
    vx, vy, vz = v_axis
    umag = math.sqrt(ux * ux + uy * uy + uz * uz)
    vmag = math.sqrt(vx * vx + vy * vy + vz * vz)
    ux, uy, uz = ux / umag, uy / umag, uz / umag
    vx, vy, vz = vx / vmag, vy / vmag, vz / vmag

    def _to_uv(p: gp_Pnt) -> Tuple[float, float]:
        dx, dy, dz = p.X() - ox, p.Y() - oy, p.Z() - oz
        return (dx * ux + dy * uy + dz * uz, dx * vx + dy * vy + dz * vz)

    seen = set()
    segs: List[Segment2D] = []
    exp = TopExp_Explorer(res, TopAbs_EDGE)
    while exp.More():
        edge = TopoDS.Edge(exp.Current())
        try:
            adaptor = BRepAdaptor_Curve(edge)
            if adaptor.GetType() == GeomAbs_Line:
                pts = [_to_uv(adaptor.Value(adaptor.FirstParameter())), _to_uv(adaptor.Value(adaptor.LastParameter()))]
            else:
                disc = GCPnts_QuasiUniformDeflection(adaptor, curve_deflection)
                if disc.IsDone() and disc.NbPoints() >= 2:
                    pts = [_to_uv(disc.Value(i)) for i in range(1, disc.NbPoints() + 1)]
                else:
                    u0, u1 = adaptor.FirstParameter(), adaptor.LastParameter()
                    pts = [_to_uv(adaptor.Value(u0 + (u1 - u0) * k / 16)) for k in range(17)]
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                if math.hypot(b[0] - a[0], b[1] - a[1]) < safe_min_len:
                    continue
                qa = (round(a[0] / quant_mm), round(a[1] / quant_mm))
                qb = (round(b[0] / quant_mm), round(b[1] / quant_mm))
                if qa == qb:
                    continue
                key = (qa, qb) if qa < qb else (qb, qa)
                if key not in seen:
                    seen.add(key)
                    segs.append((a, b))
        except Exception:
            pass
        exp.Next()
    return segs


def clip_shape_halfspace(
    shape: TopoDS_Shape,
    axis: str,
    limit: float,
    keep: str = "less",
    mesh_deflection: float = 5.0,
) -> TopoDS_Shape:
    """
    Fast half-space clip of a multi-solid assembly along `axis` ('x', 'y', or 'z'):
      - Keeps solids fully on the desired side intact (zero boolean cost)
      - Drops solids fully on the discarded side
      - Clips ONLY straddling solids cleanly via BRepAlgoAPI_Common
    """
    xmin, ymin, zmin, xmax, ymax, zmax = get_shape_bbox(shape)
    pad = 5000.0
    bx0, by0, bz0 = xmin - pad, ymin - pad, zmin - pad
    bx1, by1, bz1 = xmax + pad, ymax + pad, zmax + pad

    if axis == "x":
        if keep == "less":
            bx1 = limit
        else:
            bx0 = limit
    elif axis == "y":
        if keep == "less":
            by1 = limit
        else:
            by0 = limit
    elif axis == "z":
        if keep == "less":
            bz1 = limit
        else:
            bz0 = limit

    clip_box = BRepPrimAPI_MakeBox(gp_Pnt(bx0, by0, bz0), gp_Pnt(bx1, by1, bz1)).Shape()
    builder = BRep_Builder()
    comp = TopoDS_Compound()
    builder.MakeCompound(comp)

    idx_axis = {"x": 0, "y": 1, "z": 2}[axis]
    exp = TopExp_Explorer(shape, TopAbs_SOLID)
    while exp.More():
        solid = exp.Current()
        sbb = get_shape_bbox(solid)
        lo, hi = sbb[idx_axis], sbb[idx_axis + 3]
        if keep == "less":
            if hi <= limit + 1.0:
                builder.Add(comp, solid)
            elif lo < limit - 1.0:
                try:
                    cut = BRepAlgoAPI_Common(solid, clip_box)
                    cut.Build()
                    if cut.IsDone() and not cut.Shape().IsNull():
                        builder.Add(comp, cut.Shape())
                except Exception:
                    builder.Add(comp, solid)
        else:
            if lo >= limit - 1.0:
                builder.Add(comp, solid)
            elif hi > limit + 1.0:
                try:
                    cut = BRepAlgoAPI_Common(solid, clip_box)
                    cut.Build()
                    if cut.IsDone() and not cut.Shape().IsNull():
                        builder.Add(comp, cut.Shape())
                except Exception:
                    builder.Add(comp, solid)
        exp.Next()

    if mesh_deflection > 0:
        BRepMesh_IncrementalMesh(comp, mesh_deflection, False, 0.15, True)
    return comp


def segments_bbox(segs: List[Segment2D]) -> Tuple[float, float, float, float]:
    xs = [p[0] for seg in segs for p in seg]
    ys = [p[1] for seg in segs for p in seg]
    if not xs:
        return (0.0, 0.0, 100.0, 100.0)
    return (min(xs), min(ys), max(xs), max(ys))
