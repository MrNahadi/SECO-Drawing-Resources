"""
Sheet & ISO 5455 scale solver, Paper Space VIEWPORT composer, and attributed
SECO title-block populator.
"""

from __future__ import annotations

import datetime
import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

import ezdxf
from ezdxf import bbox

from .dimensioner import render_view_dimensions
from .marine import compute_bom_layout_paperspace, draw_bom_table_paperspace, render_marine_view_overlays
from .projector import (
    ViewPlacement,
    compute_view_local_bbox,
    layout_views_iso,
    render_view_geometry,
    render_view_title,
)
from .standards import ISO_SCALES, SHEET_ORDER, parse_scale

SKILL_ROOT = Path(__file__).resolve().parents[2]
MASTER_DXF = SKILL_ROOT / "templates" / "Seco_master_ISO.dxf"
AUDIT_JSON = SKILL_ROOT / "templates" / "template_audit.json"


def _estimate_model_span(views: List[Dict], projection: str) -> Tuple[float, float]:
    """Quick geometry-only span estimate to pick initial ISO sheet & scale."""
    max_dim = 100.0
    for v in views:
        b = compute_view_local_bbox(v)
        max_dim = max(max_dim, b[2] - b[0], b[3] - b[1])
    pls = layout_views_iso(views, projection=projection, gap_model=max_dim * 0.45)
    xs = [p.model_bbox[0] for p in pls.values()] + [p.model_bbox[2] for p in pls.values()]
    ys = [p.model_bbox[1] for p in pls.values()] + [p.model_bbox[3] for p in pls.values()]
    return (max(xs) - min(xs), max(ys) - min(ys))


def select_sheet_and_scale(
    spec: Dict,
    audit_meta: Dict,
    model_w: float,
    model_h: float,
    has_bom: bool,
) -> Tuple[str, str, float]:
    """
    Pick the best ISO 5457 sheet (A4..A0) and ISO 5455 preferred scale so the
    views + dimensions + BOM occupy ~55-82% of the usable area with clean margins.
    """
    std = spec.get("standard", {})
    pref_sheet = std.get("preferred_sheet", "AUTO")
    pref_scale = std.get("preferred_scale")

    # Reserve extra paper margin for dimensions, view titles, frame bubbles, and BOM
    pad_w_paper = 75.0 + (155.0 if has_bom else 0.0)
    pad_h_paper = 75.0

    candidate_sheets = [pref_sheet] if pref_sheet in SHEET_ORDER else ["A3", "A2", "A1", "A0", "A4"]
    if pref_sheet == "AUTO":
        # Prefer A3 first for single parts/sub-assemblies, escalate to A2/A1/A0 if needed
        candidate_sheets = ["A3", "A2", "A1", "A0"]

    candidate_scales = (
        [(pref_scale, parse_scale(pref_scale))] if pref_scale else ISO_SCALES
    )

    if pref_scale:
        sh = pref_sheet if pref_sheet in SHEET_ORDER else "A3"
        return (sh, pref_scale, parse_scale(pref_scale))

    for sh in candidate_sheets:
        uz = audit_meta["sheets"][sh]["usable_zone_mm"]
        avail_w = uz["width"] - pad_w_paper
        avail_h = uz["height"] - pad_h_paper
        if avail_w <= 60.0 or avail_h <= 60.0:
            continue
        # Pick the LARGEST standard scale that fits cleanly inside avail_w x avail_h
        for label, ratio in candidate_scales:
            if model_w * ratio <= avail_w and model_h * ratio <= avail_h:
                return (sh, label, ratio)

    # Fallback: A0 smallest fitting scale
    sh = candidate_sheets[-1]
    uz = audit_meta["sheets"][sh]["usable_zone_mm"]
    for label, ratio in ISO_SCALES:
        if model_w * ratio <= uz["width"] * 0.85 and model_h * ratio <= uz["height"] * 0.85:
            return (sh, label, ratio)
    return (sh, "1:500", 0.002)


def compose_drawing(spec: Dict, out_pre_dxf: Path) -> Dict:
    """
    Build the complete 1:1 Model Space + Paper Space DXF from `Seco_master_ISO.dxf`
    and return a rich manifest for downstream AutoCAD finalization and verification.
    """
    audit_meta = json.loads(AUDIT_JSON.read_text(encoding="utf-8"))
    std = spec.get("standard", {})
    projection = std.get("projection", "first-angle")
    is_ship = spec.get("discipline", "").startswith("shipbuilding")
    bom = spec.get("bom", [])
    views = spec["views"]

    est_w, est_h = _estimate_model_span(views, projection)
    sheet, scale_label, scale_ratio = select_sheet_and_scale(spec, audit_meta, est_w, est_h, has_bom=bool(bom))

    # Iterative fit loop: build at chosen scale; if full annotated extent overflows viewport, step down one ISO scale
    scale_idx = next((i for i, (lbl, _) in enumerate(ISO_SCALES) if lbl == scale_label), 3)
    final_manifest: Dict = {}

    for _attempt in range(5):
        doc = ezdxf.readfile(str(MASTER_DXF))
        msp = doc.modelspace()
        inv_s = 1.0 / scale_ratio

        # Inter-view gap = 46 mm plotted (58 mm for shipbuilding so frame/CL/titles never crowd)
        gap_model = (58.0 if is_ship else 46.0) * inv_s
        placements = layout_views_iso(views, projection=projection, gap_model=gap_model)

        occupied_boxes: List[Tuple[float, float, float, float]] = []
        dim_records: List[Dict] = []

        for v in views:
            pl = placements[v["id"]]
            marine_els = render_view_geometry(msp, v, pl, scale_ratio, occupied_boxes)
            if is_ship or marine_els:
                render_marine_view_overlays(msp, v, pl, marine_els, scale_ratio, occupied_boxes)
            dim_low_y = render_view_dimensions(msp, v, pl, scale_ratio, occupied_boxes, dim_records)
            render_view_title(msp, v, pl, scale_ratio, scale_label, dim_low_y, occupied_boxes)

        # Compute full Model Space bounding box (geometry + dimensions + titles + frame bubbles)
        ext = bbox.extents(msp, fast=True)
        if not ext.has_data:
            raise RuntimeError("No geometry was generated in Model Space.")
        m_minx, m_miny = float(ext.extmin.x), float(ext.extmin.y)
        m_maxx, m_maxy = float(ext.extmax.x), float(ext.extmax.y)
        full_w_paper = (m_maxx - m_minx) * scale_ratio
        full_h_paper = (m_maxy - m_miny) * scale_ratio

        sh_meta = audit_meta["sheets"][sheet]
        uz = sh_meta["usable_zone_mm"]
        lay = doc.layouts.get(sheet)

        # Determine viewport region first, then choose the BOM corner (`bottom_right` vs `top_right`)
        # that has ZERO overlap with any projected Model Space view + dimension box!
        vp_xmin = uz["xmin"] + 3.0
        vp_ymin = uz["ymin"] + 3.0
        vp_xmax = uz["xmax"] - 3.0
        vp_ymax = uz["ymax"] - 3.0
        vp_w = vp_xmax - vp_xmin
        vp_h = vp_ymax - vp_ymin

        fits = (full_w_paper <= vp_w * 0.96) and (full_h_paper <= vp_h * 0.96)
        if not fits and not std.get("preferred_scale") and scale_idx + 1 < len(ISO_SCALES):
            scale_idx += 1
            scale_label, scale_ratio = ISO_SCALES[scale_idx]
            continue

        # Project Model Space occupied boxes into Paper Space to test BOM corner collisions
        vp_cx = (vp_xmin + vp_xmax) / 2.0
        vp_cy = (vp_ymin + vp_ymax) / 2.0
        model_cx = (m_minx + m_maxx) / 2.0
        model_cy = (m_miny + m_maxy) / 2.0

        # Collect ALL Model Space ink footprints (views + callouts + titles + FULL dimension lines/ext lines!)
        all_model_boxes = list(occupied_boxes)
        for dr in dim_records:
            if "full_box" in dr:
                all_model_boxes.append(tuple(dr["full_box"]))

        def _model_to_paper_box(mb, vc_x, vc_y, mc_x, mc_y):
            return (
                vc_x + (mb[0] - mc_x) * scale_ratio,
                vc_y + (mb[1] - mc_y) * scale_ratio,
                vc_x + (mb[2] - mc_x) * scale_ratio,
                vc_y + (mb[3] - mc_y) * scale_ratio,
            )

        def _overlaps_any(box, boxes, pad=5.0):
            return any(
                not (box[2] + pad <= b[0] or b[2] + pad <= box[0] or box[3] + pad <= b[1] or b[3] + pad <= box[1])
                for b in boxes
            )

        bom_box = None
        bom_records: List[Dict] = []
        bom_cells: List[Dict] = []
        bom_collision = False

        if bom:
            bom_info = compute_bom_layout_paperspace(
                bom, sh_meta["scale_vs_a3"], is_ship, max_table_w=uz["width"] * 0.56
            )
            est_bom_w = bom_info["total_w"]
            est_bom_h = bom_info["total_h"]
            tr_box = (uz["xmax"] - 2.0 - est_bom_w, uz["ymax"] - 2.0 - est_bom_h, uz["xmax"] - 2.0, uz["ymax"] - 2.0)
            br_box = (uz["xmax"] - 2.0 - est_bom_w, uz["ymin"] + 2.0, uz["xmax"] - 2.0, uz["ymin"] + 2.0 + est_bom_h)

            chosen_corner = None
            # Strategy 1: Views fit completely LEFT of the BOM column (strictly non-overlapping viewport!)
            if full_w_paper + est_bom_w + 14.0 <= vp_w:
                vp_xmax = uz["xmax"] - est_bom_w - 7.0
                vp_w = vp_xmax - vp_xmin
                vp_cx = (vp_xmin + vp_xmax) / 2.0
                chosen_corner = "top_right"
            else:
                # Strategy 2: Test candidate horizontal/vertical shifts inside full viewport for ZERO overlap (>= 5mm pad)
                max_shift_x = max(0.0, (vp_w - full_w_paper) / 2.0 - 3.0)
                max_shift_y = max(0.0, (vp_h - full_h_paper) / 2.0 - 3.0)
                # Shift model left (+dx in model_cx) and/or up (-dy in model_cy) to open right corners
                candidate_shifts = [
                    (0.0, 0.0),
                    (max_shift_x, 0.0),
                    (max_shift_x, -max_shift_y),
                    (max_shift_x, max_shift_y),
                    (0.0, -max_shift_y),
                    (0.0, max_shift_y),
                ]
                for corner_name, cbox in (("top_right", tr_box), ("bottom_right", br_box)):
                    for sx_paper, sy_paper in candidate_shifts:
                        cand_mcx = model_cx + sx_paper / scale_ratio
                        cand_mcy = model_cy + sy_paper / scale_ratio
                        paper_occ = [_model_to_paper_box(ob, vp_cx, vp_cy, cand_mcx, cand_mcy) for ob in all_model_boxes]
                        if not _overlaps_any(cbox, paper_occ, pad=5.0):
                            model_cx, model_cy = cand_mcx, cand_mcy
                            chosen_corner = corner_name
                            break
                    if chosen_corner:
                        break

                if not chosen_corner:
                    # Neither corner is clear of full geometry + dimension lines at this scale -> must step down!
                    bom_collision = True

            if bom_collision and scale_idx + 1 < len(ISO_SCALES):
                scale_idx += 1
                scale_label, scale_ratio = ISO_SCALES[scale_idx]
                continue

            bx0, by0, bx1, by1, bom_records, bom_cells = draw_bom_table_paperspace(
                lay, bom, uz, sh_meta["scale_vs_a3"], is_shipbuilding=is_ship, corner=chosen_corner or "top_right"
            )
            bom_box = (bx0, by0, bx1, by1)

        # Create locked Paper Space VIEWPORT on non-plotting layer `VIEWPORT`
        view_h = vp_h / scale_ratio

        vp = lay.add_viewport(
            center=(vp_cx, vp_cy),
            size=(vp_w, vp_h),
            view_center_point=(model_cx, model_cy),
            view_height=view_h,
            status=2,
            dxfattribs={"layer": "VIEWPORT", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
        )
        # Lock viewport display (bit 16384)
        vp.dxf.flags = vp.dxf.flags | 16384

        # Swap projection symbol block if third-angle was explicitly requested
        if projection == "third-angle":
            for ent in lay:
                if ent.dxftype() == "INSERT" and ent.dxf.name == "ISO_PROJ_FIRST":
                    ent.dxf.name = "ISO_PROJ_THIRD"

        # Populate attributed title block `SECO_TBLOCK_<SIZE>`
        _populate_title_block(lay, sh_meta["tblock_block_name"], spec, scale_label, is_ship)

        # Set chosen sheet active
        doc.layouts.set_active_layout(sheet)
        out_pre_dxf.parent.mkdir(parents=True, exist_ok=True)
        doc.saveas(str(out_pre_dxf))

        final_manifest = {
            "discipline": spec["discipline"],
            "projection": projection,
            "sheet": sheet,
            "paper_width_mm": sh_meta["paper_width_mm"],
            "paper_height_mm": sh_meta["paper_height_mm"],
            "scale_label": scale_label,
            "scale_ratio": scale_ratio,
            "viewport": {
                "center_paper": [round(vp_cx, 3), round(vp_cy, 3)],
                "size_paper": [round(vp_w, 3), round(vp_h, 3)],
                "view_center_model": [round(model_cx, 3), round(model_cy, 3)],
                "view_height_model": round(view_h, 4),
            },
            "model_extents": [round(m_minx, 3), round(m_miny, 3), round(m_maxx, 3), round(m_maxy, 3)],
            "bom_box_paper": [round(v, 3) for v in bom_box] if bom_box else None,
            "bom_cells_paper": bom_cells,
            "bom_records": bom_records,
            "views": {
                vid: {
                    "role": pl.role,
                    "title": pl.title,
                    "ox": round(pl.ox, 6),
                    "oy": round(pl.oy, 6),
                    "align_to": pl.align_to,
                    "model_bbox": [round(v, 4) for v in pl.model_bbox],
                }
                for vid, pl in placements.items()
            },
            "dimensions": dim_records,
        }
        break

    return final_manifest


def _populate_title_block(layout, blk_name: str, spec: Dict, scale_label: str, is_ship: bool) -> None:
    meta = spec["metadata"]
    std = spec.get("standard", {})
    ship = spec.get("ship_context", {})
    today = datetime.date.today().strftime("%d/%m/%y")
    drn_date = meta.get("drawn_date") or today

    # Build concise ISO general notes (max 5 lines fitting cleanly in GENERAL NOTES box)
    notes = list(meta.get("general_notes") or [])
    if not notes:
        notes.append("1. ALL DIMENSIONS IN MM UNLESS OTHERWISE INDICATED.")
        tol = std.get("general_tolerance", "ISO 2768-mK")
        notes.append(f"2. GENERAL TOLERANCES: {tol}.")
        if is_ship:
            grade = ship.get("steel_grade") or meta.get("material", "GR.A")
            tight = ship.get("tightness", "NT")
            fspace = ship.get("frame_spacing_mm", "")
            notes.append(f"3. STEEL GRADE: {grade}. TIGHTNESS: {tight}. FRAME SPACING: {fspace} MM.")
            notes.append("4. WELDS PER ISO 2553 (THROAT 'a'). REMOVE SHARP EDGES.")
            if meta.get("class_society"):
                notes.append(f"5. CLASS: {meta['class_society']}. DO NOT SCALE DRAWING.")
            else:
                notes.append("5. DO NOT SCALE DRAWING.")
        else:
            mat = meta.get("material", "")
            notes.append(f"3. MATERIAL: {mat}. REMOVE ALL BURRS & SHARP EDGES.")
            notes.append("4. DO NOT SCALE DRAWING.")

    while len(notes) < 5:
        notes.append("")

    subtitle = meta.get("subtitle") or (f"BLOCK {meta['block']}" if meta.get("block") else meta.get("material", ""))

    values = {
        "CLIENT": str(meta.get("client", "")).upper(),
        "PROJECT": str(meta.get("project", "")).upper(),
        "SITE": str(meta.get("site", "MOMBASA")).upper(),
        "COUNTRY": str(meta.get("country", "KENYA")).upper(),
        "PROJECT_NO": str(meta.get("project_no", "")).upper(),
        "DRG_NO": str(meta.get("drg_no", "")).upper(),
        "SHEET": str(meta.get("sheet", "01 OF 01")).upper(),
        "SCALE": scale_label,
        "TITLE": str(meta.get("title", "")).upper(),
        "SUBTITLE": str(subtitle).upper(),
        "REF_DRG": str(meta.get("ref_drg", "N/A")).upper(),
        "DRAWN_BY": str(meta.get("drawn_by", "SECO")).upper(),
        "DRAWN_DATE": drn_date,
        "CHKD_BY": str(meta.get("chkd_by", "")).upper(),
        "CHKD_DATE": str(meta.get("chkd_date", "")),
        "APPD_BY": str(meta.get("appd_by", "")).upper(),
        "APPD_DATE": str(meta.get("appd_date", "")),
        "REV_0_DESC": str(meta.get("rev_desc", "ISSUED FOR CONSTRUCTION")).upper(),
        "REV_0_DATE": drn_date,
        "REV_0_DRN": str(meta.get("drawn_by", "SECO")).upper(),
        "REV_0_CHK": str(meta.get("chkd_by", "")).upper(),
        "REV_0_APP": str(meta.get("appd_by", "")).upper(),
        "NOTE_1": notes[0],
        "NOTE_2": notes[1],
        "NOTE_3": notes[2],
        "NOTE_4": notes[3],
        "NOTE_5": notes[4],
    }

    # Max usable cell widths on A3 (scaled proportionally per sheet)
    a3_max_w = {
        "TITLE": 66.0,
        "SUBTITLE": 66.0,
        "REF_DRG": 66.0,
        "CLIENT": 33.0,
        "PROJECT": 33.0,
        "PROJECT_NO": 33.0,
        "DRG_NO": 29.0,
        "NOTE_1": 72.0,
        "NOTE_2": 72.0,
        "NOTE_3": 72.0,
        "NOTE_4": 72.0,
        "NOTE_5": 72.0,
        "REV_0_DESC": 36.0,
    }

    for ent in layout:
        if ent.dxftype() == "INSERT" and ent.dxf.name == blk_name:
            for att in ent.attribs:
                tag = att.dxf.tag
                if tag in values:
                    txt = values[tag]
                    att.dxf.text = txt
                    if txt and tag in a3_max_w:
                        h = float(att.dxf.height)
                        sheet_scale = layout.get_paper_limits()[1].x / 420.0
                        max_w = a3_max_w[tag] * sheet_scale
                        est_w = len(txt) * h * 0.84
                        if est_w > max_w:
                            ratio = max_w / est_w
                            att.dxf.height = round(h * max(0.55, ratio), 2)
                            att.dxf.width = 0.80
