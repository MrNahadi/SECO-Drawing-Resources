"""SECO ISO 2D engineering drawing core package."""
