"""
Parametric orthographic view layout engine, ISO 128 line-precedence deduplicator,
and Model Space 1:1 geometry renderer.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import ezdxf
from ezdxf.enums import TextEntityAlignment
from shapely.geometry import LineString, MultiLineString
from shapely.ops import unary_union

from .standards import LAYER_PRECEDENCE


@dataclass
class ViewPlacement:
    view_id: str
    title: str
    role: str
    ox: float  # Model-space X of view local (0, 0)
    oy: float  # Model-space Y of view local (0, 0)
    local_bbox: Tuple[float, float, float, float]  # (xmin, ymin, xmax, ymax) in local coords
    model_bbox: Tuple[float, float, float, float]  # (xmin, ymin, xmax, ymax) in model coords
    align_to: Optional[str] = None


def _entity_local_bounds(el: Dict) -> Optional[Tuple[float, float, float, float]]:
    t = el.get("type")
    if t in ("rect", "void_space", "opening", "flat_surface", "test_zone"):
        if "points" in el:
            pts = el["points"]
            xs = [float(p[0]) for p in pts]
            ys = [float(p[1]) for p in pts]
            return (min(xs), min(ys), max(xs), max(ys))
        x, y = float(el["x"]), float(el["y"])
        w, h = float(el["w"]), float(el["h"])
        return (min(x, x + w), min(y, y + h), max(x, x + w), max(y, y + h))
    if t in ("polyline", "hatch_region", "thin_section_fill"):
        pts = el.get("points", [])
        if not pts:
            return None
        xs = [float(p[0]) for p in pts]
        ys = [float(p[1]) for p in pts]
        return (min(xs), min(ys), max(xs), max(ys))
    if t == "hlr_lines":
        segs = el.get("segments", [])
        if not segs:
            return None
        xs = [float(p[0]) for s in segs for p in s]
        ys = [float(p[1]) for s in segs for p in s]
        return (min(xs), min(ys), max(xs), max(ys))
    if t in ("line", "centerline", "cutting_plane", "molded_line", "stiffener", "break_line"):
        p1, p2 = el.get("p1"), el.get("p2")
        if not p1 or not p2:
            return None
        return (min(p1[0], p2[0]), min(p1[1], p2[1]), max(p1[0], p2[0]), max(p1[1], p2[1]))
    if t in ("circle", "hole"):
        cx, cy = float(el["center"][0]), float(el["center"][1])
        r = float(el.get("radius", float(el.get("diameter", 0.0)) / 2.0))
        return (cx - r, cy - r, cx + r, cy + r)
    if t == "arc":
        cx, cy = float(el["center"][0]), float(el["center"][1])
        r = float(el["radius"])
        return (cx - r, cy - r, cx + r, cy + r)
    if t == "scallop":
        cx, cy = float(el["corner"][0]), float(el["corner"][1])
        r = float(el.get("radius", 35.0))
        return (cx - r, cy - r, cx + r, cy + r)
    return None


def compute_view_local_bbox(view: Dict) -> Tuple[float, float, float, float]:
    xs_min, ys_min, xs_max, ys_max = [], [], [], []
    for el in view.get("elements", []):
        b = _entity_local_bounds(el)
        if b:
            xs_min.append(b[0])
            ys_min.append(b[1])
            xs_max.append(b[2])
            ys_max.append(b[3])
    if not xs_min:
        return (0.0, 0.0, 100.0, 100.0)
    return (min(xs_min), min(ys_min), max(xs_max), max(ys_max))


def layout_views_iso(
    views: List[Dict],
    projection: str = "first-angle",
    gap_model: float = 80.0,
) -> Dict[str, ViewPlacement]:
    """
    Place all views in 1:1 Model Space with mathematically exact orthographic
    datum alignment (< 1e-12 mm) per ISO 5456-2.

    First-angle projection:
      - top / plan -> BELOW front (exact X alignment: ox == front.ox)
      - bottom     -> ABOVE front (exact X alignment: ox == front.ox)
      - left       -> RIGHT of front (exact Y alignment: oy == front.oy)
      - right      -> LEFT of front  (exact Y alignment: oy == front.oy)
    Third-angle projection reverses top/bottom and left/right.
    """
    local_boxes = {v["id"]: compute_view_local_bbox(v) for v in views}
    placements: Dict[str, ViewPlacement] = {}
    first_angle = (projection == "first-angle")

    # 1. Place principal / unaligned root view first at (0, 0)
    root = None
    for v in views:
        if not v.get("align_to") and v["role"] in ("front", "elevation", "transverse"):
            root = v
            break
    if root is None:
        root = views[0]

    rb = local_boxes[root["id"]]
    placements[root["id"]] = ViewPlacement(
        view_id=root["id"],
        title=root["title"],
        role=root["role"],
        ox=0.0,
        oy=0.0,
        local_bbox=rb,
        model_bbox=rb,
        align_to=None,
    )

    # 2. Place aligned orthographic views
    remaining = [v for v in views if v["id"] != root["id"]]
    for _pass in range(len(remaining) + 2):
        still = []
        for v in remaining:
            vid = v["id"]
            role = v["role"]
            lb = local_boxes[vid]
            ref_id = v.get("align_to") or root["id"]
            if ref_id not in placements:
                still.append(v)
                continue
            ref = placements[ref_id]
            rminx, rminy, rmaxx, rmaxy = ref.model_bbox
            lminx, lminy, lmaxx, lmaxy = lb

            # Determine placement direction
            if role in ("top", "plan"):
                if first_angle:
                    # BELOW ref, exact X alignment
                    ox = ref.ox
                    oy = rminy - gap_model - lmaxy
                else:
                    # ABOVE ref, exact X alignment
                    ox = ref.ox
                    oy = rmaxy + gap_model - lminy
            elif role == "bottom":
                if first_angle:
                    ox = ref.ox
                    oy = rmaxy + gap_model - lminy
                else:
                    ox = ref.ox
                    oy = rminy - gap_model - lmaxy
            elif role == "left":
                if first_angle:
                    # RIGHT of ref, exact Y alignment
                    ox = rmaxx + gap_model - lminx
                    oy = ref.oy
                else:
                    ox = rminx - gap_model - lmaxx
                    oy = ref.oy
            elif role == "right":
                if first_angle:
                    # LEFT of ref, exact Y alignment
                    ox = rminx - gap_model - lmaxx
                    oy = ref.oy
                else:
                    ox = rmaxx + gap_model - lminx
                    oy = ref.oy
            elif role in ("section", "detail", "transverse", "elevation"):
                # Default: place cleanly to the RIGHT of the rightmost placed view, aligned in Y to ref
                overall_maxx = max(p.model_bbox[2] for p in placements.values())
                side = v.get("placement_side", "right")
                if side == "below":
                    overall_miny = min(p.model_bbox[1] for p in placements.values())
                    ox = ref.ox
                    oy = overall_miny - gap_model - lmaxy
                else:
                    ox = overall_maxx + gap_model * 1.15 - lminx
                    oy = ref.oy
            else:
                overall_maxx = max(p.model_bbox[2] for p in placements.values())
                ox = overall_maxx + gap_model - lminx
                oy = ref.oy

            mb = (lminx + ox, lminy + oy, lmaxx + ox, lmaxy + oy)
            placements[vid] = ViewPlacement(
                view_id=vid,
                title=v["title"],
                role=role,
                ox=ox,
                oy=oy,
                local_bbox=lb,
                model_bbox=mb,
                align_to=ref_id,
            )
        remaining = still
        if not remaining:
            break

    return placements


class PrecedenceSegmentCollector:
    """
    Collects line segments per semantic layer and resolves ISO 128 line precedence
    (VISIBLE > HIDDEN > CUTTING > CENTER > MOLDED_LINE) so zero duplicate or
    coincident lower-priority overlapping segments remain in the final CAD file.
    """

    def __init__(self) -> None:
        self.segments_by_layer: Dict[str, List[Tuple[Tuple[float, float], Tuple[float, float]]]] = {}

    def add(self, layer: str, p1: Tuple[float, float], p2: Tuple[float, float]) -> None:
        if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-4:
            return
        self.segments_by_layer.setdefault(layer, []).append(((float(p1[0]), float(p1[1])), (float(p2[0]), float(p2[1]))))

    def emit_clean(self, msp) -> None:
        # Process layers in strict ISO 128 precedence order
        ordered_layers = sorted(
            self.segments_by_layer.keys(),
            key=lambda lyr: LAYER_PRECEDENCE.get(lyr, 99),
        )
        higher_union = None

        for layer in ordered_layers:
            raw_lines = [LineString([p1, p2]) for p1, p2 in self.segments_by_layer[layer]]
            if not raw_lines:
                continue

            # Deduplicate within the same layer via unary_union
            layer_geom = unary_union(raw_lines)

            # Subtract any collinear overlap already claimed by higher-precedence layers
            if higher_union is not None:
                # Buffer higher_union minimally (1e-4 mm) to catch exact collinear overlap without clipping perpendicular crossings
                diff = layer_geom.difference(higher_union.buffer(1e-4, cap_style=2))
            else:
                diff = layer_geom

            # Emit resulting clean line segments
            for seg in _extract_segments(diff):
                p1, p2 = seg
                if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) >= 1e-3:
                    msp.add_line(
                        p1,
                        p2,
                        dxfattribs={"layer": layer, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
                    )

            # Add this layer's geometry into higher_union for lower-priority layers
            # (Only VISIBLE, HIDDEN, CUTTING block lower layers; CENTER/FRAME_GRID don't erase each other across crossings)
            if layer in ("VISIBLE", "HIDDEN", "CUTTING"):
                higher_union = layer_geom if higher_union is None else unary_union([higher_union, layer_geom])


def _extract_segments(geom) -> List[Tuple[Tuple[float, float], Tuple[float, float]]]:
    segs: List[Tuple[Tuple[float, float], Tuple[float, float]]] = []
    if geom is None or geom.is_empty:
        return segs
    gtype = geom.geom_type
    if gtype == "LineString":
        coords = list(geom.coords)
        for i in range(len(coords) - 1):
            segs.append(((coords[i][0], coords[i][1]), (coords[i + 1][0], coords[i + 1][1])))
    elif gtype in ("MultiLineString", "GeometryCollection"):
        for part in geom.geoms:
            segs.extend(_extract_segments(part))
    return segs


def _add_filled_arrow(msp, tip: Tuple[float, float], dx: float, dy: float, length: float, width: float, layer: str) -> None:
    """Draw a clean closed-filled arrowhead (SOLID) pointing toward `tip` along `(dx, dy)`."""
    mag = math.hypot(dx, dy)
    if mag < 1e-9:
        return
    ux, uy = dx / mag, dy / mag
    nx, ny = -uy, ux
    base_x = tip[0] - ux * length
    base_y = tip[1] - uy * length
    p_left = (base_x + nx * (width / 2.0), base_y + ny * (width / 2.0))
    p_right = (base_x - nx * (width / 2.0), base_y - ny * (width / 2.0))
    msp.add_solid(
        [tip, p_left, p_right, p_right],
        dxfattribs={"layer": layer, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
    )


def render_view_geometry(
    msp,
    view: Dict,
    placement: ViewPlacement,
    scale_ratio: float,
    occupied_boxes: List[Tuple[float, float, float, float]],
) -> List[Dict]:
    """
    Render all general engineering geometry of one view into Model Space at 1:1.
    Returns list of any deferred marine elements to be rendered by `marine.py`.
    """
    ox, oy = placement.ox, placement.oy
    inv_s = 1.0 / scale_ratio  # converts paper mm -> model mm
    bylayer = lambda lyr: {"layer": lyr, "color": 256, "linetype": "BYLAYER", "lineweight": -1}

    collector = PrecedenceSegmentCollector()
    marine_elements: List[Dict] = []

    for el in view.get("elements", []):
        et = el.get("type")
        layer = el.get("layer", "VISIBLE")

        if et in ("molded_line", "stiffener", "weld_symbol", "tightness_tag", "test_zone"):
            marine_elements.append(el)
            continue

        if et == "rect":
            x = float(el["x"]) + ox
            y = float(el["y"]) + oy
            w = float(el["w"])
            h = float(el["h"])
            pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            if el.get("as_polyline", True) and layer == "VISIBLE":
                msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer(layer))
                # Also register in precedence collector so hidden/center overlapping edges get clipped!
                for i in range(4):
                    collector.add("__MASK_VISIBLE__", pts[i], pts[(i + 1) % 4])
            else:
                for i in range(4):
                    collector.add(layer, pts[i], pts[(i + 1) % 4])

        elif et == "polyline":
            pts = [(float(p[0]) + ox, float(p[1]) + oy) for p in el["points"]]
            closed = bool(el.get("closed", True))
            if closed and layer == "VISIBLE" and len(pts) >= 3:
                msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer(layer))
                for i in range(len(pts)):
                    collector.add("__MASK_VISIBLE__", pts[i], pts[(i + 1) % len(pts)])
            else:
                n = len(pts) if closed else len(pts) - 1
                for i in range(n):
                    collector.add(layer, pts[i], pts[(i + 1) % len(pts)])

        elif et == "line":
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            collector.add(layer, p1, p2)

        elif et == "hlr_lines":
            # Fast-path for pre-deduplicated OpenCASCADE 3D HLR / BRep section line batches
            attr = bylayer(layer)
            seen_local = set()
            for seg in el.get("segments", []):
                p1 = (float(seg[0][0]) + ox, float(seg[0][1]) + oy)
                p2 = (float(seg[1][0]) + ox, float(seg[1][1]) + oy)
                if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-3:
                    continue
                k1 = (round(p1[0], 3), round(p1[1], 3))
                k2 = (round(p2[0], 3), round(p2[1], 3))
                key = (k1, k2) if k1 < k2 else (k2, k1)
                if key not in seen_local:
                    seen_local.add(key)
                    msp.add_line(p1, p2, dxfattribs=attr)

        elif et == "centerline":
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            ext = float(el.get("overshoot_paper_mm", 3.5)) * inv_s
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            mag = math.hypot(dx, dy)
            if mag > 1e-6:
                ux, uy = dx / mag, dy / mag
                p1 = (p1[0] - ux * ext, p1[1] - uy * ext)
                p2 = (p2[0] + ux * ext, p2[1] + uy * ext)
            collector.add("CENTER", p1, p2)

        elif et == "circle":
            cx, cy = float(el["center"][0]) + ox, float(el["center"][1]) + oy
            r = float(el.get("radius", float(el.get("diameter", 0.0)) / 2.0))
            msp.add_circle((cx, cy), radius=r, dxfattribs=bylayer(layer))

        elif et == "hole":
            cx, cy = float(el["center"][0]) + ox, float(el["center"][1]) + oy
            r = float(el.get("radius", float(el.get("diameter", 0.0)) / 2.0))
            msp.add_circle((cx, cy), radius=r, dxfattribs=bylayer(layer))
            if el.get("centermarks", True):
                ext = 3.0 * inv_s
                collector.add("CENTER", (cx - r - ext, cy), (cx + r + ext, cy))
                collector.add("CENTER", (cx, cy - r - ext), (cx, cy + r + ext))

        elif et == "arc":
            cx, cy = float(el["center"][0]) + ox, float(el["center"][1]) + oy
            r = float(el["radius"])
            msp.add_arc(
                (cx, cy),
                radius=r,
                start_angle=float(el["start_angle"]),
                end_angle=float(el["end_angle"]),
                dxfattribs=bylayer(layer),
            )

        elif et == "scallop":
            # Corner scallop / rat-hole quarter-arc on VISIBLE layer
            cx, cy = float(el["corner"][0]) + ox, float(el["corner"][1]) + oy
            r = float(el.get("radius", 35.0))
            quad = str(el.get("quadrant", "NE")).upper()
            angles = {"NE": (0.0, 90.0), "NW": (90.0, 180.0), "SW": (180.0, 270.0), "SE": (270.0, 360.0)}
            sa, ea = angles.get(quad, (0.0, 90.0))
            msp.add_arc((cx, cy), radius=r, start_angle=sa, end_angle=ea, dxfattribs=bylayer("VISIBLE"))

        elif et == "thin_section_fill":
            # ISO 128-50: Narrow sections (< 2mm on paper) filled solid black instead of hatched
            pts = [(float(p[0]) + ox, float(p[1]) + oy) for p in el["points"]]
            if len(pts) >= 3:
                hatch = msp.add_hatch(color=256, dxfattribs=bylayer("HATCH"))
                hatch.set_solid_fill(color=256)
                hatch.dxf.color = 256
                hatch.paths.add_polyline_path(pts, is_closed=True)

        elif et in ("void_space", "opening", "flat_surface"):
            # ISO 128 Basic Line Type 01.1 (01.1.3 openings/voids; 01.1.10 flat surfaces):
            # Continuous narrow (0.25 mm) diagonal crossing lines (X), NEVER hatched!
            if "points" in el:
                pts = [(float(p[0]) + ox, float(p[1]) + oy) for p in el["points"]]
            else:
                x = float(el["x"]) + ox
                y = float(el["y"]) + oy
                w = float(el["w"])
                h = float(el["h"])
                pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            if el.get("draw_border", et != "flat_surface") and len(pts) >= 3:
                b_lyr = el.get("layer", "VISIBLE")
                msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer(b_lyr))
                if b_lyr == "VISIBLE":
                    for i in range(len(pts)):
                        collector.add("__MASK_VISIBLE__", pts[i], pts[(i + 1) % len(pts)])
            # Compute corner-to-corner diagonals (exact 4 corners or bbox corners)
            if len(pts) == 4:
                d1, d2 = (pts[0], pts[2]), (pts[1], pts[3])
                cx = sum(p[0] for p in pts) / 4.0
                cy = sum(p[1] for p in pts) / 4.0
            else:
                xs = [p[0] for p in pts]
                ys = [p[1] for p in pts]
                d1 = ((min(xs), min(ys)), (max(xs), max(ys)))
                d2 = ((min(xs), max(ys)), (max(xs), min(ys)))
                cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0

            label = str(el.get("label", "VOID" if et == "void_space" else "")).strip()
            mask_box = None
            if label:
                from shapely.geometry import box as shp_box
                txt_h = float(el.get("text_height_paper_mm", 2.6)) * inv_s
                lines_txt = label.split("\n")
                max_len = max(len(s) for s in lines_txt)
                hw = max(max_len * txt_h * 0.42 + 2.5 * inv_s, 7.0 * inv_s)
                hh = (len(lines_txt) * txt_h * 0.78) + 2.0 * inv_s
                mask_box = shp_box(cx - hw, cy - hh, cx + hw, cy + hh)
                for idx_l, ln_str in enumerate(lines_txt):
                    ly = cy + ((len(lines_txt) - 1) / 2.0 - idx_l) * (txt_h * 1.45)
                    t = msp.add_text(ln_str, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
                    t.set_placement((cx, ly), align=TextEntityAlignment.MIDDLE_CENTER)
                occupied_boxes.append((cx - hw, cy - hh, cx + hw, cy + hh))

            for p_start, p_end in (d1, d2):
                ls = LineString([p_start, p_end])
                if mask_box is not None:
                    ls = ls.difference(mask_box)
                for seg_a, seg_b in _extract_segments(ls):
                    collector.add("VOID_OPENING", seg_a, seg_b)

        elif et == "break_line":
            # ISO 128 Type 01.1 continuous narrow zig-zag long-break line
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            mag = math.hypot(dx, dy)
            if mag > 1e-4:
                ux, uy = dx / mag, dy / mag
                nx, ny = -uy, ux
                ext = 3.0 * inv_s
                a0 = (p1[0] - ux * ext, p1[1] - uy * ext)
                a1 = (p2[0] + ux * ext, p2[1] + uy * ext)
                mx, my = (p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0
                zw = 2.2 * inv_s
                zh = 3.2 * inv_s
                pts_brk = [
                    a0,
                    (mx - ux * zw, my - uy * zw),
                    (mx - ux * (zw * 0.35) + nx * zh, my - uy * (zw * 0.35) + ny * zh),
                    (mx + ux * (zw * 0.35) - nx * zh, my + uy * (zw * 0.35) - ny * zh),
                    (mx + ux * zw, my + uy * zw),
                    a1,
                ]
                for i in range(len(pts_brk) - 1):
                    collector.add("VOID_OPENING", pts_brk[i], pts_brk[i + 1])

        elif et == "hatch_region":
            pts = [(float(p[0]) + ox, float(p[1]) + oy) for p in el["points"]]
            if len(pts) >= 3:
                hatch = msp.add_hatch(color=256, dxfattribs=bylayer("HATCH"))
                # Metric ANSI31 at 45 deg, scaled so paper spacing is ~3.0 mm
                pattern = el.get("pattern", "ANSI31")
                angle = float(el.get("angle", 0.0))
                h_scale = float(el.get("paper_spacing_mm", 3.0)) / 3.175 * inv_s
                hatch.set_pattern_fill(pattern, color=256, scale=max(0.1, h_scale), angle=angle)
                hatch.dxf.color = 256
                hatch.paths.add_polyline_path(pts, is_closed=True)
                for island in el.get("islands", []):
                    ipts = [(float(p[0]) + ox, float(p[1]) + oy) for p in island]
                    if len(ipts) >= 3:
                        hatch.paths.add_polyline_path(ipts, is_closed=True)

        elif et == "cutting_plane":
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            label = str(el.get("label", "A"))
            view_dir = el.get("arrow_dir", [1.0, 0.0])  # direction of sight
            ext = 6.0 * inv_s
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            mag = math.hypot(dx, dy)
            if mag > 1e-6:
                ux, uy = dx / mag, dy / mag
                ep1 = (p1[0] - ux * ext, p1[1] - uy * ext)
                ep2 = (p2[0] + ux * ext, p2[1] + uy * ext)
                collector.add("CUTTING", ep1, ep2)
                # ISO cutting arrows perpendicular to line, pointing toward view_dir
                adx, ady = float(view_dir[0]), float(view_dir[1])
                amag = math.hypot(adx, ady) or 1.0
                aux, auy = adx / amag, ady / amag
                stem_len = 8.0 * inv_s
                arr_len = 4.0 * inv_s
                arr_w = 1.8 * inv_s
                txt_h = 3.5 * inv_s
                for end_pt in (ep1, ep2):
                    tail = (end_pt[0] - aux * stem_len, end_pt[1] - auy * stem_len)
                    msp.add_line(tail, end_pt, dxfattribs=bylayer("CUTTING"))
                    _add_filled_arrow(msp, end_pt, aux, auy, arr_len, arr_w, "CUTTING")
                    lbl_pt = (tail[0] - aux * 3.2 * inv_s, tail[1] - auy * 3.2 * inv_s)
                    t = msp.add_text(label, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
                    t.set_placement(lbl_pt, align=TextEntityAlignment.MIDDLE_CENTER)
                    occupied_boxes.append((
                        min(lbl_pt[0], end_pt[0]) - txt_h,
                        min(lbl_pt[1], end_pt[1]) - txt_h,
                        max(lbl_pt[0], end_pt[0]) + txt_h,
                        max(lbl_pt[1], end_pt[1]) + txt_h,
                    ))

        elif et == "balloon":
            # ISO BOM item balloon (circle + leader + filled dot/arrow)
            target = (float(el["target"][0]) + ox, float(el["target"][1]) + oy)
            center = (float(el["center"][0]) + ox, float(el["center"][1]) + oy)
            item_no = str(el["item"])
            r_bal = 3.8 * inv_s
            dx, dy = center[0] - target[0], center[1] - target[1]
            mag = math.hypot(dx, dy) or 1.0
            edge_pt = (center[0] - (dx / mag) * r_bal, center[1] - (dy / mag) * r_bal)
            msp.add_line(target, edge_pt, dxfattribs=bylayer("DIM"))
            _add_filled_arrow(msp, target, -dx, -dy, 2.2 * inv_s, 0.9 * inv_s, "DIM")
            msp.add_circle(center, radius=r_bal, dxfattribs=bylayer("TEXT"))
            tb = msp.add_text(item_no, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
            tb.set_placement(center, align=TextEntityAlignment.MIDDLE_CENTER)
            occupied_boxes.append((center[0] - r_bal, center[1] - r_bal, center[0] + r_bal, center[1] + r_bal))

        elif et == "callout":
            target = (float(el["target"][0]) + ox, float(el["target"][1]) + oy)
            land = (float(el["landing"][0]) + ox, float(el["landing"][1]) + oy)
            text_str = str(el["text"])
            txt_h = float(el.get("text_height_paper_mm", 2.5)) * inv_s
            right_side = land[0] >= target[0]
            shelf_len = max(len(text_str) * txt_h * 0.68, 12.0 * inv_s)
            shelf_end = (land[0] + (shelf_len if right_side else -shelf_len), land[1])
            msp.add_line(target, land, dxfattribs=bylayer("DIM"))
            msp.add_line(land, shelf_end, dxfattribs=bylayer("DIM"))
            _add_filled_arrow(msp, target, target[0] - land[0], target[1] - land[1], 2.5 * inv_s, 0.9 * inv_s, "DIM")
            tx = (land[0] + 1.2 * inv_s) if right_side else (shelf_end[0] + 1.2 * inv_s)
            ty = land[1] + 1.0 * inv_s
            t = msp.add_text(text_str, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
            t.set_placement((tx, ty), align=TextEntityAlignment.BOTTOM_LEFT)
            occupied_boxes.append((min(land[0], shelf_end[0]), land[1] - 0.5 * inv_s, max(land[0], shelf_end[0]), ty + txt_h * 1.3))

    # Resolve precedence: remove __MASK_VISIBLE__ pseudo-layer after it masks lower layers
    _emit_with_visible_mask(collector, msp)

    # Record view geometry bbox as occupied
    occupied_boxes.append(placement.model_bbox)
    return marine_elements


def _emit_with_visible_mask(collector: PrecedenceSegmentCollector, msp) -> None:
    mask_lines = collector.segments_by_layer.pop("__MASK_VISIBLE__", [])
    higher_union = unary_union([LineString([p1, p2]) for p1, p2 in mask_lines]) if mask_lines else None

    ordered_layers = sorted(
        collector.segments_by_layer.keys(),
        key=lambda lyr: LAYER_PRECEDENCE.get(lyr, 99),
    )
    for layer in ordered_layers:
        raw_lines = [LineString([p1, p2]) for p1, p2 in collector.segments_by_layer[layer]]
        if not raw_lines:
            continue
        layer_geom = unary_union(raw_lines)
        if higher_union is not None:
            diff = layer_geom.difference(higher_union.buffer(1e-4, cap_style=2))
        else:
            diff = layer_geom
        for p1, p2 in _extract_segments(diff):
            if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) >= 1e-3:
                msp.add_line(
                    p1, p2,
                    dxfattribs={"layer": layer, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
                )
        if layer in ("VISIBLE", "HIDDEN", "CUTTING"):
            higher_union = layer_geom if higher_union is None else unary_union([higher_union, layer_geom])


def render_view_title(
    msp,
    view: Dict,
    placement: ViewPlacement,
    scale_ratio: float,
    scale_label: str,
    dim_bottom_y: float,
    occupied_boxes: List[Tuple[float, float, float, float]],
) -> None:
    """Place ISO 3098 underlined view title + optional marine view direction cleanly below the view."""
    inv_s = 1.0 / scale_ratio
    cx = (placement.model_bbox[0] + placement.model_bbox[2]) / 2.0
    title_h = 3.6 * inv_s
    sub_h = 2.5 * inv_s
    ty = dim_bottom_y - 11.5 * inv_s

    title_text = view["title"].upper()
    t = msp.add_text(
        title_text,
        dxfattribs={"layer": "TEXT", "style": "ISO_TEXT", "height": title_h, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
    )
    t.set_placement((cx, ty), align=TextEntityAlignment.BOTTOM_CENTER)
    half_w = max(len(title_text) * title_h * 0.34, 14.0 * inv_s)
    # Underline per ISO practice (clear below title text and clear above scale subtitle)
    msp.add_line(
        (cx - half_w, ty - 1.1 * inv_s),
        (cx + half_w, ty - 1.1 * inv_s),
        dxfattribs={"layer": "TEXT", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
    )

    sub_parts = []
    if view.get("view_direction"):
        sub_parts.append(str(view["view_direction"]).upper())
    sub_parts.append(f"SCALE {scale_label}")
    sub_text = "  |  ".join(sub_parts)
    st = msp.add_text(
        sub_text,
        dxfattribs={"layer": "TEXT", "style": "ISO_TEXT", "height": sub_h, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
    )
    st.set_placement((cx, ty - 5.6 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
    sub_hw = len(sub_text) * sub_h * 0.34
    occupied_boxes.append((cx - max(half_w, sub_hw), ty - 6.4 * inv_s, cx + max(half_w, sub_hw), ty + title_h * 1.2))
