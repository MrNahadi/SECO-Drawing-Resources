"""
Associative ISO 129-1 dimensioning engine with bounding-box collision avoidance.

All dimensions are native DXF `DIMENSION` entities on layer `DIM` using
`DIMSTYLE = SECO_ISO_MM`. Measured values are NEVER faked or overridden;
prefixes/suffixes always retain `<>` so AutoCAD computes exact geometry values.
"""

from __future__ import annotations

import math
from typing import Dict, List, Tuple

from .projector import ViewPlacement


def _boxes_overlap(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float], pad: float = 0.0) -> bool:
    return not (
        a[2] + pad <= b[0]
        or b[2] + pad <= a[0]
        or a[3] + pad <= b[1]
        or b[3] + pad <= a[1]
    )


def _format_dim_override(prefix: str, suffix: str, reference: bool) -> str:
    """Return AutoCAD associative text template preserving `<>` true measurement."""
    if not prefix and not suffix and not reference:
        return ""
    body = f"{prefix}<>{suffix}"
    return f"({body})" if reference else body


def render_view_dimensions(
    msp,
    view: Dict,
    placement: ViewPlacement,
    scale_ratio: float,
    occupied_boxes: List[Tuple[float, float, float, float]],
    dim_records: List[Dict],
) -> float:
    """
    Render all associative ISO 129-1 dimensions for one view.
    Returns the lowest Y coordinate reached below the view (so the view title sits clear).
    """
    ox, oy = placement.ox, placement.oy
    minx, miny, maxx, maxy = placement.model_bbox
    inv_s = 1.0 / scale_ratio
    first_off = 12.0 * inv_s   # ISO 129-1: >= 10 mm plotted from outline
    tier_step = 9.0 * inv_s    # ISO 129-1: >= 7.5 mm plotted between parallel rows
    txt_h = 2.5 * inv_s

    dim_override_base = {
        "dimscale": inv_s,
        "dimtxt": 2.5,
        "dimasz": 2.5,
        "dimexo": 1.25,
        "dimexe": 2.0,
        "dimgap": 1.0,
        "dimtad": 1,
        "dimtih": 0,
        "dimtoh": 0,
        "dimdec": 2,
        "dimzin": 8,
        "dimclrd": 256,
        "dimclre": 256,
        "dimclrt": 256,
        "dimlwd": -1,
        "dimlwe": -1,
    }
    dxf_bylayer = {"layer": "DIM", "color": 256, "linetype": "BYLAYER", "lineweight": -1}
    lowest_y = miny

    for d in view.get("dimensions", []):
        kind = d["kind"]
        tier = int(d.get("tier", 1))
        side = d.get("side", "bottom")
        prefix = str(d.get("prefix", ""))
        suffix = str(d.get("suffix", ""))
        reference = bool(d.get("reference", False))
        text_tpl = _format_dim_override(prefix, suffix, reference)

        if kind == "horizontal":
            p1 = (float(d["p1"][0]) + ox, float(d["p1"][1]) + oy)
            p2 = (float(d["p2"][0]) + ox, float(d["p2"][1]) + oy)
            true_val = abs(p2[0] - p1[0])
            off = first_off + (tier - 1) * tier_step
            base_y = (maxy + off) if side == "top" else (miny - off)

            # Collision avoidance along Y
            mx = (p1[0] + p2[0]) / 2.0
            est_w = max(len(f"{prefix}{true_val:.1f}{suffix}") * txt_h * 0.65, 8.0 * inv_s)
            for _ in range(8):
                tbox = (mx - est_w / 2.0, base_y + 0.3 * inv_s, mx + est_w / 2.0, base_y + txt_h * 1.45)
                if not any(_boxes_overlap(tbox, ob, pad=0.8 * inv_s) for ob in occupied_boxes):
                    break
                base_y += (tier_step * 0.85) if side == "top" else (-tier_step * 0.85)

            dim = msp.add_linear_dim(
                base=(mx, base_y),
                p1=p1,
                p2=p2,
                angle=0,
                dimstyle="SECO_ISO_MM",
                override=dim_override_base,
                dxfattribs=dxf_bylayer,
            )
            if text_tpl:
                dim.dimension.dxf.text = text_tpl
            dim.render()
            tbox = (mx - est_w / 2.0, base_y + 0.3 * inv_s, mx + est_w / 2.0, base_y + txt_h * 1.45)
            occupied_boxes.append(tbox)
            lowest_y = min(lowest_y, base_y)
            full_box = (
                min(p1[0], p2[0], tbox[0]) - 2.0 * inv_s,
                min(p1[1], p2[1], base_y) - 2.0 * inv_s,
                max(p1[0], p2[0], tbox[2]) + 2.0 * inv_s,
                max(p1[1], p2[1], tbox[3]) + 1.0 * inv_s,
            )
            dim_records.append({
                "view_id": placement.view_id, "kind": kind, "expected_mm": round(true_val, 4),
                "text_box": [round(v, 3) for v in tbox],
                "full_box": [round(v, 3) for v in full_box],
            })

        elif kind == "vertical":
            p1 = (float(d["p1"][0]) + ox, float(d["p1"][1]) + oy)
            p2 = (float(d["p2"][0]) + ox, float(d["p2"][1]) + oy)
            true_val = abs(p2[1] - p1[1])
            off = first_off + (tier - 1) * tier_step
            base_x = (maxx + off) if side == "right" else (minx - off)

            my = (p1[1] + p2[1]) / 2.0
            est_h = max(len(f"{prefix}{true_val:.1f}{suffix}") * txt_h * 0.65, 8.0 * inv_s)
            for _ in range(8):
                tbox = (base_x - txt_h * 1.45, my - est_h / 2.0, base_x - 0.3 * inv_s, my + est_h / 2.0)
                if not any(_boxes_overlap(tbox, ob, pad=0.8 * inv_s) for ob in occupied_boxes):
                    break
                base_x += (tier_step * 0.85) if side == "right" else (-tier_step * 0.85)

            dim = msp.add_linear_dim(
                base=(base_x, my),
                p1=p1,
                p2=p2,
                angle=90,
                dimstyle="SECO_ISO_MM",
                override=dim_override_base,
                dxfattribs=dxf_bylayer,
            )
            if text_tpl:
                dim.dimension.dxf.text = text_tpl
            dim.render()
            tbox = (base_x - txt_h * 1.45, my - est_h / 2.0, base_x - 0.3 * inv_s, my + est_h / 2.0)
            occupied_boxes.append(tbox)
            full_box = (
                min(p1[0], p2[0], tbox[0]) - 2.0 * inv_s,
                min(p1[1], p2[1], tbox[1]) - 2.0 * inv_s,
                max(p1[0], p2[0], base_x) + 2.0 * inv_s,
                max(p1[1], p2[1], tbox[3]) + 2.0 * inv_s,
            )
            dim_records.append({
                "view_id": placement.view_id, "kind": kind, "expected_mm": round(true_val, 4),
                "text_box": [round(v, 3) for v in tbox],
                "full_box": [round(v, 3) for v in full_box],
            })

        elif kind == "aligned":
            p1 = (float(d["p1"][0]) + ox, float(d["p1"][1]) + oy)
            p2 = (float(d["p2"][0]) + ox, float(d["p2"][1]) + oy)
            true_val = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            dist = first_off + (tier - 1) * tier_step
            dim = msp.add_aligned_dim(
                p1=p1,
                p2=p2,
                distance=dist,
                dimstyle="SECO_ISO_MM",
                override=dim_override_base,
                dxfattribs=dxf_bylayer,
            )
            if text_tpl:
                dim.dimension.dxf.text = text_tpl
            dim.render()
            dim_records.append({"view_id": placement.view_id, "kind": kind, "expected_mm": round(true_val, 4)})

        elif kind == "diameter":
            cx = float(d["center"][0]) + ox
            cy = float(d["center"][1]) + oy
            r = float(d["radius"])
            ang = float(d.get("angle_deg", 45.0))
            rad = math.radians(ang)
            true_val = 2.0 * r
            # Compute leader landing cleanly OUTSIDE the view bounding box along `ang`
            ux, uy = math.cos(rad), math.sin(rad)
            # Distance from circle center to exit view bbox along ray (ux, uy)
            t_candidates = []
            if ux > 1e-6:
                t_candidates.append((maxx - cx) / ux)
            elif ux < -1e-6:
                t_candidates.append((minx - cx) / ux)
            if uy > 1e-6:
                t_candidates.append((maxy - cy) / uy)
            elif uy < -1e-6:
                t_candidates.append((miny - cy) / uy)
            exit_dist = min([t for t in t_candidates if t > 0], default=r)
            lead_dist = max(r + 12.0 * inv_s, exit_dist + 12.0 * inv_s)
            tx = cx + ux * lead_dist
            ty = cy + uy * lead_dist
            # Place associative diameter dim with explicit outside location
            dim = msp.add_diameter_dim(
                center=(cx, cy),
                radius=r,
                angle=ang,
                location=(tx, ty),
                dimstyle="SECO_ISO_MM",
                override={**dim_override_base, "dimtix": 0, "dimtofl": 0, "dimatfit": 1},
                dxfattribs=dxf_bylayer,
            )
            if text_tpl:
                dim.dimension.dxf.text = text_tpl
            dim.render()
            tbox = (tx - 5.0 * inv_s, ty - 2.0 * inv_s, tx + 9.0 * inv_s, ty + 3.0 * inv_s)
            occupied_boxes.append(tbox)
            dim_records.append({
                "view_id": placement.view_id, "kind": kind, "expected_mm": round(true_val, 4),
                "text_box": [round(v, 3) for v in tbox],
            })

        elif kind == "radius":
            cx = float(d["center"][0]) + ox
            cy = float(d["center"][1]) + oy
            r = float(d["radius"])
            ang = float(d.get("angle_deg", 45.0))
            dim = msp.add_radius_dim(
                center=(cx, cy),
                radius=r,
                angle=ang,
                dimstyle="SECO_ISO_MM",
                override=dim_override_base,
                dxfattribs=dxf_bylayer,
            )
            if text_tpl:
                dim.dimension.dxf.text = text_tpl
            dim.render()
            dim_records.append({"view_id": placement.view_id, "kind": kind, "expected_mm": round(r, 4)})

    return lowest_y
