"""
Headless AutoCAD 2027 (`accoreconsole.exe`) bridge + `pdftoppm` visual rasterizer.

Performs authoritative AutoCAD operations:
  - AUDIT (zero-error verification)
  - Native AutoCAD 2018 DWG and DXF save (evaluates real DIMENSION blocks & VIEWPORTs)
  - Monochrome PDF plotting via `DWG To PDF.pc3` + `monochrome.ctb` with object lineweights
  - Rasterization + high-res detail crops for visual inspection
"""

from __future__ import annotations

import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image

ACCORECONSOLE = Path(r"C:\Program Files\Autodesk\AutoCAD 2027\accoreconsole.exe")

MEDIA_PLOT_NAMES: Dict[str, str] = {
    "A0": "ISO full bleed A0 (1189.00 x 841.00 MM)",
    "A1": "ISO full bleed A1 (594.00 x 841.00 MM)",
    "A2": "ISO full bleed A2 (420.00 x 594.00 MM)",
    "A3": "ISO full bleed A3 (420.00 x 297.00 MM)",
    "A4": "ISO full bleed A4 (210.00 x 297.00 MM)",
}


@dataclass
class AutoCADResult:
    ok: bool
    dwg_path: Optional[Path]
    dxf_path: Optional[Path]
    pdf_path: Optional[Path]
    audit_errors: int
    audit_fixed: int
    raw_log: str


def run_accore(input_file: Path, script_lines: List[str], timeout: int = 90) -> str:
    if not ACCORECONSOLE.exists():
        raise FileNotFoundError(f"AutoCAD Core Console not found: {ACCORECONSOLE}")
    with tempfile.NamedTemporaryFile("w", suffix=".scr", delete=False, encoding="ascii", newline="\r\n") as f:
        f.write("\n".join(script_lines) + "\n")
        scr_path = Path(f.name)
    try:
        proc = subprocess.run(
            [str(ACCORECONSOLE), "/i", str(input_file), "/s", str(scr_path), "/l", "en-US"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        raw = proc.stdout
        try:
            text = raw.decode("utf-16-le", errors="ignore")
        except Exception:
            text = raw.decode("utf-8", errors="ignore")
        if not text.strip():
            text = proc.stderr.decode("utf-8", errors="ignore")
        return text
    finally:
        scr_path.unlink(missing_ok=True)


def parse_audit_counts(log_text: str) -> Tuple[int, int]:
    matches = re.findall(r"Total errors found\s+(\d+)\s+fixed\s+(\d+)", log_text, re.IGNORECASE)
    if not matches:
        return (-1, -1)
    errs, fixed = matches[-1]
    return int(errs), int(fixed)


def finalize_and_plot(
    input_dxf: Path,
    sheet_size: str,
    out_dwg: Path,
    out_dxf: Path,
    out_pdf: Path,
    ctb_name: str = "monochrome.ctb",
) -> AutoCADResult:
    """
    Open generated DXF in AutoCAD 2027, AUDIT, regenerate dimension/viewport geometry,
    save native DWG + DXF, and plot monochrome full-bleed PDF.
    """
    sheet = sheet_size.upper()
    if sheet not in MEDIA_PLOT_NAMES:
        raise ValueError(f"Unsupported sheet size {sheet_size!r}")
    media_name = MEDIA_PLOT_NAMES[sheet]

    out_dwg.parent.mkdir(parents=True, exist_ok=True)
    out_dxf.parent.mkdir(parents=True, exist_ok=True)
    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    for p in (out_dwg, out_dxf, out_pdf):
        p.unlink(missing_ok=True)

    script = [
        "EXPERT", "5",
        "AUDIT", "Y",
        "-LAYOUT", "S", sheet,
        "REGENALL",
        "SAVEAS", "2018", f'"{out_dwg}"',
        "DXFOUT", f'"{out_dxf}"', "16",
        "-PLOT", "Y", sheet,
        "DWG To PDF.pc3",
        media_name,
        "Millimeters", "Landscape", "No", "Layout",
        "1:1", "0.00,0.00", "Yes", ctb_name,
        "Yes", "No", "No", "No",
        f'"{out_pdf}"', "No", "Yes",
        "QUIT", "N",
    ]
    log = run_accore(input_dxf, script, timeout=90)
    errs, fixed = parse_audit_counts(log)

    # Fresh verification AUDIT on the saved native DWG
    if out_dwg.exists():
        audit_log = run_accore(out_dwg, ["AUDIT", "Y", "QUIT", "N"], timeout=45)
        errs2, fixed2 = parse_audit_counts(audit_log)
        if errs2 >= 0:
            errs, fixed = errs2, fixed2
        log += "\n--- FINAL DWG AUDIT ---\n" + audit_log

    ok = out_dwg.exists() and out_dxf.exists() and out_pdf.exists() and errs == 0
    return AutoCADResult(
        ok=ok,
        dwg_path=out_dwg if out_dwg.exists() else None,
        dxf_path=out_dxf if out_dxf.exists() else None,
        pdf_path=out_pdf if out_pdf.exists() else None,
        audit_errors=errs,
        audit_fixed=fixed,
        raw_log=log,
    )


def rasterize_and_crop(pdf_path: Path, out_dir: Path, dpi: int = 200) -> Dict[str, Path]:
    """Rasterize PDF via pdftoppm and produce zoomed crops of title block and main drawing area."""
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = pdf_path.stem
    prefix = out_dir / f"{stem}_full"
    subprocess.run(
        ["pdftoppm", "-png", "-r", str(dpi), str(pdf_path), str(prefix)],
        check=True,
        capture_output=True,
    )
    full_png = out_dir / f"{stem}_full-1.png"
    results: Dict[str, Path] = {"full": full_png}

    if full_png.exists():
        im = Image.open(full_png)
        w, h = im.size
        # Title block bottom strip crop
        tb_crop = out_dir / f"{stem}_titleblock.png"
        im.crop((0, int(h * 0.82), w, h)).save(tb_crop)
        results["titleblock"] = tb_crop

        # Main drawing views crop (upper 83%, inner margins)
        views_crop = out_dir / f"{stem}_views.png"
        im.crop((int(w * 0.02), int(h * 0.03), int(w * 0.98), int(h * 0.85))).save(views_crop)
        results["views"] = views_crop

    return results
