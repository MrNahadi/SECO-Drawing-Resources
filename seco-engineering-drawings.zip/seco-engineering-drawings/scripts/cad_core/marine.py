"""
Shipbuilding / Marine structural & outfitting drawing module.

Activated when `discipline` is `shipbuilding-structural` or `shipbuilding-outfitting`:
  - Ship coordinate & frame grid (`FR ##`, `BL`, `CL`, `WL`, `PORT`/`STBD`, `SYM ABOUT CL`)
  - Mandatory vessel orientation arrows (`FWD ->`) & view-direction headers
  - Molded lines (`ML`) with plate thickness-throw symbols
  - Stiffener representations with toe-direction arrows & profile callouts
  - Native ISO 2553 welding symbols (`a` throat / `z` leg, continuous & intermittent)
  - Watertight / Oiltight (`WT` / `OT` / `NT`) boundary badges
  - Paper-Space Handing-Aware Material List / BOM table with auto-computed steel weights
"""

from __future__ import annotations

import math
from typing import Dict, List, Tuple

from ezdxf.enums import TextEntityAlignment

from .projector import ViewPlacement, _add_filled_arrow
from .standards import compute_bom_item_weight_kg


def render_marine_view_overlays(
    msp,
    view: Dict,
    placement: ViewPlacement,
    marine_elements: List[Dict],
    scale_ratio: float,
    occupied_boxes: List[Tuple[float, float, float, float]],
) -> None:
    """Render frame grids, orientation arrows, molded lines, stiffeners, welds, and WT tags."""
    ox, oy = placement.ox, placement.oy
    minx, miny, maxx, maxy = placement.model_bbox
    inv_s = 1.0 / scale_ratio
    bylayer = lambda lyr: {"layer": lyr, "color": 256, "linetype": "BYLAYER", "lineweight": -1}

    # 1. Ship datum & frame grid
    fg = view.get("frame_grid") or {}
    ext_top = 8.0 * inv_s
    ext_bot = 6.0 * inv_s
    ext_side = 10.0 * inv_s
    txt_h = 2.5 * inv_s

    for fr in fg.get("frames", []):
        fr_num = fr["fr"]
        coord = float(fr["coord"])
        axis = fr.get("axis", "x")
        if axis == "x":
            x = coord + ox
            y0, y1 = miny - ext_bot, maxy + ext_top
            msp.add_line((x, y0), (x, y1), dxfattribs=bylayer("FRAME_GRID"))
            # Frame bubble at top
            bub_r = 4.2 * inv_s
            msp.add_circle((x, y1 + bub_r), radius=bub_r, dxfattribs=bylayer("TEXT"))
            t = msp.add_text(f"FR{fr_num}", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.2 * inv_s})
            t.set_placement((x, y1 + bub_r), align=TextEntityAlignment.MIDDLE_CENTER)
            occupied_boxes.append((x - bub_r, y1, x + bub_r, y1 + 2 * bub_r))
        else:
            y = coord + oy
            x0, x1 = minx - ext_side, maxx + ext_side
            msp.add_line((x0, y), (x1, y), dxfattribs=bylayer("FRAME_GRID"))
            t = msp.add_text(f"FR{fr_num}", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.2 * inv_s})
            t.set_placement((x1 + 2.0 * inv_s, y), align=TextEntityAlignment.MIDDLE_LEFT)

    if fg.get("centerline_x") is not None:
        cx = float(fg["centerline_x"]) + ox
        y0, y1 = miny - ext_bot, maxy + ext_top + 4.0 * inv_s
        msp.add_line((cx, y0), (cx, y1), dxfattribs=bylayer("CENTER"))
        t = msp.add_text("CL", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 3.0 * inv_s})
        t.set_placement((cx, y1 + 2.5 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
        occupied_boxes.append((cx - 4.0 * inv_s, y1 + 2.0 * inv_s, cx + 4.0 * inv_s, y1 + 6.0 * inv_s))

        if fg.get("port_stbd_labels"):
            tp = msp.add_text("PORT", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
            tp.set_placement((cx - 16.0 * inv_s, maxy + 5.5 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
            ts = msp.add_text("STBD", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
            ts.set_placement((cx + 16.0 * inv_s, maxy + 5.5 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
            occupied_boxes.append((cx - 24.0 * inv_s, maxy + 5.0 * inv_s, cx + 24.0 * inv_s, maxy + 9.0 * inv_s))

        if fg.get("sym_about_cl"):
            # Symmetry double-ticks on CL + clean label to the right of CL (never overlapping CL)
            for ty_frac in (0.28, 0.72):
                sy = miny + (maxy - miny) * ty_frac
                for dy_tick in (-1.0 * inv_s, 1.0 * inv_s):
                    msp.add_line((cx - 3.5 * inv_s, sy + dy_tick), (cx + 3.5 * inv_s, sy + dy_tick), dxfattribs=bylayer("CENTER"))
            tsym = msp.add_text("SYM ABOUT CL", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.4 * inv_s})
            tsym.set_placement((cx + 5.0 * inv_s, miny - 5.0 * inv_s), align=TextEntityAlignment.TOP_LEFT)

    if fg.get("baseline_y") is not None:
        by = float(fg["baseline_y"]) + oy
        msp.add_line((minx - ext_side, by), (maxx + ext_side, by), dxfattribs=bylayer("FRAME_GRID"))
        tb = msp.add_text("BL (WL 0)", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.4 * inv_s})
        tb.set_placement((maxx + ext_side + 2.0 * inv_s, by), align=TextEntityAlignment.MIDDLE_LEFT)

    for wl in fg.get("waterlines", []):
        wy = float(wl["y"]) + oy
        msp.add_line((minx - ext_side, wy), (maxx + ext_side, wy), dxfattribs=bylayer("FRAME_GRID"))
        tw = msp.add_text(str(wl["label"]), dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.3 * inv_s})
        tw.set_placement((maxx + ext_side + 2.0 * inv_s, wy), align=TextEntityAlignment.MIDDLE_LEFT)

    # 2. Mandatory vessel orientation marker (direction-aware! Supports FWD UP, FWD ->, FWD <-, FWD DOWN)
    orient = str(view.get("orientation_marker", "")).strip()
    if orient:
        oy_top = maxy + ext_top + 4.5 * inv_s
        ox_right = maxx - 16.0 * inv_s
        ou = orient.upper()
        if "FWD" in ou:
            # Determine arrow vector: vertical UP if explicitly UP/NORTH or if frames increase along +Y
            frames = fg.get("frames", [])
            y_increasing_fwd = (
                len(frames) >= 2
                and frames[0].get("axis", "x") == "y"
                and (frames[-1]["fr"] - frames[0]["fr"]) * (frames[-1]["coord"] - frames[0]["coord"]) > 0
            )
            if "UP" in ou or y_increasing_fwd:
                ax = maxx + ext_side + 10.0 * inv_s
                ay0 = (miny + maxy) / 2.0 - 8.0 * inv_s
                ay1 = (miny + maxy) / 2.0 + 8.0 * inv_s
                msp.add_line((ax, ay0), (ax, ay1), dxfattribs=bylayer("TEXT"))
                _add_filled_arrow(msp, (ax, ay1), 0.0, 1.0, 3.0 * inv_s, 1.2 * inv_s, "TEXT")
                to = msp.add_text("FWD", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
                to.set_placement((ax, ay1 + 2.0 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
                occupied_boxes.append((ax - 4.0 * inv_s, ay0, ax + 4.0 * inv_s, ay1 + 5.5 * inv_s))
            else:
                arr_x0 = ox_right - 9.0 * inv_s
                arr_x1 = ox_right + 9.0 * inv_s
                msp.add_line((arr_x0, oy_top), (arr_x1, oy_top), dxfattribs=bylayer("TEXT"))
                _add_filled_arrow(msp, (arr_x1, oy_top), 1.0, 0.0, 3.0 * inv_s, 1.2 * inv_s, "TEXT")
                to = msp.add_text("FWD", dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
                to.set_placement((ox_right, oy_top + 1.3 * inv_s), align=TextEntityAlignment.BOTTOM_CENTER)
                occupied_boxes.append((arr_x0, oy_top - 1.5 * inv_s, arr_x1 + 2.0 * inv_s, oy_top + 4.5 * inv_s))
        elif not fg.get("port_stbd_labels"):
            to = msp.add_text(ou, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.5 * inv_s})
            to.set_placement((ox_right, oy_top), align=TextEntityAlignment.BOTTOM_CENTER)
            occupied_boxes.append((ox_right - 16.0 * inv_s, oy_top - 1.0 * inv_s, ox_right + 16.0 * inv_s, oy_top + 3.5 * inv_s))

    # 3. Marine elements: molded lines, stiffeners, ISO 2553 welds, tightness tags
    for el in marine_elements:
        et = el["type"]

        if et == "molded_line":
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            throw = str(el["throw"]).upper()
            msp.add_line(p1, p2, dxfattribs=bylayer("MOLDED_LINE"))
            # Molded-line throw indicator (small filled arrow on throw side at configurable fraction along line)
            frac = float(el.get("label_frac", 0.28))
            mx = p1[0] + (p2[0] - p1[0]) * frac
            my = p1[1] + (p2[1] - p1[1]) * frac
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            mag = math.hypot(dx, dy) or 1.0
            nx, ny = -dy / mag, dx / mag  # unit normal
            side_sign = float(el.get("throw_sign", 1.0))
            nx, ny = nx * side_sign, ny * side_sign
            tip = (mx + nx * 3.5 * inv_s, my + ny * 3.5 * inv_s)
            msp.add_line((mx, my), tip, dxfattribs=bylayer("MOLDED_LINE"))
            _add_filled_arrow(msp, tip, nx, ny, 2.4 * inv_s, 1.2 * inv_s, "MOLDED_LINE")
            lbl = el.get("label") or f"ML (THK {throw})"
            tm = msp.add_text(lbl, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.4 * inv_s})
            lx, ly = tip[0] + nx * 1.5 * inv_s, tip[1] + ny * 1.5 * inv_s
            tm.set_placement((lx, ly), align=TextEntityAlignment.BOTTOM_CENTER if abs(ny) > 0.5 else TextEntityAlignment.MIDDLE_LEFT)
            occupied_boxes.append((lx - len(lbl) * 0.9 * inv_s, ly - 1.5 * inv_s, lx + len(lbl) * 0.9 * inv_s, ly + 2.5 * inv_s))

        elif et == "stiffener":
            p1 = (float(el["p1"][0]) + ox, float(el["p1"][1]) + oy)
            p2 = (float(el["p2"][0]) + ox, float(el["p2"][1]) + oy)
            profile = str(el["profile"])
            toe = str(el["toe_direction"]).upper()
            side = str(el.get("side", "near")).lower()
            # ISO 128-15: Near Side (NS) = continuous VISIBLE; Far Side (FS) = dashed HIDDEN
            layer = "HIDDEN" if side == "far" else el.get("layer", "VISIBLE")
            msp.add_line(p1, p2, dxfattribs=bylayer(layer))
            # Draw parallel dashed/solid flange indicator + toe-direction tick near 65% of length
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            mag = math.hypot(dx, dy) or 1.0
            ux, uy = dx / mag, dy / mag
            nx, ny = -uy, ux
            toe_sign = float(el.get("toe_sign", 1.0))
            nx, ny = nx * toe_sign, ny * toe_sign
            fl_off = 1.8 * inv_s
            msp.add_line(
                (p1[0] + nx * fl_off, p1[1] + ny * fl_off),
                (p2[0] + nx * fl_off, p2[1] + ny * fl_off),
                dxfattribs=bylayer("HIDDEN"),
            )
            # Explicit toe-direction arrow at 65% along stiffener
            ax = p1[0] + dx * 0.65
            ay = p1[1] + dy * 0.65
            tip = (ax + nx * 4.5 * inv_s, ay + ny * 4.5 * inv_s)
            msp.add_line((ax, ay), tip, dxfattribs=bylayer("TEXT"))
            _add_filled_arrow(msp, tip, nx, ny, 2.2 * inv_s, 1.0 * inv_s, "TEXT")
            # Callout label (placed at custom landing if provided, suppressed when show_label=False)
            if el.get("show_label", True):
                fs_tag = " FS" if (side == "far" and "FS" not in str(el.get("label", "")).upper()) else ""
                label = (el.get("label") or f"{profile} (TOE {toe})") + fs_tag
                if "landing" in el:
                    lx, ly = float(el["landing"][0]) + ox, float(el["landing"][1]) + oy
                    msp.add_line((ax, ay), (lx, ly), dxfattribs=bylayer("DIM"))
                    right_side = lx >= ax
                    shelf_len = max(len(label) * txt_h * 0.66, 14.0 * inv_s)
                    se = (lx + (shelf_len if right_side else -shelf_len), ly)
                    msp.add_line((lx, ly), se, dxfattribs=bylayer("DIM"))
                    _add_filled_arrow(msp, (ax, ay), ax - lx, ay - ly, 2.4 * inv_s, 0.9 * inv_s, "DIM")
                    tx = (lx + 1.2 * inv_s) if right_side else (se[0] + 1.2 * inv_s)
                    ts = msp.add_text(label, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
                    ts.set_placement((tx, ly + 0.8 * inv_s), align=TextEntityAlignment.BOTTOM_LEFT)
                    occupied_boxes.append((min(lx, se[0]), ly - 0.5 * inv_s, max(lx, se[0]), ly + txt_h * 1.4))
                else:
                    ts = msp.add_text(label, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
                    ts.set_placement((tip[0] + nx * 1.5 * inv_s, tip[1] + ny * 1.5 * inv_s), align=TextEntityAlignment.MIDDLE_LEFT)

        elif et == "test_zone":
            # IACS UR S14 Monochrome Tank & Leak Testing Compartment Representation:
            # Voids use ISO 128 thin continuous diagonal X (NEVER hatched, NEVER rainbow colored!).
            # Liquid/tested compartments use crisp monochrome boundary + boxed UR S14 test code.
            from shapely.geometry import LineString, box as shp_box
            from .projector import _extract_segments

            if "points" in el:
                pts = [(float(p[0]) + ox, float(p[1]) + oy) for p in el["points"]]
            else:
                x = float(el["x"]) + ox
                y = float(el["y"]) + oy
                w = float(el["w"])
                h = float(el["h"])
                pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer("VISIBLE"))

            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            comp_w = max(xs) - min(xs)
            comp_h = max(ys) - min(ys)
            cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
            test_type = str(el.get("test_type", "VOID")).upper()
            comp_name = str(el.get("name", "")).upper()
            test_detail = str(el.get("detail", "")).upper()

            lines_txt = [s for s in (comp_name, f"[{test_type}]" + (f" {test_detail}" if test_detail else "")) if s]
            t_h = 2.5 * inv_s
            max_len = max((len(s) for s in lines_txt), default=6)
            est_w = max(max_len * t_h * 0.72 + 4.0 * inv_s, 14.0 * inv_s)
            est_h = len(lines_txt) * t_h * 1.65 + 4.0 * inv_s

            # Rotate text 90 deg vertically if compartment is narrow & tall so text never overflows bay width
            rotate_90 = (comp_h > comp_w * 1.6) and (est_w > comp_w * 0.88)
            hw = (est_h / 2.0) if rotate_90 else (est_w / 2.0)
            hh = (est_w / 2.0) if rotate_90 else (est_h / 2.0)
            mask_box = shp_box(cx - hw, cy - hh, cx + hw, cy + hh)

            if test_type in ("VOID", "V.S.", "COFFERDAM"):
                # ISO 128 thin continuous corner-to-corner diagonal X with text clearance gap
                d_pairs = ((pts[0], pts[2]), (pts[1], pts[3])) if len(pts) == 4 else (
                    ((min(xs), min(ys)), (max(xs), max(ys))),
                    ((min(xs), max(ys)), (max(xs), min(ys))),
                )
                for pa, pb in d_pairs:
                    clipped = LineString([pa, pb]).difference(mask_box)
                    for sa, sb in _extract_segments(clipped):
                        msp.add_line(sa, sb, dxfattribs=bylayer("VOID_OPENING"))
            else:
                # Boxed UR S14 test-regime callout inside clean open monochrome tank
                bpts = [(cx - hw, cy - hh), (cx + hw, cy - hh), (cx + hw, cy + hh), (cx - hw, cy + hh)]
                msp.add_lwpolyline(bpts, close=True, dxfattribs=bylayer("DIM"))

            for idx_l, ln_str in enumerate(lines_txt):
                offset = ((len(lines_txt) - 1) / 2.0 - idx_l) * (t_h * 1.45)
                if rotate_90:
                    tx, ty = cx - offset, cy
                    tt = msp.add_text(ln_str, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": t_h, "rotation": 90.0})
                    tt.set_placement((tx, ty), align=TextEntityAlignment.MIDDLE_CENTER)
                else:
                    tt = msp.add_text(ln_str, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": t_h})
                    tt.set_placement((cx, cy + offset), align=TextEntityAlignment.MIDDLE_CENTER)
            occupied_boxes.append((cx - hw, cy - hh, cx + hw, cy + hh))

        elif et == "weld_symbol":
            _draw_iso2553_weld_symbol(msp, el, ox, oy, inv_s, occupied_boxes)

        elif et == "tightness_tag":
            px = float(el["pos"][0]) + ox
            py = float(el["pos"][1]) + oy
            tag = str(el["tag"]).upper()
            bh = 4.2 * inv_s
            bw = max(len(tag) * 2.5 * inv_s + 3.0 * inv_s, 9.0 * inv_s)
            pts = [
                (px - bw / 2.0, py - bh / 2.0),
                (px + bw / 2.0, py - bh / 2.0),
                (px + bw / 2.0, py + bh / 2.0),
                (px - bw / 2.0, py + bh / 2.0),
            ]
            msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer("WELD_SYM"))
            tt = msp.add_text(tag, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.6 * inv_s})
            tt.set_placement((px, py), align=TextEntityAlignment.MIDDLE_CENTER)
            occupied_boxes.append((pts[0][0], pts[0][1], pts[2][0], pts[2][1]))


def _draw_iso2553_weld_symbol(
    msp,
    el: Dict,
    ox: float,
    oy: float,
    inv_s: float,
    occupied_boxes: List[Tuple[float, float, float, float]],
) -> None:
    """Draw a compliant ISO 2553 welding symbol (solid reference + dashed ID line + symbol + spec)."""
    bylayer = lambda lyr: {"layer": lyr, "color": 256, "linetype": "BYLAYER", "lineweight": -1}
    joint = (float(el["joint"][0]) + ox, float(el["joint"][1]) + oy)
    land = (float(el["landing"][0]) + ox, float(el["landing"][1]) + oy)
    arrow_spec = str(el.get("arrow_side", "")).strip()
    other_spec = str(el.get("other_side", "")).strip()
    weld_kind = str(el.get("weld_kind", "fillet")).lower()
    tail_note = str(el.get("tail", "")).strip()

    right_side = land[0] >= joint[0]
    sign = 1.0 if right_side else -1.0
    max_chars = max(len(arrow_spec), len(other_spec), 6)
    ref_len = max((max_chars * 2.0 + 10.0) * inv_s, 22.0 * inv_s)
    ref_end = (land[0] + sign * ref_len, land[1])

    # Leader line with filled arrow touching joint
    msp.add_line(joint, land, dxfattribs=bylayer("WELD_SYM"))
    _add_filled_arrow(msp, joint, joint[0] - land[0], joint[1] - land[1], 2.6 * inv_s, 1.0 * inv_s, "WELD_SYM")

    # ISO 2553 solid reference line + dashed identification line below it
    msp.add_line(land, ref_end, dxfattribs=bylayer("WELD_SYM"))
    id_y = land[1] - 1.3 * inv_s
    msp.add_line((land[0], id_y), (ref_end[0], id_y), dxfattribs=bylayer("HIDDEN"))

    # Weld elementary symbol (placed at 35% along reference line)
    sx = land[0] + sign * (ref_len * 0.30)
    sym_s = 3.2 * inv_s
    txt_h = 2.5 * inv_s

    def _draw_elementary(y_base: float, up: bool) -> None:
        d = 1.0 if up else -1.0
        if weld_kind == "fillet":
            # ISO 2553 right triangle (vertical leg on left)
            pts = [(sx, y_base), (sx, y_base + d * sym_s), (sx + sym_s, y_base)]
            msp.add_lwpolyline(pts, close=True, dxfattribs=bylayer("WELD_SYM"))
        elif weld_kind in ("v", "v-butt"):
            msp.add_line((sx, y_base + d * sym_s), (sx + sym_s / 2.0, y_base), dxfattribs=bylayer("WELD_SYM"))
            msp.add_line((sx + sym_s / 2.0, y_base), (sx + sym_s, y_base + d * sym_s), dxfattribs=bylayer("WELD_SYM"))
        else:
            msp.add_line((sx, y_base), (sx + sym_s, y_base + d * sym_s), dxfattribs=bylayer("WELD_SYM"))

    # Per ISO 2553: arrow side = solid line side (ABOVE); other side = dashed line side (BELOW)
    if arrow_spec:
        _draw_elementary(land[1], up=True)
        t = msp.add_text(arrow_spec, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
        tx = sx + sym_s + 1.5 * inv_s
        t.set_placement((tx, land[1] + 0.7 * inv_s), align=TextEntityAlignment.BOTTOM_LEFT)
    if other_spec:
        _draw_elementary(id_y, up=False)
        t = msp.add_text(other_spec, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": txt_h})
        tx = sx + sym_s + 1.5 * inv_s
        t.set_placement((tx, id_y - 0.7 * inv_s), align=TextEntityAlignment.TOP_LEFT)

    if tail_note:
        # Forked ISO 2553 tail
        msp.add_line(ref_end, (ref_end[0] + sign * 2.5 * inv_s, ref_end[1] + 2.2 * inv_s), dxfattribs=bylayer("WELD_SYM"))
        msp.add_line(ref_end, (ref_end[0] + sign * 2.5 * inv_s, ref_end[1] - 2.2 * inv_s), dxfattribs=bylayer("WELD_SYM"))
        tt = msp.add_text(tail_note, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": 2.2 * inv_s})
        tt.set_placement(
            (ref_end[0] + sign * 3.2 * inv_s, ref_end[1]),
            align=TextEntityAlignment.MIDDLE_LEFT if right_side else TextEntityAlignment.MIDDLE_RIGHT,
        )

    xmin_b = min(land[0], ref_end[0])
    xmax_b = max(land[0], ref_end[0]) + (12.0 * inv_s if tail_note else 0.0)
    occupied_boxes.append((xmin_b, id_y - 4.0 * inv_s, xmax_b, land[1] + 4.5 * inv_s))


def _build_bom_rows(bom: List[Dict], is_shipbuilding: bool):
    """Prepare structured headers, column alignments, row strings, and computed records."""
    if is_shipbuilding:
        headers = ["MARK", "DESCRIPTION / PROFILE", "GRADE", "SIZE (mm)", "P/S/TOT", "UNIT kg", "TOT kg", "THROW / TOE"]
        aligns = ["C", "L", "C", "C", "C", "R", "R", "C"]
        min_widths = [15.0, 32.0, 13.0, 22.0, 15.0, 14.0, 14.0, 19.0]
        banner = "MATERIAL LIST / BILL OF MATERIALS (SHIPBUILDING)"
    else:
        headers = ["ITEM", "DESCRIPTION", "MATERIAL", "QTY", "UNIT kg", "TOT kg", "REMARKS"]
        aligns = ["C", "L", "C", "C", "R", "R", "L"]
        min_widths = [11.0, 36.0, 18.0, 10.0, 14.0, 14.0, 24.0]
        banner = "BILL OF MATERIALS"

    rows_vals: List[List[str]] = []
    computed_records: List[Dict] = []
    grand_total_kg = 0.0

    for item in bom:
        qty_p = int(item.get("qty_p", 0))
        qty_s = int(item.get("qty_s", 0))
        qty_cl = int(item.get("qty_cl", 0))
        qty_tot = qty_p + qty_s + qty_cl
        unit_wt = compute_bom_item_weight_kg(item) or 0.0
        tot_wt = round(unit_wt * qty_tot, 2)
        grand_total_kg += tot_wt

        if item.get("kind") == "plate":
            thk = int(item.get("thickness_mm", 0))
            if item.get("width_mm") and item.get("length_mm"):
                size_str = f"{thk}x{int(item['width_mm'])}x{int(item['length_mm'])}"
            else:
                size_str = f"{thk} PL (RING)"
        elif item.get("length_mm"):
            size_str = f"L={int(item['length_mm'])}"
        else:
            size_str = "-"

        throw_toe = item.get("plate_throw") or item.get("toe_direction") or item.get("handing", "-")
        if item.get("plate_throw"):
            throw_toe = f"THK {item['plate_throw']}"
        elif item.get("toe_direction"):
            throw_toe = f"TOE {item['toe_direction']}"

        qty_col = f"CL({qty_cl})/{qty_tot}" if qty_cl > 0 and qty_p == 0 and qty_s == 0 else f"{qty_p}/{qty_s}/{qty_tot}"

        if is_shipbuilding:
            vals = [
                str(item["mark"]),
                str(item.get("profile") or item["description"]),
                str(item["grade"]),
                size_str,
                qty_col,
                f"{unit_wt:.1f}",
                f"{tot_wt:.1f}",
                throw_toe,
            ]
        else:
            vals = [
                str(item["mark"]),
                str(item["description"]),
                str(item["grade"]),
                str(qty_tot),
                f"{unit_wt:.2f}",
                f"{tot_wt:.2f}",
                str(item.get("remarks", "")),
            ]
        rows_vals.append(vals)
        computed_records.append({
            "mark": item["mark"],
            "qty_p": qty_p,
            "qty_s": qty_s,
            "qty_cl": qty_cl,
            "qty_tot": qty_tot,
            "unit_weight_kg": unit_wt,
            "total_weight_kg": tot_wt,
            "throw_toe": throw_toe,
        })

    return banner, headers, aligns, min_widths, rows_vals, computed_records, grand_total_kg


def compute_bom_layout_paperspace(
    bom: List[Dict],
    scale_vs_a3: float,
    is_shipbuilding: bool,
    max_table_w: float = 220.0,
) -> Dict:
    """
    Dynamically size every BOM column so every header and cell value is strictly
    enclosed with >= 2.0 mm horizontal padding on each side (zero cell overflow!).
    """
    sf = max(0.85, min(1.30, scale_vs_a3 ** 0.5))
    banner, headers, aligns, min_widths, rows_vals, computed_records, grand_total_kg = _build_bom_rows(
        bom, is_shipbuilding
    )
    txt_h_hdr = round(2.1 * sf, 2)
    txt_h_row = round(2.0 * sf, 2)
    cell_pad = 2.2 * sf  # >= 2.0 mm internal margin on left and right of text!

    # Conservative glyph advance for isocpeur.ttf (~0.80 * height)
    char_adv_hdr = txt_h_hdr * 0.80
    char_adv_row = txt_h_row * 0.80

    col_widths: List[float] = []
    for ci, hdr in enumerate(headers):
        req = max(min_widths[ci] * sf, len(hdr) * char_adv_hdr + 2.0 * cell_pad)
        for rvals in rows_vals:
            req = max(req, len(rvals[ci]) * char_adv_row + 2.0 * cell_pad)
        col_widths.append(round(req, 2))

    # Ensure total width is also >= banner width + padding
    banner_req = len(banner) * (2.6 * sf * 0.80) + 8.0 * sf
    total_w = sum(col_widths)
    if total_w < banner_req:
        extra = banner_req - total_w
        col_widths[1] = round(col_widths[1] + extra, 2)
        total_w = sum(col_widths)

    # If wider than max_table_w, scale columns proportionally (text auto-fits in cell below)
    if total_w > max_table_w:
        ratio = max_table_w / total_w
        col_widths = [round(w * ratio, 2) for w in col_widths]
        total_w = sum(col_widths)

    row_h = round(5.5 * sf, 2)
    hdr_h = round(6.4 * sf, 2)
    title_h = round(6.8 * sf, 2)
    total_h = round(title_h + hdr_h + (len(bom) + 1) * row_h, 2)

    return {
        "sf": sf,
        "banner": banner,
        "headers": headers,
        "aligns": aligns,
        "col_widths": col_widths,
        "rows_vals": rows_vals,
        "computed_records": computed_records,
        "grand_total_kg": grand_total_kg,
        "txt_h_hdr": txt_h_hdr,
        "txt_h_row": txt_h_row,
        "cell_pad": cell_pad,
        "row_h": row_h,
        "hdr_h": hdr_h,
        "title_h": title_h,
        "total_w": round(total_w, 2),
        "total_h": total_h,
    }


def draw_bom_table_paperspace(
    layout,
    bom: List[Dict],
    usable_zone: Dict[str, float],
    scale_vs_a3: float,
    is_shipbuilding: bool,
    corner: str = "top_right",
) -> Tuple[float, float, float, float, List[Dict], List[Dict]]:
    """
    Render a crisp ISO Material List / BOM table in Paper Space with auto-sized
    columns and strict cell-enclosure guarantees.
    Returns (xmin, ymin, xmax, ymax, computed_bom_records, bom_cells_paper).
    """
    bylayer = lambda lyr: {"layer": lyr, "color": 256, "linetype": "BYLAYER", "lineweight": -1}
    max_w = usable_zone["width"] * 0.56
    info = compute_bom_layout_paperspace(bom, scale_vs_a3, is_shipbuilding, max_table_w=max_w)

    sf = info["sf"]
    total_w = info["total_w"]
    total_h = info["total_h"]
    col_widths = info["col_widths"]
    headers = info["headers"]
    aligns = info["aligns"]
    cell_pad = info["cell_pad"]
    row_h = info["row_h"]
    hdr_h = info["hdr_h"]
    title_h = info["title_h"]

    xmax = usable_zone["xmax"] - 2.0
    xmin = xmax - total_w
    if corner == "bottom_right":
        ymin = usable_zone["ymin"] + 2.0
        ymax = ymin + total_h
    else:
        ymax = usable_zone["ymax"] - 2.0
        ymin = ymax - total_h

    def _add_fitted_cell_text(val: str, x0: float, y0: float, x1: float, y1: float, base_h: float, align_code: str) -> None:
        if not val:
            return
        avail = max(2.0, (x1 - x0) - 2.0 * (cell_pad * 0.85))
        est_w = len(val) * base_h * 0.80
        h = base_h
        wf = 1.0
        if est_w > avail:
            ratio = avail / est_w
            if ratio >= 0.72:
                wf = round(ratio, 3)
            else:
                wf = 0.75
                h = round(max(1.5, base_h * (ratio / 0.75)), 2)
        cy = (y0 + y1) / 2.0
        tv = layout.add_text(val, dxfattribs={**bylayer("TEXT"), "style": "ISO_TEXT", "height": h, "width": wf})
        if align_code == "L":
            tv.set_placement((x0 + cell_pad * 0.85, cy), align=TextEntityAlignment.MIDDLE_LEFT)
        elif align_code == "R":
            tv.set_placement((x1 - cell_pad * 0.85, cy), align=TextEntityAlignment.MIDDLE_RIGHT)
        else:
            tv.set_placement(((x0 + x1) / 2.0, cy), align=TextEntityAlignment.MIDDLE_CENTER)

    # Outer frame (heavy)
    layout.add_lwpolyline(
        [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)],
        close=True,
        dxfattribs=bylayer("TITLEBLOCK_HEAVY"),
    )

    bom_cells: List[Dict] = []

    # Banner title row
    y_hdr_top = ymax - title_h
    layout.add_line((xmin, y_hdr_top), (xmax, y_hdr_top), dxfattribs=bylayer("TITLEBLOCK"))
    _add_fitted_cell_text(info["banner"], xmin, y_hdr_top, xmax, ymax, round(2.6 * sf, 2), "C")
    bom_cells.append({"col": "BANNER", "text": info["banner"], "box": [round(xmin, 2), round(y_hdr_top, 2), round(xmax, 2), round(ymax, 2)]})

    # Header row
    y_cur = y_hdr_top - hdr_h
    layout.add_line((xmin, y_cur), (xmax, y_cur), dxfattribs=bylayer("TITLEBLOCK_HEAVY"))
    x_cur = xmin
    for cname, cw in zip(headers, col_widths):
        if x_cur > xmin + 0.01:
            layout.add_line((x_cur, ymin + row_h), (x_cur, y_hdr_top), dxfattribs=bylayer("TITLEBLOCK"))
        _add_fitted_cell_text(cname, x_cur, y_cur, x_cur + cw, y_hdr_top, info["txt_h_hdr"], "C")
        bom_cells.append({"col": cname, "text": cname, "box": [round(x_cur, 2), round(y_cur, 2), round(x_cur + cw, 2), round(y_hdr_top, 2)]})
        x_cur += cw

    # Data rows
    for rvals in info["rows_vals"]:
        y_next = y_cur - row_h
        layout.add_line((xmin, y_next), (xmax, y_next), dxfattribs=bylayer("TITLEBLOCK"))
        x_cur = xmin
        for cname, cw, acode, val in zip(headers, col_widths, aligns, rvals):
            _add_fitted_cell_text(val, x_cur, y_next, x_cur + cw, y_cur, info["txt_h_row"], acode)
            bom_cells.append({"col": cname, "text": val, "box": [round(x_cur, 2), round(y_next, 2), round(x_cur + cw, 2), round(y_cur, 2)]})
            x_cur += cw
        y_cur = y_next

    # Total steel mass footer row
    tot_lbl = f"TOTAL CALCULATED MASS:  {info['grand_total_kg']:.1f} kg"
    _add_fitted_cell_text(tot_lbl, xmin, ymin, xmax, ymin + row_h, round(2.2 * sf, 2), "R")
    bom_cells.append({"col": "TOTAL", "text": tot_lbl, "box": [round(xmin, 2), round(ymin, 2), round(xmax, 2), round(ymin + row_h, 2)]})

    return (xmin, ymin, xmax, ymax, info["computed_records"], bom_cells)
