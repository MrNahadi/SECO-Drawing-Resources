"""
Primary ISO engineering drawing standards & shipbuilding structural steel data.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

# Steel density: 7.85 t/m^3 = 7.85e-6 kg/mm^3
STEEL_DENSITY_KG_PER_MM3 = 7.85e-6

# ISO 5455 Preferred Engineering Scales: (label, model_to_paper_ratio)
ISO_SCALES: List[Tuple[str, float]] = [
    ("10:1", 10.0),
    ("5:1", 5.0),
    ("2:1", 2.0),
    ("1:1", 1.0),
    ("1:2", 0.5),
    ("1:5", 0.2),
    ("1:10", 0.1),
    ("1:20", 0.05),
    ("1:25", 0.04),
    ("1:50", 0.02),
    ("1:100", 0.01),
    ("1:200", 0.005),
    ("1:500", 0.002),
]

SHEET_ORDER = ["A4", "A3", "A2", "A1", "A0"]

# ISO 128-20 Line Precedence (lower index = higher precedence)
LAYER_PRECEDENCE: Dict[str, int] = {
    "VISIBLE": 0,
    "HIDDEN": 1,
    "CUTTING": 2,
    "CENTER": 3,
    "MOLDED_LINE": 4,
    "PHANTOM": 5,
    "FRAME_GRID": 6,
    "VOID_OPENING": 7,
    "DIM": 8,
    "HATCH": 9,
    "TEXT": 10,
    "WELD_SYM": 11,
}

# Approved semantic layers (must match Seco_master_ISO.dwt)
APPROVED_LAYERS = {
    "0",
    "VISIBLE",
    "HIDDEN",
    "CENTER",
    "CUTTING",
    "DIM",
    "HATCH",
    "VOID_OPENING",
    "PHANTOM",
    "TEXT",
    "TITLEBLOCK",
    "TITLEBLOCK_HEAVY",
    "VIEWPORT",
    "MOLDED_LINE",
    "FRAME_GRID",
    "WELD_SYM",
    "REV_CLOUD",
}

# EN 10067 Standard Shipbuilding Bulb Flats (HP h x t) -> nominal linear mass (kg/m)
EN10067_HP_KG_PER_M: Dict[Tuple[int, int], float] = {
    (80, 5): 3.92,
    (80, 6): 4.55,
    (100, 6): 5.83,
    (100, 7): 6.62,
    (100, 8): 7.40,
    (120, 6): 7.12,
    (120, 7): 8.06,
    (120, 8): 9.01,
    (140, 7): 9.57,
    (140, 8): 10.70,
    (140, 9): 11.80,
    (160, 7): 11.40,
    (160, 8): 12.70,
    (160, 9): 14.00,
    (180, 8): 14.80,
    (180, 9): 16.20,
    (180, 10): 17.60,
    (200, 9): 18.50,
    (200, 10): 20.10,
    (200, 11): 21.70,
    (220, 10): 22.80,
    (220, 11): 24.50,
    (220, 12): 26.20,
    (240, 10): 25.40,
    (240, 11): 27.30,
    (240, 12): 29.20,
    (260, 10): 28.30,
    (260, 11): 30.30,
    (260, 12): 32.40,
    (280, 11): 33.50,
    (280, 12): 35.70,
    (300, 11): 36.70,
    (300, 12): 39.00,
    (320, 12): 42.50,
}

# ISO 2553 valid weld syntax patterns
# Examples: "a5", "a6 CONT", "a5 100(200)", "a5 100-200", "z7", "V-BUTT", "X-BUTT 100% UT"
WELD_FILLET_RE = re.compile(
    r"^(?P<dim_type>[az])(?P<size>\d+(?:\.\d+)?)(?:\s+(?P<len>\d+)\((?P<pitch>\d+)\)|\s+(?P<clen>\d+)-(?P<cpitch>\d+)|\s+CONT\.?)?(?:\s+.*)?$",
    re.IGNORECASE,
)
WELD_BUTT_RE = re.compile(
    r"^(?:V|X|K|U|J|1/2\s*V|FULL\s*PEN|BUTT)(?:\s*-?\s*BUTT)?(?:\s+.*)?$",
    re.IGNORECASE,
)

VALID_PLATE_THROWS = {"FWD", "AFT", "ABV", "BLW", "INBD", "OUTBD", "PORT", "STBD", "CL", "SYM"}
VALID_TOE_DIRS = {"FWD", "AFT", "UP", "DOWN", "INBD", "OUTBD", "PORT", "STBD", "LEFT", "RIGHT", "SYM"}


def parse_scale(label: str) -> float:
    parts = label.strip().split(":")
    if len(parts) != 2:
        raise ValueError(f"Invalid ISO scale format: {label!r}")
    return float(parts[0]) / float(parts[1])


def profile_linear_mass_kg_per_m(profile_str: str) -> Optional[float]:
    """
    Compute nominal linear steel mass (kg/m) from standard marine profile callouts:
      - 'HP 180x9' (EN 10067 bulb flat)
      - 'FB 150x12' (flat bar)
      - 'L 100x75x8' (angle)
      - 'T 300x10/150x12' (built-up T-bar)
    """
    s = profile_str.strip().upper().replace("×", "X")

    m_hp = re.match(r"^HP\s*(\d+)\s*X\s*(\d+)$", s)
    if m_hp:
        h, t = int(m_hp.group(1)), int(m_hp.group(2))
        if (h, t) in EN10067_HP_KG_PER_M:
            return EN10067_HP_KG_PER_M[(h, t)]
        # Approximation for non-tabulated HP sizes (~1.22x web area)
        return round(h * t * 1.22 * 0.00785, 2)

    m_fb = re.match(r"^FB\s*(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)$", s)
    if m_fb:
        h, t = float(m_fb.group(1)), float(m_fb.group(2))
        return round(h * t * 0.00785, 2)

    m_l = re.match(r"^L\s*(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)$", s)
    if m_l:
        a, b, t = float(m_l.group(1)), float(m_l.group(2)), float(m_l.group(3))
        area_mm2 = (a + b - t) * t
        return round(area_mm2 * 0.00785, 2)

    m_t = re.match(
        r"^T\s*(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)$",
        s,
    )
    if m_t:
        wh, wt, fw, ft = map(float, m_t.groups())
        area_mm2 = wh * wt + fw * ft
        return round(area_mm2 * 0.00785, 2)

    return None


def compute_bom_item_weight_kg(item: Dict) -> Optional[float]:
    """Deterministically compute unit weight (kg) from geometry/profile specs."""
    kind = item.get("kind")
    if kind == "plate":
        t = item.get("thickness_mm")
        if t is None:
            return None
        if "net_area_mm2" in item and item["net_area_mm2"] is not None:
            area = float(item["net_area_mm2"])
        elif "width_mm" in item and "length_mm" in item:
            area = float(item["width_mm"]) * float(item["length_mm"]) - float(item.get("cutout_area_mm2", 0.0))
        else:
            return None
        return round(max(0.0, area) * float(t) * STEEL_DENSITY_KG_PER_MM3, 2)

    if kind in ("profile", "bar"):
        prof = item.get("profile") or item.get("description", "")
        kg_m = profile_linear_mass_kg_per_m(prof)
        length = item.get("length_mm")
        if kg_m is not None and length is not None:
            return round(kg_m * (float(length) / 1000.0), 2)
    return item.get("unit_weight_kg")


def validate_weld_spec(spec_text: str) -> bool:
    s = spec_text.strip()
    return bool(WELD_FILLET_RE.match(s) or WELD_BUTT_RE.match(s))
