"""
Input intake & engineering ambiguity/completeness gate.

Validates a drawing specification against the formal JSON Schema and checks
engineering completeness (both general mechanical and shipbuilding rules).
Refuses to silently guess missing critical engineering data.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

import jsonschema
import yaml

from .standards import (
    VALID_PLATE_THROWS,
    VALID_TOE_DIRS,
    compute_bom_item_weight_kg,
    validate_weld_spec,
)

SKILL_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = SKILL_ROOT / "references" / "drawing_spec_schema.json"


@dataclass
class IntakeReport:
    ok: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    discipline: str = ""


def load_spec(spec_path: Path) -> Dict:
    raw = spec_path.read_text(encoding="utf-8")
    if spec_path.suffix.lower() in (".yaml", ".yml"):
        return yaml.safe_load(raw)
    return json.loads(raw)


def run_intake_gate(spec: Dict) -> IntakeReport:
    errors: List[str] = []
    warnings: List[str] = []

    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = jsonschema.Draft7Validator(schema)
    for err in sorted(validator.iter_errors(spec), key=lambda e: list(e.path)):
        loc = ".".join(str(p) for p in err.path) or "<root>"
        errors.append(f"Schema violation at {loc}: {err.message}")

    discipline = spec.get("discipline", "")
    meta = spec.get("metadata", {})
    std = spec.get("standard", {})

    if not meta.get("material") and not spec.get("ship_context", {}).get("steel_grade"):
        errors.append("Missing material / steel grade specification (must not be invented).")

    if std.get("units", "mm") != "mm":
        errors.append(f"Unsupported units {std.get('units')!r}; SECO standard requires 'mm'.")

    # View-level & shipbuilding completeness checks
    is_ship = discipline.startswith("shipbuilding")
    ship_ctx = spec.get("ship_context", {})

    if is_ship:
        if not ship_ctx:
            errors.append("Shipbuilding drawing requires 'ship_context' (frame spacing, steel grade, tightness).")
        else:
            if not ship_ctx.get("frame_spacing_mm"):
                errors.append("Shipbuilding ambiguity: 'ship_context.frame_spacing_mm' is missing.")
            if not ship_ctx.get("steel_grade"):
                errors.append("Shipbuilding ambiguity: 'ship_context.steel_grade' (e.g. GR.A, AH36) is missing.")
            if not ship_ctx.get("tightness"):
                errors.append("Shipbuilding ambiguity: 'ship_context.tightness' (WT/OT/GT/NT) is missing.")

    views = spec.get("views", [])
    view_ids = {v.get("id") for v in views}
    for v in views:
        vid = v.get("id", "<unnamed>")
        align_to = v.get("align_to")
        if align_to and align_to not in view_ids:
            errors.append(f"View {vid!r} align_to={align_to!r} references unknown view id.")

        if is_ship:
            if not v.get("view_direction"):
                errors.append(f"Shipbuilding view {vid!r} missing mandatory 'view_direction' (e.g., 'LKG FWD', 'PLAN VIEW').")
            if not v.get("orientation_marker"):
                errors.append(f"Shipbuilding view {vid!r} missing mandatory 'orientation_marker' (e.g., 'FWD ->' or 'CL / PORT-STBD').")

            # Check frame spacing consistency if frame_grid has >= 2 frames
            fg = v.get("frame_grid", {})
            frames = fg.get("frames", [])
            fspace = ship_ctx.get("frame_spacing_mm")
            if len(frames) >= 2 and fspace:
                f0 = frames[0]
                for fi in frames[1:]:
                    expected = f0["coord"] + (fi["fr"] - f0["fr"]) * fspace
                    if abs(fi["coord"] - expected) > 0.5:
                        errors.append(
                            f"View {vid!r} frame FR {fi['fr']} at {fi['coord']} mm contradicts "
                            f"frame_spacing_mm={fspace} from FR {f0['fr']} (expected {expected})."
                        )

        # Validate element-level marine rules
        for idx, el in enumerate(v.get("elements", [])):
            et = el.get("type")
            if et == "molded_line":
                throw = str(el.get("throw", "")).upper()
                if throw not in VALID_PLATE_THROWS:
                    errors.append(
                        f"View {vid!r} element[{idx}] molded_line has invalid/missing plate throw {throw!r}; "
                        f"must be one of {sorted(VALID_PLATE_THROWS)}."
                    )
            elif et == "stiffener":
                toe = str(el.get("toe_direction", "")).upper()
                if toe not in VALID_TOE_DIRS:
                    errors.append(
                        f"View {vid!r} element[{idx}] stiffener missing valid 'toe_direction' ({toe!r})."
                    )
                if not el.get("profile"):
                    errors.append(f"View {vid!r} element[{idx}] stiffener missing 'profile' callout (e.g. 'HP 180x9').")
            elif et == "weld_symbol":
                wtxt = el.get("arrow_side", "") or el.get("other_side", "")
                if not wtxt or not validate_weld_spec(wtxt):
                    errors.append(
                        f"View {vid!r} element[{idx}] weld_symbol has invalid ISO 2553 spec: {wtxt!r}."
                    )

        # Check for ungrounded/overridden dimension traps
        for didx, dim in enumerate(v.get("dimensions", [])):
            if "override_text" in dim:
                errors.append(
                    f"View {vid!r} dimension[{didx}] attempts to override measured value; "
                    "dimensions must measure true Model Space geometry."
                )

    # BOM completeness & marine throw/weight checks
    bom = spec.get("bom", [])
    if is_ship and not bom:
        errors.append("Shipbuilding drawing requires a Material List / BOM ('bom').")
    for item in bom:
        mark = item.get("mark", "?")
        if is_ship and item.get("kind") == "plate":
            throw = str(item.get("plate_throw", "")).upper()
            if throw not in VALID_PLATE_THROWS:
                errors.append(f"BOM plate {mark!r} missing valid 'plate_throw' ({throw!r}).")
        if is_ship and item.get("kind") == "profile":
            toe = str(item.get("toe_direction", "")).upper()
            if toe not in VALID_TOE_DIRS:
                errors.append(f"BOM profile {mark!r} missing valid 'toe_direction' ({toe!r}).")
        w = compute_bom_item_weight_kg(item)
        if w is None:
            warnings.append(f"BOM item {mark!r} weight could not be auto-computed from geometry/profile.")

    return IntakeReport(ok=(len(errors) == 0), errors=errors, warnings=warnings, discipline=discipline)
