#!/usr/bin/env python3
"""
Build and audit the sanitized SECO ISO master drawing template (`Seco_master_ISO.dwt`
and `Seco_master_ISO.dxf`) directly from the raw `Seco_drawing_template.dwt`.

Rebuilds into a pristine R2018 (AC1032) CAD database to eliminate all legacy
dictionary bloat and headless-breaking OLE2FRAME objects, while preserving SECO's
exact sheet borders, zone grids (A-F, 1-8), title-block geometry, SECO vector emblem,
and a clean native vector SGS ISO 9001 badge:
  - Normalizes header to ISO metric ($INSUNITS=4, $MEASUREMENT=1, $PSLTSCALE=1, $LTSCALE=1.0)
  - Keeps Model Space 100% clean (0 entities)
  - Installs native ISO 128 linetypes from acadiso.lin (HIDDEN2, CENTER2, PHANTOM2, DASHDOT2)
  - Enforces a strict ISO 128 (0.50 / 0.25 mm group) + Marine semantic layer table
  - Replaces Comic Sans and fixed-height styles with ISO 3098 (`isocpeur.ttf`) & `arial.ttf`
  - Installs ISO 129-1 associative DIMSTYLE (`SECO_ISO_MM`)
  - Normalizes A4 origin to (0, 0) and removes all stray off-sheet viewports
  - Strips all stale job strings and replaces variable fields with an attributed BLOCK
    (`SECO_TBLOCK_<SIZE>`) + ISO 5456-2 projection symbol (`ISO_PROJ_FIRST`)
  - Round-trips through AutoCAD 2027 (`accoreconsole.exe`) with AUDIT, native DWT/DXF
    save, and a monochrome A3 PDF plot check.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

import ezdxf
from ezdxf.enums import TextEntityAlignment

ACCORECONSOLE = Path(r"C:\Program Files\Autodesk\AutoCAD 2027\accoreconsole.exe")

# ISO 128 (0.50 / 0.25 mm line group) + Marine semantic layers
# Restrained, predominantly monochrome CAD screen palette (7=White, 8/9=Gray)
# with minimal functional accents (1=Red axes/cutting, 4=Cyan dims, 3=Green ML, 6=Magenta rev cloud)
# Format: name -> (aci_color, linetype, lineweight_hundredths_mm, plot_flag)
ISO_LAYERS: Dict[str, Tuple[int, str, int, int]] = {
    "0": (7, "Continuous", -3, 1),
    "VISIBLE": (7, "Continuous", 50, 1),
    "HIDDEN": (8, "HIDDEN2", 35, 1),
    "CENTER": (1, "CENTER2", 25, 1),
    "CUTTING": (1, "DASHDOT2", 50, 1),
    "DIM": (4, "Continuous", 25, 1),
    "HATCH": (8, "Continuous", 25, 1),
    "VOID_OPENING": (8, "Continuous", 25, 1),
    "PHANTOM": (8, "PHANTOM2", 25, 1),
    "TEXT": (7, "Continuous", 25, 1),
    "TITLEBLOCK": (7, "Continuous", 25, 1),
    "TITLEBLOCK_HEAVY": (7, "Continuous", 50, 1),
    "VIEWPORT": (9, "Continuous", 18, 0),
    # Shipbuilding / Marine layers
    "MOLDED_LINE": (3, "PHANTOM2", 25, 1),
    "FRAME_GRID": (9, "CENTER2", 18, 1),
    "WELD_SYM": (7, "Continuous", 25, 1),
    "REV_CLOUD": (6, "Continuous", 35, 1),
}

# Native acadiso.lin metric patterns (paper mm when PSLTSCALE=1, LTSCALE=1.0)
ISO_LINETYPES: Dict[str, Tuple[str, List[float]]] = {
    "HIDDEN2": ("Hidden (.5x) _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _", [4.7625, 3.175, -1.5875]),
    "CENTER2": ("Center (.5x) ___ _ ___ _ ___ _ ___ _ ___ _ ___", [28.575, 19.05, -3.175, 3.175, -3.175]),
    "PHANTOM2": ("Phantom (.5x) ___ _ _ ___ _ _ ___ _ _ ___ _ _", [31.75, 15.875, -3.175, 3.175, -3.175, 3.175, -3.175]),
    "DASHDOT2": ("Dash dot (.5x) _._._._._._._._._._._._._._._.", [12.7, 6.35, -3.175, 0.0, -3.175]),
}

SHEET_SPECS = {
    "a0": ("A0", 1189.0, 841.0, "ISO_full_bleed_A0_(1189.00_x_841.00_MM)", "ISO full bleed A0 (1189.00 x 841.00 MM)", 2.8284271),
    "a1": ("A1", 841.0, 594.0, "ISO_full_bleed_A1_(594.00_x_841.00_MM)", "ISO full bleed A1 (594.00 x 841.00 MM)", 2.0),
    "a2": ("A2", 594.0, 420.0, "ISO_full_bleed_A2_(420.00_x_594.00_MM)", "ISO full bleed A2 (420.00 x 594.00 MM)", 1.4142136),
    "a3": ("A3", 420.0, 297.0, "ISO_full_bleed_A3_(420.00_x_297.00_MM)", "ISO full bleed A3 (420.00 x 297.00 MM)", 1.0),
    "a4": ("A4", 297.0, 210.0, "ISO_full_bleed_A4_(210.00_x_297.00_MM)", "ISO full bleed A4 (210.00 x 297.00 MM)", 0.7071068),
}

STALE_EXACT = {
    "ALPHA LOGISTIOCS",
    "ALPHAHEK",
    "FOUNDATION DETAIL",
    "NWN",
    "12/03/25",
    "name",
    "---/----/---/---.",
    "1:1",
    "01 OF 01",
    "MOMBASA",
    "KENYA",
}

# A3 canonical attribute coordinates (measured directly from SECO A3 boxes)
# tag -> (x_a3, y_a3, height_a3, default_value, prompt)
A3_ATTR_LAYOUT: Dict[str, Tuple[float, float, float, str, str]] = {
    "CLIENT":      (364.2, 31.8, 1.8, "", "Client name"),
    "PROJECT":     (364.2, 26.3, 1.8, "", "Project name"),
    "SITE":        (355.0, 22.1, 1.4, "MOMBASA", "Site"),
    "COUNTRY":     (391.4, 21.8, 1.4, "KENYA", "Country"),
    "PROJECT_NO":  (364.2, 17.5, 1.5, "", "Project number"),
    "DRG_NO":      (360.5, 13.0, 1.7, "", "Drawing number"),
    "SHEET":       (392.4, 14.3, 1.4, "01 OF 01", "Sheet number"),
    "SCALE":       (331.2, 13.7, 1.5, "1:1", "Drawing scale"),
    "TITLE":       (246.0, 22.8, 2.6, "", "Drawing title"),
    "SUBTITLE":    (246.0, 18.8, 1.8, "", "Drawing subtitle / block"),
    "REF_DRG":     (246.0, 30.2, 1.3, "N/A", "Reference drawings"),
    "DRAWN_BY":    (331.3, 28.7, 1.25, "SECO", "Drawn by"),
    "DRAWN_DATE":  (337.7, 28.7, 1.05, "", "Drawn date"),
    "CHKD_BY":     (331.3, 24.1, 1.25, "", "Checked by"),
    "CHKD_DATE":   (337.7, 24.1, 1.05, "", "Checked date"),
    "APPD_BY":     (331.3, 19.3, 1.25, "", "Approved by"),
    "APPD_DATE":   (337.7, 19.3, 1.05, "", "Approved date"),
    "REV_0_DESC":  (18.0,  16.7, 1.25, "ISSUED FOR CONSTRUCTION", "Rev 0 description"),
    "REV_0_DATE":  (58.0,  16.7, 1.05, "", "Rev 0 date"),
    "REV_0_DRN":   (69.0,  16.7, 1.2, "SECO", "Rev 0 drawn"),
    "REV_0_CHK":   (76.3,  16.7, 1.2, "", "Rev 0 checked"),
    "REV_0_APP":   (83.2,  16.7, 1.2, "", "Rev 0 approved"),
    "NOTE_1":      (96.0,  24.5, 1.6, "1. ALL DIMENSIONS IN MM UNLESS OTHERWISE INDICATED.", "General note 1"),
    "NOTE_2":      (96.0,  21.4, 1.6, "2. GENERAL TOLERANCES: ISO 2768-mK.", "General note 2"),
    "NOTE_3":      (96.0,  18.3, 1.6, "3. REMOVE ALL SHARP EDGES AND BURRS.", "General note 3"),
    "NOTE_4":      (96.0,  15.2, 1.6, "4. DO NOT SCALE DRAWING.", "General note 4"),
    "NOTE_5":      (96.0,  12.1, 1.6, "", "General note 5"),
}


def run_accore(input_file: Path, script_lines: List[str], timeout: int = 60) -> str:
    if not ACCORECONSOLE.exists():
        raise FileNotFoundError(f"AutoCAD Core Console not found at {ACCORECONSOLE}")
    with tempfile.NamedTemporaryFile("w", suffix=".scr", delete=False, encoding="ascii", newline="\r\n") as f:
        f.write("\n".join(script_lines) + "\n")
        scr_path = Path(f.name)
    try:
        proc = subprocess.run(
            [str(ACCORECONSOLE), "/i", str(input_file), "/s", str(scr_path), "/l", "en-US"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        raw = proc.stdout
        try:
            text = raw.decode("utf-16-le", errors="ignore")
        except Exception:
            text = raw.decode("utf-8", errors="ignore")
        if not text.strip():
            text = proc.stderr.decode("utf-8", errors="ignore")
        return text
    finally:
        scr_path.unlink(missing_ok=True)


def add_projection_blocks(doc: ezdxf.document.Drawing) -> None:
    """Create ISO 5456-2 First-Angle and Third-Angle projection symbol blocks (10 mm height)."""
    for name, first_angle in (("ISO_PROJ_FIRST", True), ("ISO_PROJ_THIRD", False)):
        blk = doc.blocks.new(name=name)
        if first_angle:
            # ISO 5456-2 First-Angle: truncated cone on LEFT (tall left, short right), circles on RIGHT
            cone_pts = [(0.0, -5.0), (10.0, -2.5), (10.0, 2.5), (0.0, 5.0)]
            cx = 17.0
            cl_x0, cl_x1 = -2.0, 23.5
        else:
            # ISO 5456-2 Third-Angle: concentric circles on LEFT, truncated cone on RIGHT
            cx = 5.0
            cone_pts = [(12.0, -2.5), (22.0, -5.0), (22.0, 5.0), (12.0, 2.5)]
            cl_x0, cl_x1 = -1.5, 24.0

        bylayer = {"layer": "TITLEBLOCK", "color": 256, "linetype": "BYLAYER", "lineweight": -1}
        blk.add_lwpolyline(cone_pts, close=True, dxfattribs=bylayer)
        blk.add_circle((cx, 0.0), radius=5.0, dxfattribs=bylayer)
        blk.add_circle((cx, 0.0), radius=2.5, dxfattribs=bylayer)
        blk.add_line(
            (cl_x0, 0.0), (cl_x1, 0.0),
            dxfattribs={"layer": "CENTER", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
        )
        blk.add_line(
            (cx, -6.5), (cx, 6.5),
            dxfattribs={"layer": "CENTER", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
        )


def add_sgs_badge_block(doc: ezdxf.document.Drawing) -> None:
    """
    Authentic colored vector SGS ISO 9001 certification badge using 24-bit TrueColor
    RGB fills sampled directly from the original SECO template:
      - SGS Orange: (254, 104, 7)
      - SGS Gray:   (141, 142, 141)
      - White check: (255, 255, 255)
    TrueColor bypasses `monochrome.ctb` so the badge ALWAYS plots in color.
    """
    blk = doc.blocks.new(name="SECO_ISO9001_BADGE")
    sgs_orange = (254, 104, 7)
    sgs_gray = (141, 142, 141)
    sgs_white = (255, 255, 255)
    base_attr = {"layer": "TITLEBLOCK", "linetype": "BYLAYER", "lineweight": -1}

    def _arc_ring_poly(r_in: float, r_out: float, a0_deg: float, a1_deg: float, steps: int = 36):
        pts = []
        for i in range(steps + 1):
            ang = math.radians(a0_deg + (a1_deg - a0_deg) * i / steps)
            pts.append((r_out * math.cos(ang), r_out * math.sin(ang)))
        for i in range(steps, -1, -1):
            ang = math.radians(a0_deg + (a1_deg - a0_deg) * i / steps)
            pts.append((r_in * math.cos(ang), r_in * math.sin(ang)))
        return pts

    def _circle_poly(r: float, steps: int = 48):
        return [(r * math.cos(2 * math.pi * i / steps), r * math.sin(2 * math.pi * i / steps)) for i in range(steps)]

    # 1. Outer SGS Gray ring arc (from -20 deg counter-clockwise to 185 deg -> top & right)
    h_gray = blk.add_hatch(dxfattribs=base_attr)
    h_gray.set_solid_fill(rgb=sgs_gray)
    h_gray.paths.add_polyline_path(_arc_ring_poly(4.0, 5.1, -20.0, 185.0, 40), is_closed=True)

    # 2. Lower-left SGS Orange arc (from 185 deg to 275 deg)
    h_org_arc = blk.add_hatch(dxfattribs=base_attr)
    h_org_arc.set_solid_fill(rgb=sgs_orange)
    h_org_arc.paths.add_polyline_path(_arc_ring_poly(4.0, 5.1, 185.0, 275.0, 24), is_closed=True)

    # 3. Inner solid SGS Orange circle with bold white checkmark cut out as island
    check_poly = [
        (-1.85, 0.05),
        (-1.25, 0.65),
        (-0.35, -0.35),
        (1.45, 1.55),
        (2.05, 0.95),
        (-0.35, -1.60),
    ]
    h_disk = blk.add_hatch(dxfattribs=base_attr)
    h_disk.set_solid_fill(rgb=sgs_orange)
    h_disk.paths.add_polyline_path(_circle_poly(3.25, 48), is_closed=True)
    h_disk.paths.add_polyline_path(check_poly, is_closed=True)

    # Explicit white fill inside checkmark (ensures crisp white regardless of viewer background)
    h_chk = blk.add_hatch(dxfattribs=base_attr)
    h_chk.set_solid_fill(rgb=sgs_white)
    h_chk.paths.add_polyline_path(check_poly, is_closed=True)

    # 4. Colored 'SGS' mark (bottom-right) and 'ISO 9001' caption in SGS Gray / Orange
    t_sgs = blk.add_text("SGS", dxfattribs={**base_attr, "style": "SECO_TBLOCK", "height": 1.45})
    t_sgs.rgb = sgs_orange
    t_sgs.set_placement((4.1, -4.3), align=TextEntityAlignment.MIDDLE_CENTER)

    t_iso = blk.add_text("ISO 9001", dxfattribs={**base_attr, "style": "SECO_TBLOCK", "height": 1.15})
    t_iso.rgb = sgs_gray
    t_iso.set_placement((-0.6, -6.1), align=TextEntityAlignment.MIDDLE_CENTER)


def copy_clean_entity(src_ent, target_space, dx: float, dy: float, pw: float, ph: float) -> None:
    """Recreate vector border/title-block entities cleanly into a fresh R2018 layout."""
    etype = src_ent.dxftype()
    bylayer = {"layer": "TITLEBLOCK", "color": 256, "linetype": "BYLAYER", "lineweight": -1}

    if etype == "LINE":
        s = src_ent.dxf.start
        e = src_ent.dxf.end
        target_space.add_line((s.x + dx, s.y + dy), (e.x + dx, e.y + dy), dxfattribs=bylayer)

    elif etype == "LWPOLYLINE":
        pts = [(p[0] + dx, p[1] + dy, p[2], p[3], p[4]) for p in src_ent.get_points("xyseb")]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        span_x = (max(xs) - min(xs)) if xs else 0.0
        span_y = (max(ys) - min(ys)) if ys else 0.0
        layer = "TITLEBLOCK_HEAVY" if (src_ent.closed and span_x > 0.85 * pw and span_y > 0.80 * ph) else "TITLEBLOCK"
        target_space.add_lwpolyline(
            pts,
            format="xyseb",
            close=src_ent.closed,
            dxfattribs={"layer": layer, "color": 256, "linetype": "BYLAYER", "lineweight": -1},
        )

    elif etype == "ARC":
        c = src_ent.dxf.center
        target_space.add_arc(
            (c.x + dx, c.y + dy),
            radius=src_ent.dxf.radius,
            start_angle=src_ent.dxf.start_angle,
            end_angle=src_ent.dxf.end_angle,
            dxfattribs=bylayer,
        )

    elif etype == "CIRCLE":
        c = src_ent.dxf.center
        target_space.add_circle((c.x + dx, c.y + dy), radius=src_ent.dxf.radius, dxfattribs=bylayer)

    elif etype == "SPLINE":
        try:
            ctrl = [(p[0] + dx, p[1] + dy, 0.0) for p in src_ent.control_points]
            if len(ctrl) >= 2:
                sp = target_space.add_open_spline(ctrl, degree=min(src_ent.dxf.degree, len(ctrl) - 1), dxfattribs=bylayer)
        except Exception:
            pass

    elif etype == "TEXT":
        raw_txt = src_ent.dxf.text.strip()
        if not raw_txt or raw_txt in STALE_EXACT or "All dimensions in" in raw_txt:
            return
        p = src_ent.dxf.insert
        h = max(0.8, float(src_ent.dxf.height))
        t = target_space.add_text(
            src_ent.dxf.text,
            dxfattribs={
                "layer": "TITLEBLOCK",
                "style": "SECO_TBLOCK",
                "height": h,
                "rotation": float(src_ent.dxf.get("rotation", 0.0)),
                "width": float(src_ent.dxf.get("width", 0.85)),
                "color": 256,
                "linetype": "BYLAYER",
                "lineweight": -1,
            },
        )
        t.dxf.insert = (p.x + dx, p.y + dy, 0.0)

    elif etype == "MTEXT":
        raw_txt = src_ent.plain_text().strip()
        if not raw_txt or raw_txt in STALE_EXACT or "All dimensions in" in raw_txt:
            return
        p = src_ent.dxf.insert
        h = max(0.8, float(src_ent.dxf.char_height))
        target_space.add_text(
            raw_txt,
            dxfattribs={
                "layer": "TITLEBLOCK",
                "style": "SECO_TBLOCK",
                "height": h,
                "color": 256,
                "linetype": "BYLAYER",
                "lineweight": -1,
            },
        ).dxf.insert = (p.x + dx, p.y + dy, 0.0)

    elif etype == "INSERT" and src_ent.dxf.name == "A$C2F48788A":
        p = src_ent.dxf.insert
        target_space.add_blockref(
            "SECO_LOGO",
            insert=(p.x + dx, p.y + dy),
            dxfattribs={
                "layer": "TITLEBLOCK",
                "xscale": float(src_ent.dxf.xscale),
                "yscale": float(src_ent.dxf.yscale),
                "zscale": float(src_ent.dxf.zscale),
                "rotation": float(src_ent.dxf.get("rotation", 0.0)),
                "color": 256,
                "linetype": "BYLAYER",
                "lineweight": -1,
            },
        )


def build_master_template(source_dwt: Path, out_dir: Path) -> Dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        raw_dwg = tmp_path / "raw_template.dwg"
        raw_dxf = tmp_path / "raw_template.dxf"
        shutil.copy2(source_dwt, raw_dwg)

        print("[1/5] Exporting raw .dwt to DXF via AutoCAD Core Console...", flush=True)
        run_accore(raw_dwg, ["DXFOUT", f'"{raw_dxf}"', "16", "QUIT", "N"])
        if not raw_dxf.exists():
            raise RuntimeError("Failed to export raw template to DXF via accoreconsole.exe")

        print("[2/5] Rebuilding pristine ISO R2018 master database...", flush=True)
        src = ezdxf.readfile(str(raw_dxf))
        doc = ezdxf.new("R2018", setup=False)

        # 1. Header normalized to ISO metric
        doc.header["$INSUNITS"] = 4
        doc.header["$MEASUREMENT"] = 1
        doc.header["$LUNITS"] = 2
        doc.header["$LUPREC"] = 2
        doc.header["$AUNITS"] = 0
        doc.header["$AUPREC"] = 1
        doc.header["$LTSCALE"] = 1.0
        doc.header["$PSLTSCALE"] = 1
        doc.header["$CELTSCALE"] = 1.0
        doc.header["$DIMSCALE"] = 1.0
        doc.header["$LWDISPLAY"] = 1
        doc.header["$PSTYLEMODE"] = 1
        doc.header["$CECOLOR"] = 256
        doc.header["$CELTYPE"] = "BYLAYER"
        doc.header["$CELWEIGHT"] = -1

        # 2. Native ISO 128 linetypes
        for lt_name, (desc, pattern) in ISO_LINETYPES.items():
            doc.linetypes.add(lt_name, pattern=pattern, description=desc)

        # 3. Strict ISO 128 + Marine semantic layers
        for lname, (color, ltype, lw, plot_flag) in ISO_LAYERS.items():
            lay_obj = doc.layers.get(lname) if lname in doc.layers else doc.layers.add(lname)
            lay_obj.dxf.color = color
            lay_obj.dxf.linetype = ltype
            lay_obj.dxf.lineweight = lw
            lay_obj.dxf.plot = plot_flag

        # 4. ISO 3098 Text Styles
        for st_name, font_name, width_factor in (
            ("Standard", "isocpeur.ttf", 1.0),
            ("ISO_TEXT", "isocpeur.ttf", 1.0),
            ("SECO_TBLOCK", "arial.ttf", 0.85),
        ):
            st = doc.styles.get(st_name) if st_name in doc.styles else doc.styles.add(st_name, font=font_name)
            st.dxf.font = font_name
            st.dxf.height = 0.0
            st.dxf.width = width_factor

        # 5. ISO 129-1 Associative DIMSTYLE
        ds = doc.dimstyles.new("SECO_ISO_MM")
        ds.dxf.dimtxsty = "ISO_TEXT"
        ds.dxf.dimtxt = 2.5
        ds.dxf.dimasz = 2.5
        ds.dxf.dimexo = 1.25
        ds.dxf.dimexe = 2.0
        ds.dxf.dimgap = 1.0
        ds.dxf.dimtad = 1
        ds.dxf.dimtih = 0
        ds.dxf.dimtoh = 0
        ds.dxf.dimtix = 0
        ds.dxf.dimtofl = 1
        ds.dxf.dimdec = 2
        ds.dxf.dimzin = 8
        ds.dxf.dimdsep = 46
        ds.dxf.dimlfac = 1.0
        ds.dxf.dimscale = 1.0
        ds.dxf.dimclrd = 256
        ds.dxf.dimclre = 256
        ds.dxf.dimclrt = 256
        ds.dxf.dimlwd = -1
        ds.dxf.dimlwe = -1
        doc.header["$DIMSTYLE"] = "SECO_ISO_MM"

        # 6. Copy SECO vector logo block cleanly (`A$C2F48788A` -> `SECO_LOGO`)
        # Preserve SECO's exact corporate Red/Green SOLID fills using 24-bit TrueColor (RGB)
        # so the SECO logo ALWAYS plots in full color even under `monochrome.ctb`!
        from ezdxf import colors as dxf_colors, path as dxf_path

        seco_blk = doc.blocks.new("SECO_LOGO")
        if "A$C2F48788A" in src.blocks:
            for e in src.blocks.get("A$C2F48788A"):
                t = e.dxftype()
                if t == "HATCH":
                    try:
                        aci = int(e.dxf.get("color", 7))
                        rgb = dxf_colors.aci2rgb(aci) if 1 <= aci <= 255 else (0, 0, 0)
                        h = seco_blk.add_hatch(
                            dxfattribs={"layer": "TITLEBLOCK", "linetype": "BYLAYER", "lineweight": -1},
                        )
                        h.set_solid_fill(rgb=rgb)
                        for p_obj in dxf_path.from_hatch(e):
                            pts = [(float(v.x), float(v.y)) for v in p_obj.flattening(distance=1.5)]
                            if len(pts) >= 3:
                                h.paths.add_polyline_path(pts, is_closed=True)
                    except Exception:
                        pass
            # Draw crisp black outline lines & splines ON TOP of the colored fills
            for e in src.blocks.get("A$C2F48788A"):
                t = e.dxftype()
                if t == "LINE":
                    seco_blk.add_line(
                        (e.dxf.start.x, e.dxf.start.y),
                        (e.dxf.end.x, e.dxf.end.y),
                        dxfattribs={"layer": "TITLEBLOCK", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
                    )
                elif t == "SPLINE":
                    ctrl = [(p[0], p[1], 0.0) for p in e.control_points]
                    if len(ctrl) >= 2:
                        seco_blk.add_open_spline(
                            ctrl,
                            degree=min(e.dxf.degree, len(ctrl) - 1),
                            dxfattribs={"layer": "TITLEBLOCK", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
                        )

        # 7. Add ISO 5456-2 projection symbol blocks & vector SGS ISO 9001 badge
        add_projection_blocks(doc)
        add_sgs_badge_block(doc)

        # Remove default "Layout1" after creating A0..A4
        audit_meta: Dict[str, Dict] = {
            "sheets": {},
            "layers": ISO_LAYERS,
            "linetypes": list(ISO_LINETYPES.keys()),
        }

        for old_name, (new_name, pw, ph, media_dxf, media_plot, scale_vs_a3) in SHEET_SPECS.items():
            src_lay = src.layouts.get(old_name)
            lay = doc.layouts.new(new_name)

            dx, dy = 0.0, 0.0
            if old_name == "a4":
                lim_min, _ = src_lay.get_paper_limits()
                dx, dy = -float(lim_min.x), -float(lim_min.y)

            # Copy all clean vector border & static title-block entities
            for ent in src_lay:
                if ent.dxftype() in ("VIEWPORT", "OLE2FRAME"):
                    continue
                copy_clean_entity(ent, lay, dx, dy, pw, ph)

            # Place clean vector SGS ISO 9001 badge centered inside its box (~180.5, 18.2 on A3)
            lay.add_blockref(
                "SECO_ISO9001_BADGE",
                insert=(180.5 * scale_vs_a3, 18.2 * scale_vs_a3),
                dxfattribs={
                    "layer": "TITLEBLOCK",
                    "xscale": 0.78 * scale_vs_a3,
                    "yscale": 0.78 * scale_vs_a3,
                    "zscale": 0.78 * scale_vs_a3,
                    "color": 256,
                    "linetype": "BYLAYER",
                    "lineweight": -1,
                },
            )

            # Build attributed block `SECO_TBLOCK_<SIZE>` for all variable title-block fields
            blk_name = f"SECO_TBLOCK_{new_name}"
            tb_blk = doc.blocks.new(name=blk_name)
            for tag, (ax, ay, ah, default_val, prompt) in A3_ATTR_LAYOUT.items():
                sx = ax * scale_vs_a3
                sy = ay * scale_vs_a3
                sh = max(1.4, round(ah * scale_vs_a3, 2))
                tb_blk.add_attdef(
                    tag=tag,
                    text=default_val,
                    insert=(sx, sy),
                    dxfattribs={
                        "layer": "TITLEBLOCK",
                        "style": "SECO_TBLOCK",
                        "height": sh,
                        "prompt": prompt,
                        "color": 256,
                        "linetype": "BYLAYER",
                        "lineweight": -1,
                    },
                )

            ref = lay.add_blockref(
                blk_name,
                insert=(0.0, 0.0),
                dxfattribs={"layer": "TITLEBLOCK", "color": 256, "linetype": "BYLAYER", "lineweight": -1},
            )
            ref.add_auto_attribs({tag: vals[3] for tag, vals in A3_ATTR_LAYOUT.items()})

            # Insert ISO 5456-2 First-Angle Projection Symbol neatly in top-right of GENERAL NOTES box
            proj_scale = 0.55 * scale_vs_a3
            proj_x = 154.5 * scale_vs_a3
            proj_y = 31.2 * scale_vs_a3
            lay.add_blockref(
                "ISO_PROJ_FIRST",
                insert=(proj_x, proj_y),
                dxfattribs={
                    "layer": "TITLEBLOCK",
                    "xscale": proj_scale,
                    "yscale": proj_scale,
                    "zscale": proj_scale,
                    "color": 256,
                    "linetype": "BYLAYER",
                    "lineweight": -1,
                },
            )

            # Configure page setup
            lay.page_setup(
                size=(pw, ph),
                margins=(0, 0, 0, 0),
                units="mm",
                offset=(0, 0),
                rotation=0,
                scale=(1, 1),
                name=media_dxf,
            )
            lay.dxf.plot_configuration_file = "DWG To PDF.pc3"
            lay.dxf.current_style_sheet = "monochrome.ctb"
            lay.dxf.paper_size = media_dxf

            usable = {
                "xmin": round(9.83 * scale_vs_a3 + 2.5, 2),
                "ymin": round(37.00 * scale_vs_a3 + 2.5, 2),
                "xmax": round(410.15 * scale_vs_a3 - 2.5, 2),
                "ymax": round(286.83 * scale_vs_a3 - 2.5, 2),
            }
            usable["width"] = round(usable["xmax"] - usable["xmin"], 2)
            usable["height"] = round(usable["ymax"] - usable["ymin"], 2)

            audit_meta["sheets"][new_name] = {
                "paper_width_mm": pw,
                "paper_height_mm": ph,
                "scale_vs_a3": round(scale_vs_a3, 6),
                "media_plot_name": media_plot,
                "tblock_block_name": blk_name,
                "projection_insert": [round(proj_x, 2), round(proj_y, 2), round(proj_scale, 4)],
                "usable_zone_mm": usable,
            }

        if "Layout1" in doc.layout_names():
            doc.layouts.delete("Layout1")
        doc.layouts.set_active_layout("A3")

        auditor = doc.audit()
        print(f"    ezdxf pre-audit: {len(auditor.errors)} errors, {len(auditor.fixes)} fixes", flush=True)
        if auditor.errors:
            raise RuntimeError(f"ezdxf pre-audit errors: {auditor.errors[:5]}")

        pre_dxf = tmp_path / "sanitized_pre.dxf"
        doc.saveas(str(pre_dxf))

        master_dwt = out_dir / "Seco_master_ISO.dwt"
        master_dxf = out_dir / "Seco_master_ISO.dxf"
        test_pdf = out_dir / "Seco_master_ISO_A3_check.pdf"
        master_dwg_tmp = tmp_path / "Seco_master_ISO.dwg"
        test_pdf.unlink(missing_ok=True)
        master_dxf.unlink(missing_ok=True)

        print("[3/5] Running AutoCAD 2027 AUDIT, native DWT/DXF save, and A3 PDF plot check...", flush=True)
        ac_script = [
            "EXPERT", "5",
            "AUDIT", "Y",
            "-LAYOUT", "S", "A3",
            "SAVEAS", "2018", f'"{master_dwg_tmp}"',
            "DXFOUT", f'"{master_dxf}"', "16",
            "-PLOT", "Y", "A3",
            "DWG To PDF.pc3",
            "ISO full bleed A3 (420.00 x 297.00 MM)",
            "Millimeters", "Landscape", "No", "Layout",
            "1:1", "0.00,0.00", "Yes", "monochrome.ctb",
            "Yes", "No", "No", "No",
            f'"{test_pdf}"', "No", "Yes",
            "QUIT", "N",
        ]
        ac_log = run_accore(pre_dxf, ac_script, timeout=60)
        if not master_dwg_tmp.exists():
            raise RuntimeError(f"AutoCAD failed to save master DWG/DWT.\nLog tail:\n{ac_log[-1500:]}")
        shutil.copy2(master_dwg_tmp, master_dwt)

        print("[4/5] Verifying final Seco_master_ISO.dwt with fresh AutoCAD AUDIT...", flush=True)
        audit_log = run_accore(master_dwg_tmp, ["AUDIT", "Y", "QUIT", "N"], timeout=45)
        audit_lines = [ln.strip() for ln in audit_log.splitlines() if "Total errors found" in ln]
        print("    AutoCAD AUDIT:", audit_lines[-1] if audit_lines else "OK", flush=True)

        final_doc = ezdxf.readfile(str(master_dxf))
        final_audit = final_doc.audit()
        print(f"    ezdxf final audit: {len(final_audit.errors)} errors, {len(final_audit.fixes)} fixes", flush=True)

        audit_meta["verification"] = {
            "ezdxf_errors": len(final_audit.errors),
            "autocad_audit": audit_lines[-1] if audit_lines else "unknown",
            "test_pdf_created": test_pdf.exists(),
        }
        audit_json = out_dir / "template_audit.json"
        audit_json.write_text(json.dumps(audit_meta, indent=2), encoding="utf-8")
        print(f"[5/5] Master template ready:\n  - {master_dwt}\n  - {master_dxf}\n  - {audit_json}\n  - {test_pdf}", flush=True)
        return audit_meta


def main() -> int:
    parser = argparse.ArgumentParser(description="Build sanitized SECO ISO master template.")
    parser.add_argument(
        "--source",
        type=Path,
        default=Path(r"C:\Users\muigu\.gemini\antigravity\brain\d613778b-740d-4da1-a69d-2af6139fb0b6\.user_uploaded\media_1795524872872_8ba7e459.dwt"),
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(r"C:\Users\muigu\.gemini\config\skills\seco-engineering-drawings\templates"),
    )
    args = parser.parse_args()
    build_master_template(args.source, args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
