#!/usr/bin/env python3
"""
SECO 2D Engineering Drawing Generator — Main CLI Entrypoint.

Pipeline:
  1. Load spec (.yaml / .json) & run Intake / Ambiguity Gate (refuses to guess missing data)
  2. Compose 1:1 Model Space + Paper Space DXF from `Seco_master_ISO.dxf`
  3. Finalize via AutoCAD 2027 (`accoreconsole.exe`): AUDIT, save native DWG & DXF,
     and plot monochrome PDF via `DWG To PDF.pc3`
  4. Execute Independent 4-Gate Verification Suite & produce visual inspection PNGs
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path

from cad_core.autocad_bridge import finalize_and_plot
from cad_core.composer import compose_drawing
from cad_core.intake import load_spec, run_intake_gate
from verify_drawing import verify_drawing


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate and verify a SECO ISO 2D engineering drawing.")
    parser.add_argument("spec", type=Path, help="Path to YAML/JSON drawing specification")
    parser.add_argument("--out", type=Path, required=True, help="Output directory for DWG, DXF, PDF, and verification")
    parser.add_argument("--ctb", type=str, default="monochrome.ctb", help="Plot style table (default: monochrome.ctb)")
    parser.add_argument("--intake-only", action="store_true", help="Run only the schema & engineering ambiguity gate")
    args = parser.parse_args()

    spec = load_spec(args.spec)
    print(f"[1/4] Intake & Engineering Ambiguity Gate: {args.spec.name}", flush=True)
    intake = run_intake_gate(spec)
    for w in intake.warnings:
        print(f"  [WARN] {w}", flush=True)
    if not intake.ok:
        print("  [STOP] Engineering ambiguities / schema errors must be resolved before generating CAD:", flush=True)
        for err in intake.errors:
            print(f"    - {err}", flush=True)
        return 1
    print(f"  [OK] Discipline={intake.discipline} | All engineering inputs grounded.", flush=True)
    if args.intake_only:
        return 0

    args.out.mkdir(parents=True, exist_ok=True)
    stem = spec["metadata"]["drg_no"].replace("/", "-").replace(" ", "_")

    out_dwg = args.out / f"{stem}.dwg"
    out_dxf = args.out / f"{stem}.dxf"
    out_pdf = args.out / f"{stem}.pdf"
    manifest_path = args.out / f"{stem}_manifest.json"
    verify_json = args.out / f"{stem}_verification.json"
    crops_dir = args.out / "inspection"

    with tempfile.TemporaryDirectory() as tmp:
        pre_dxf = Path(tmp) / f"{stem}_pre.dxf"
        print("[2/4] Composing 1:1 Model Space geometry, associative dimensions & Paper Space layout...", flush=True)
        manifest = compose_drawing(spec, pre_dxf)
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        print(
            f"  [OK] Sheet={manifest['sheet']} | Scale={manifest['scale_label']} | "
            f"Views={len(manifest['views'])} | Dimensions={len(manifest['dimensions'])}",
            flush=True,
        )

        print("[3/4] Running AutoCAD 2027 AUDIT, native DWG/DXF export & monochrome PDF plot...", flush=True)
        ac_res = finalize_and_plot(
            input_dxf=pre_dxf,
            sheet_size=manifest["sheet"],
            out_dwg=out_dwg,
            out_dxf=out_dxf,
            out_pdf=out_pdf,
            ctb_name=args.ctb,
        )
        if not ac_res.ok:
            print(f"  [FAIL] AutoCAD finalization failed (audit_errors={ac_res.audit_errors}).", flush=True)
            print(ac_res.raw_log[-1500:], flush=True)
            return 2
        print(f"  [OK] AutoCAD AUDIT errors=0 | Saved DWG, DXF, PDF.", flush=True)

    print("[4/4] Running Independent 4-Gate Verification Suite...", flush=True)
    rep = verify_drawing(
        dwg_path=out_dwg,
        dxf_path=out_dxf,
        pdf_path=out_pdf,
        manifest_path=manifest_path,
        spec_path=args.spec,
        crops_dir=crops_dir,
    )
    verify_json.write_text(json.dumps(asdict(rep), indent=2), encoding="utf-8")
    for chk in rep.checks:
        tag = "PASS" if chk.passed else "FAIL"
        print(f"  [{tag}] {chk.gate} | {chk.name}: {chk.detail}", flush=True)

    print("\n--- DELIVERABLES ---", flush=True)
    print(f"  DWG : {out_dwg}")
    print(f"  DXF : {out_dxf}")
    print(f"  PDF : {out_pdf}")
    print(f"  LOG : {verify_json}")
    for k, v in rep.crops.items():
        print(f"  PNG ({k}): {v}")

    if not rep.passed:
        print("\n[FAIL] One or more independent verification gates failed. Do not deliver.", flush=True)
        return 3

    print("\n[PASS] ALL INDEPENDENT VERIFICATION GATES PASSED.", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
