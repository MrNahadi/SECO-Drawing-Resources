---
name: "seco-engineering-drawings"
description: >-
  SECO production 2D engineering drawing generator (DWG, DXF, and monochrome PDF)
  grounded in primary ISO standards (ISO 128, 129-1, 5455, 5456-2, 5457, 3098,
  2768-1/-2) and shipbuilding structural/outfitting conventions (ISO 2553 welds,
  ship coordinate datums, molded lines, plate throw, stiffener toe direction,
  EN 10067 profiles, P/S handing, and steel-weight BOM). Uses the audited SECO
  master template (`Seco_master_ISO.dwt`) and headless AutoCAD 2027 (`accoreconsole.exe`)
  with a mandatory 4-gate automated verification suite. Use whenever creating,
  drafting, detailing, or verifying 2D mechanical or shipbuilding engineering
  drawings for SECO in DWG/DXF/PDF format.
---

# SECO 2D Engineering Drawings (ISO Mechanical & Shipbuilding)

Produce production-grade, standards-compliant 2D engineering drawings in **native DWG, DXF, and monochrome PDF** using SECO's audited ISO master template (`templates/Seco_master_ISO.dwt`).

## Core Engineering Discipline (Non-Negotiable)
1. **Never freehand raw DXF coordinates.** Always author a structured YAML/JSON specification conforming to `references/drawing_spec_schema.json`, then execute `scripts/generate_drawing.py`.
2. **Never invent missing engineering data.** Before generating CAD, run the intake & ambiguity gate. If critical dimensions, tolerances, material/steel grade, plate thickness throw, stiffener toe direction, frame spacing, or `PORT`/`STBD` handing are omitted or contradictory, **stop and ask the user**—never guess manufacturing values.
3. **1:1 Model Space + Paper Space Viewports only.** All geometry is drawn at true `1:1` mm in Model Space; sheet scaling is handled solely by locked Paper Space `VIEWPORT`s at preferred ISO 5455 scales (`1:1`, `1:2`, `1:5`, `1:10`, `1:20`, `1:25`, `1:50`, etc.).
4. **Never deliver an unverified drawing.** Every drawing must pass all 4 independent verification gates (AutoCAD 2027 `AUDIT`, standards/geometry/marine linter, PyMuPDF PDF vector stroke/scale check, and visual inspection of rasterized crops).

## SECO House Baseline (ISO Standard, Millimetres)
Read `references/iso_standards.md` for full tables, and `references/shipbuilding_conventions.md` whenever the drawing is a shipbuilding/marine drawing:
- **Units:** Millimetres (`$INSUNITS = 4`, `$MEASUREMENT = 1`).
- **Projection:** ISO First-Angle (`ISO_PROJ_FIRST`; `third-angle` supported per drawing if requested).
- **Color Discipline (Strict Monochrome + Colored SECO Logo):** Plotted engineering geometry is strictly monochrome black-on-white (`monochrome.ctb` + object lineweights, verified automatically in Gate 3). The **SECO corporate logo (`SECO_LOGO`)** inside the title block uses 24-bit TrueColor fills so it **always plots in full corporate Red & Green** even under `monochrome.ctb` (verified in Gate 3). Never use decorative colors or colored fills on drawing geometry (color is allowed only when regulated, e.g., SOLAS Fire Control Plans or ISO 14726 P&IDs, with `color_mode: functional`). CAD screen layers stay restrained (predominantly white/gray with minimal functional accents).
- **Lineweights:** ISO 128 `0.5` line group (`0.50 mm` visible/cutting, `0.35 mm` hidden, `0.25 mm` dimension/center/hatch/void-cross/molded/weld, `0.18 mm` frame grid), **100% `BYLAYER`**.
- **Voids, Openings & Flat Surfaces (ISO 128 `01.1.3` / `01.1.10` & IACS UR S14):** ALWAYS demarcate void spaces (`VOID` / `V.S.`), cofferdams, cutouts, deck openings, and shaft flats using **thin continuous diagonal crossing lines (`X`, `0.25 mm`)** via `void_space`, `opening`, `flat_surface`, or `test_zone (VOID)` — **NEVER hatch a void**. Hatching (`ANSI31`) is strictly for cut solid material.
- **Section Hatching Discipline (ISO 128-50):** Never hatch ribs, webs, stiffeners, bolts, nuts, pins, or solid shafts when cut longitudinally; alternate hatch angles/spacing on adjacent welded parts; fill very thin cut sections (`< 2 mm` on paper) solid black (`thin_section_fill`) with a `≥ 0.7 mm` white gap between touching parts.
- **General Tolerances:** `ISO 2768-mK` (unless tighter GD&T or IACS Rec. 47 hull tolerances are specified).
- **Text Positioning, Table Enclosure & Zero-Overlap Rule (Gate 3 Enforced):**
  - **Zero overlaps:** No text on text, no text on lines/dimensions/outlines, and **no view/dimension line ever crossing a table (BOM/title block)** (`≥ 5 mm` paper clearance buffer; step down scale or up sheet size rather than crowding).
  - **Strict table enclosure:** Every table cell (BOM, Revision Table, Title Block, Legends) must strictly enclose its text with `≥ 1.5 mm` horizontal cell padding — auto-sized columns, never touching or crossing cell borders (verified automatically on rendered PDF glyphs in Gate 3).
  - **Text placement:** Route callouts/welds outside part outlines into clear margins; mask void `X` lines around centered text; center view titles below the lowest dimension row; read horizontal text left-to-right and vertical text bottom-to-top (ISO 129-1).
- **3D STEP Projection Fidelity (No Erased Features / Open Pipe Ends):** When extracting views from `.step`/`.stp` 3D models via `cad_core/step_projector.py`, always use **exact analytic B-Rep HLR (`HLRBRep_Algo`)** and **never length-cull edges (`min_len_mm <= 1.0 mm`, `curve_deflection <= 2.5 mm`)** so coplanar deck coamings/handrails never suffer mesh Z-fighting erasures and pipe end-caps/flanges/bells stay 100% closed.
- **Shipbuilding Defaults (ISO 128-15 / ISO 2553 / IACS UR S14):** Transverse sections `LKG FWD`, Profile/Plan `FWD →` (or `FWD UP` when frames advance along `+Y`), Near-Side (`NS`) stiffeners solid `VISIBLE` vs. Far-Side (`FS`) stiffeners dashed `HIDDEN`, ISO 2553 welds by design throat thickness `a` (leg `z` when instructed), monochrome UR S14 test codes (`HT`/`ST`/`AT`/`HS`/`VT`/`VOID`), steel density `7.85 t/m³`.

## Workflow

### Step 1 — Intake & Classify Discipline
Inspect all user inputs (reference DWG/DXF/PDF/sketches or plain instructions) and classify:
- `general-mechanical` — machined parts, brackets, shafts, flanges, weldments, assemblies.
- `shipbuilding-structural` — hull blocks, bulkheads, web frames, decks, girders, stiffened panels.
- `shipbuilding-outfitting` — propulsion brackets, foundations, piping supports, bollards, hatches.

If reference CAD files (`DWG`/`DXF`) are provided, extract exact geometry first (using `ezdxf` or `accoreconsole.exe` `DXFOUT`) rather than eyeballing screenshots.

### Step 2 — Author the Drawing Specification (`.yaml`)
Write a clean spec conforming to `references/drawing_spec_schema.json` (see `benchmarks/mech_bearing_bracket.yaml` and `benchmarks/ship_bulkhead_subassy.yaml` as canonical templates).
Check intake completeness first:
```powershell
python "<skill_dir>/scripts/generate_drawing.py" "<job_dir>/spec.yaml" --out "<job_dir>/out" --intake-only
```
If `[STOP]` lists ambiguities, ask the user to confirm those exact items before proceeding.

### Step 3 — Generate, Audit, Plot & Verify
Run the full deterministic pipeline:
```powershell
python "<skill_dir>/scripts/generate_drawing.py" "<job_dir>/spec.yaml" --out "<job_dir>/out"
```
This runs in order:
1. Schema + engineering ambiguity gate.
2. `1:1` Model Space view projection (ISO 5456-2 aligned), ISO 128 line-precedence deduplication, collision-free associative `DIMENSION`s (`SECO_ISO_MM`), shipbuilding overlays & Paper-Space BOM (when in shipbuilding mode), sheet/scale selection, locked `VIEWPORT`, and attributed SECO title block (`SECO_TBLOCK_<SIZE>`).
3. Headless AutoCAD 2027 (`accoreconsole.exe`): `AUDIT`, `REGENALL`, native `.dwg` + `.dxf` export, and monochrome full-bleed `.pdf` plot via `DWG To PDF.pc3`.
4. Independent 4-gate verification (`verify_drawing.py`) + `pdftoppm` visual inspection crops.

### Step 4 — Visual Inspection & Handover
Always inspect the generated PNGs in `<job_dir>/out/inspection/` (`*_full-1.png`, `*_views.png`, `*_titleblock.png`) using `read_file` before handing over files. Confirm:
- No text overlaps, clipped labels, or illegible dimension clusters.
- Title block fields, projection symbol, and BOM look clean and accurate.
- All 4 automated gates report `PASS`.

Deliver `<DRG_NO>.dwg`, `<DRG_NO>.dxf`, `<DRG_NO>.pdf`, and `<DRG_NO>_verification.json`.

## Rebuilding the Master Template
If SECO ever updates its corporate border or `.ctb`, rebuild the master template reproducibly via:
```powershell
python "<skill_dir>/scripts/build_master_template.py" --source "<new_template.dwt>" --out "<skill_dir>/templates"
```
